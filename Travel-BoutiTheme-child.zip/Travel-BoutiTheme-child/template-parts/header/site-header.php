<?php
/**
 * Displays the site header.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

$wrapper_classes  = 'site-header';
$wrapper_classes .= has_custom_logo() ? ' has-logo' : '';
$wrapper_classes .= true === get_theme_mod( 'display_title_and_tagline', true ) ? ' has-title-and-tagline' : '';
$wrapper_classes .= has_nav_menu( 'primary' ) ? ' has-menu' : '';
?>

<div id="masthead" class="<?php //echo esc_attr( $wrapper_classes ); ?> header-cover" role="banner">
    <div class="header_top">
               <div class="container">
                  <div class="d-sm-flex justify-content-between w-100">
                     <ul class="social-icons m-0 p-0">
                        <li><a href="#"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/facebook.svg" alt=""></a></li>
                        <li><a href="#"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/youtube.svg" alt=""></a></li>
                        <li><a href="#"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/instagram.svg" alt=""></a></li>
                        <li><a href="#"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/twitter.svg" alt=""></a></li>
                     </ul>
                     <ul class="acnt-set m-0 p-0">
                        <!--<li>-->
                        <!--   <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/globe.svg" alt="">-->
                        <!--   <span style="position: relative;top: -2px;"><?php echo do_shortcode('[wpml_language_selector_widget]'); ?></span>-->
                        <!--</li>-->
                        <li>
                        <?php if(is_user_logged_in()){?>
                           <a href="<?php echo wp_logout_url( home_url() ); ?>">
                           <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/log-in.svg" alt="">
                           <span>Sign out</span>
                           </a>
                          <?php } else { ?>
                          <a href="<?php echo site_url();?>/my-account/">
                           <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/log-in.svg" alt="">
                           <span>Sign in</span>
                           </a>
                          <?php } ?>
                        </li>
                        <li>
                           <a href="<?php echo site_url();?>/my-account/">
                           <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/user.svg" alt="">
                           <span>My Account</span>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
    </div>

	<?php //get_template_part( 'template-parts/header/site-branding' ); ?>
	<?php //get_template_part( 'template-parts/header/site-nav' ); ?>
	
	<div class="header_main header float-left w-100">
               <div class="container">
                  <div>
                     <div class="mobile_menu my-auto icon-container">
                        <div id="menuicon">
                           <div class="bar bar1"></div>
                           <div class="bar bar2"></div>
                           <div class="bar bar3"></div>
                        </div>
                     </div>
                     <?php //if ( has_custom_logo() ){ ?>
                     <span class="logo logo-head" >
                         <a href="<?php echo site_url();?>"><svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 534.1 177.9"><defs><style>.cls-1{fill:#fff;}</style></defs><path class="cls-1" d="M13.9,35.6H49.4S81.1,40.2,87.8,74s-23,51-34.3,53.5L35.6,110.8s24.2,4.1,32.1-18.4S56.1,55.2,49.4,54.8L32.3,54Z" transform="translate(-1.7 -30.5)"/><polygon class="cls-1" points="0 0 43.5 43.2 43.5 69.8 0 26 0 0"/><polygon class="cls-1" points="0 53.2 87.1 140 87.1 166.6 0 79.5 0 53.2"/><polygon class="cls-1" points="0 106.8 43.5 150.3 43.5 177.9 0 133.7 0 106.8"/><path class="cls-1" d="M142.6,126.5H131.4v24.9h-14v-68h25.3q12,0,18.6,5.4c4.3,3.5,6.5,8.6,6.5,15.1,0,4.7-1,8.6-3,11.6a20.9,20.9,0,0,1-9.1,7.5l14.7,27.7v.7h-15Zm-11.2-11.3h11.3c3.6,0,6.3-.9,8.2-2.7a9.8,9.8,0,0,0,2.9-7.4,10.4,10.4,0,0,0-2.7-7.6c-1.8-1.8-4.6-2.8-8.4-2.8H131.4Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M219.4,121.9H192.5v18.2h31.6v11.3H178.5v-68H224V94.7H192.5v16.2h26.9Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M287.6,151.4h-14l-27.3-44.7v44.7h-14v-68h14l27.3,44.8V83.4h14Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M349.7,94.7H328.8v56.7h-14V94.7H294.3V83.4h55.4Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M372.5,140.1h34.3v11.3H355v-8.2l33.6-48.5H355V83.4h51v8Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M470.3,118.9a40.4,40.4,0,0,1-3.6,17.6,25.8,25.8,0,0,1-10.1,11.7,27.7,27.7,0,0,1-15.2,4.1,28.4,28.4,0,0,1-15.1-4A27.8,27.8,0,0,1,416,136.7a40.4,40.4,0,0,1-3.6-17.4v-3.4A41,41,0,0,1,416,98.3a27.4,27.4,0,0,1,10.2-11.8,28,28,0,0,1,40.5,11.8,40.7,40.7,0,0,1,3.6,17.6Zm-14.2-3c0-7.2-1.3-12.6-3.9-16.3A12.5,12.5,0,0,0,441.3,94a12.7,12.7,0,0,0-10.9,5.5c-2.5,3.7-3.8,9.1-3.8,16.1v3.3c0,7,1.2,12.4,3.8,16.2a12.4,12.4,0,0,0,11,5.7,12.2,12.2,0,0,0,10.8-5.5c2.6-3.7,3.8-9.1,3.9-16.1Z" transform="translate(-1.7 -30.5)"/><path class="cls-1" d="M535.8,151.4H521.7l-27.2-44.7v44.7h-14v-68h14l27.3,44.8V83.4h14Z" transform="translate(-1.7 -30.5)"/></svg></a>
                    </span>
                    <?php //} ?>
                     <ul class="nav-icons icons-mobile float-right d-flex m-0 p-0 ml-lg-4">
                           <li><a href="<?php echo site_url();?>/products/" class="srcicon"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/search.svg" alt=""></a></li>
                           <li><a href="<?php echo site_url();?>/wishlist/">
                               <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/heart.svg" alt="">
                                <span class="badge yith-wcwl-items-count"><?php  echo do_shortcode('[yith_wcwl_items_count]'); ?>  </span> 
                               </a></li>
                           <li><a href="<?php echo site_url();?>/cart/" class="position-relative">
                              <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/cart.svg" alt="">
                              <span class="badge rentzon_wc_count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                              </a>
                           </li>
                        </ul>
                     
                     <?php if ( has_nav_menu( 'primary' ) ) : ?>
	<nav id="site-navigation" class="my-auto d-lg-flex mobile-menu" role="navigation" aria-label="<?php esc_attr_e( 'Primary menu', 'twentytwentyone' ); ?>">
		<?php /*<div class="menu-button-container">
			<button id="primary-mobile-menu" class="button" aria-controls="primary-menu-list" aria-expanded="false">
				<span class="dropdown-icon open"><?php esc_html_e( 'Menu', 'twentytwentyone' ); ?>
					<?php echo twenty_twenty_one_get_icon_svg( 'ui', 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</span>
				<span class="dropdown-icon close"><?php esc_html_e( 'Close', 'twentytwentyone' ); ?>
					<?php echo twenty_twenty_one_get_icon_svg( 'ui', 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</span>
			</button><!-- #primary-mobile-menu -->
		</div><!-- .menu-button-container --> */?>
		<?php
		wp_nav_menu(
			array(
				'theme_location'  => 'primary',
				'menu_class'      => 'menu-wrapper',
				'container_class' => 'primary-menu-container',
				'items_wrap'      => '<ul id="primary-menu-list" class="d-lg-flex w-100 m-0 p-0">%3$s</ul>',
				'fallback_cb'     => false,
			)
		);
		?>
		<ul class="nav-icons icons-desk d-flex m-0 p-0 ml-lg-4">
                    <!--       <li><a href="<?php //echo site_url();?>/products/" class="srcicon"><img src="<?php //echo get_stylesheet_directory_uri();?>/images/icons/search.svg" alt=""></a>-->
                    <!--         <div class="srcheader">-->
                    <!--             <?php
                        // if (is_active_sidebar('searchsidebar')) {
                        //   dynamic_sidebar('searchsidebar');
                        // }
                   ?>-->
                    <!--         </div>-->
                    <!--       </li>-->
                           <li><a href="<?php echo site_url();?>/wishlist/">
                               <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/heart.svg" alt="">
                                <span class="badge yith-wcwl-items-count"><?php echo do_shortcode('[yith_wcwl_items_count]'); ?> </span> 
                               </a></li>
                           <li><a href="<?php echo site_url();?>/cart/" class="position-relative">
                              <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/cart.svg" alt="">
                              <span class="badge rentzon_wc_count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                              </a>
                           </li>
        </ul>
	</nav><!-- #site-navigation -->
<?php endif; ?>
                    
                  </div>
               </div>
            </div>

</div><!-- #masthead -->
