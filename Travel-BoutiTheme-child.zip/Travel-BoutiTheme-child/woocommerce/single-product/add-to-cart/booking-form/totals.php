<?php
/**
 * Booking Totals
 *
 * @author        Leanza Francesco <leanzafrancesco@gmail.com>
 * @var WC_Product_Booking $product
 */
!defined( 'ABSPATH' ) && exit;
?>
<div class="yith-wcbk-booking-form-totals"></div>