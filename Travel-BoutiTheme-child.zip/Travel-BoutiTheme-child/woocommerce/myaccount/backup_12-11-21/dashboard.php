<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/dashboard.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.4.0
 */
?>


<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$allowed_html = array(
	'a' => array(
		'href' => array(),
	),
);
?>

<p>
	<?php
	printf(
		/* translators: 1: user display name 2: logout url */
		wp_kses( __( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ), $allowed_html ),
		'<strong>' . esc_html( $current_user->display_name ) . '</strong>',
		esc_url( wc_logout_url() )
	);
	?>
</p>

<p>
	<?php
	/* translators: 1: Orders URL 2: Address URL 3: Account URL. */
	 $dashboard_desc = __( 'From your <a href="%1$s">admin dashboard</a> you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.', 'woocommerce' );
	//if ( wc_shipping_enabled() ) {
		/* translators: 1: Orders URL 2: Addresses URL 3: Account URL. */
		$dashboard_desc = __( 'From your <a href='.get_admin_url().'>admin dashboard</a>  you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.', 'woocommerce' );
	//}
	printf(
		wp_kses( $dashboard_desc, $allowed_html ),
		esc_url( wc_get_endpoint_url( 'orders' ) ),
		esc_url( wc_get_endpoint_url( 'edit-address' ) ),
		esc_url( wc_get_endpoint_url( 'edit-account' ) )
	);
	?>
</p>

<?php
	/**
	 * My Account dashboard.
	 *
	 * @since 2.6.0
	 */
	//do_action( 'woocommerce_account_dashboard' );

	/**
	 * Deprecated woocommerce_before_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
 ?>
  <style>
  /*@import url('https://fonts.googleapis.com/css?family=Arimo:400,700&display=swap');
body{
  background:#CDDC39;
  font-family: 'Arimo', sans-serif;
}*/
h2{
  color:#000;
  text-align:center;
  font-size:2em;
}
.warpper{
  display:flex;
  flex-direction: column;
  align-items: left;
}
.tabs{display:flex;margin-top:50px;}
.tab{
  cursor: pointer;
  padding:10px 20px;
  margin:0px 2px;
  background:#000;
  display:inline-block;
  color:#fff;
  border-radius:3px 3px 0px 0px;
  font-size:18px;
  /*box-shadow: 0 0.5rem 0.8rem #00000080;*/
}
.woocommerce table.shop_table th{font-size: 17px;}	
.panels{
  background:#fffffff6;
  /*box-shadow: 0 2rem 2rem #00000080;*/
  min-height:200px;
  width:100%;
 /* max-width:500px; */
  border-radius:3px;
  overflow:hidden;
 /* padding:20px; */ 
}
.panel{
  display:none;
  animation: fadein .8s;
}
 .woocommerce-MyAccount-content .radio{display:none;}
 .post-9 .woocommerce .woocommerce-MyAccount-content{border-bottom:none;padding-bottom: 0px;}
 .ui-state-default, .ui-widget-content .ui-state-default{border:none;border-radius:0%;}

@keyframes fadein {
    from {
        opacity:0;
    }
    to {
        opacity:1;
    }
}
.panel-title{
  font-size:1.5em;
  font-weight:bold
}
.radio{
  display:none;
}
#one:checked ~ .panels #one-panel,
#two:checked ~ .panels #two-panel,
#three:checked ~ .panels #three-panel,
#four:checked ~ .panels #four-panel,
#five:checked ~ .panels #five-panel{
  display:block
}
#one:checked ~ .tabs #one-tab,
#two:checked ~ .tabs #two-tab,
#three:checked ~ .tabs #three-tab,
#four:checked ~ .tabs #four-tab,#five:checked ~ .tabs #five-tab{
	background: #ed711b;
    color: #fff;
    border-top: 3px solid #fff;
}
.bgrank{font-weight:bold;color:red;}
.starbutton{height: 46px;padding: 8px; font-size: 15px;font-weight: none;font-weight: normal;float: right; width:20%;}

.fa-copy:before {
    content: "\f0c5";
}

</style>  

<?php 
 global $current_user;
  $user_id = get_current_user_id();
  global $wpdb;
  
  
 $tbl1 = $wpdb->prefix.'termmeta';
 $tbl2 = $wpdb->prefix.'blogger_product';

 $qry = $wpdb->get_row( $wpdb->prepare("select tm.term_id ,bl.blogger_id from ". $tbl1 . " tm ," .  $tbl2 . " bl 
        where tm.term_id = bl.blogger_id AND tm.meta_key ='owner' AND tm.meta_value =  " .$user_id));

  $bgid =  $qry->blogger_id;
  
 ?>
 <script type="text/javascript">
 function copyToClipboard(text) {
    var sampleTextarea = document.createElement("textarea");
    document.body.appendChild(sampleTextarea);
    sampleTextarea.value = text; //save main text in it
    sampleTextarea.select(); //select textarea contenrs
    document.execCommand("copy");
    document.body.removeChild(sampleTextarea);
}

function myFunction(str){
   /* var copyText = document.getElementById("myInput");
    copyToClipboard(copyText.value); */
    var copyText = document.getElementById('myInput'+str);
    copyToClipboard(copyText.value); 

    
}
 



   function statusCheck(){
    alert('hi');
   var ord  = $("#ordvalues").val();
    alert(ord);
    var ordarray = ord.split(',');
    var ordsortby  = $("#sortorder").val();
    alert(ordsortby);
    $.ajax({
          type:'POST',
          data:{"action":"filterOrders","orarray": ordarray,"sortby":ordsortby },       
          url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
          success: function(data) {
          // alert(data);
		       $("#replace").html(data);         
         
        }

      });
   }

   function bloggerdateSorter(){
   var ordsortby  = $("#sortorder").val();
		$.ajax({
			type:'POST',
			data:{"action":"filterdaterange","sortby":ordsortby},       
			url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
			success: function(data) {		
		  	$("#replace").html(data); 
			}		
    }); 
     
  }

   function revenuesorting(){   
     var rev = $("#revenueorder").val();    
     var bg = $("#revbg").val();   
     $.ajax({
			type:'POST',
			data:{"action":"filtrevenue","blogr":bg,"revemod":rev},       
			url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
			success: function(data) {		
		
        $("#revenuereplace").html(data); 
			}		
    });
   }
  
   function ordertypechange(){
     var type = $("#sortorder").val();
     var bg = $("#blgname").val();
     var bid = $("#blid").val();    
     $.ajax({
			type:'POST',
			data:{"action":"filterordertype","blogid":bg,"seltype":type,"bd":bid},       
			url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
			success: function(data) {		
		    // alert(data);
        $("#replaceorders").html(data); 
        
			}		
    });
   }

   function upimage(){
     alert('hi');
   }




   function toggleText(rowid){
     //alert('hai');
    // var x = 'myDiv'+rowid;
     var x = 'myDiv';
   // alert(x);
       //alert(document.getElementById('myDiv'+rowid));
     if(document.getElementById('myDiv').style.display == "none"){
         document.getElementById('myDiv').style.display = "block";
         $.ajax({
          type:'POST',
          data:{"action":"Retrieve","dataid": rowid  },       
          url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
          success: function(data) {
             // alert(data);
              var todisp = data.split('@#$%');
             
            $("#review").html(todisp[0]);
          //$("#startd"+str).html(star);
          document.getElementById('reviewbpid').value = rowid;
          //document.getElementById('myButton'+str).style.display = "block";
           //$("#toreplace").html(data);
        }

      });




     }else{
         document.getElementById('myDiv').style.display = "none";
      
     }
      

  }

  function saveReview(){ 
    var review = $('#review').val();
    //var star = $('#star').val();
    var str  = $('#reviewbpid').val();

     $.ajax({
        type:'POST',
        data:{"action":"Attending","data": review , "id" :str },       
        url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
       // beforeSend: function(){
       //  alert(form);
      //  },
        success: function(data) {
          // alert(data);
           $("#reviewtd"+str).html(data);
        // $("#reviewtd"+str).html(review);
         //$("#startd"+str).html(star);
        // document.getElementById('myDiv'+str).style.display = "none";
         document.getElementById('myButton'+str).style.display = "block";

        }

      });

  }
 </script>


 <?php if($bgid !='') { 
   
   $tblbg = $wpdb->prefix.'terms';
   $tblbg4 = $wpdb->prefix.'blogger_product';
   $bgqry ="select distinct(bg.blogger_id), t.name from " . $tblbg4  ." bg ," .$tblbg . " t where bg.blogger_id = t.term_id   
          AND bg.blogger_id = " .$bgid;
         // echo "select distinct(bg.blogger_id), t.name from " . $tblbg4  ." bg ," .$tblbg . " t where bg.blogger_id = t.term_id   
         // AND bg.blogger_id = " .$bgid;
         
  $bgres = $wpdb->get_results($bgqry);  
  foreach($bgres as $bgn){
  $bloggername  =  $bgn->name;
   // echo $bloggername;
  } 
   // check if user is blogger or not */?>

<div class="wrapper">
  <input class="radio" id="one" name="group" type="radio" checked>
  <input class="radio" id="two" name="group" type="radio">
  <input class="radio" id="three" name="group" type="radio">
  <input class="radio" id="four" name="group" type="radio">
  <input class="radio" id="five" name="group" type="radio">
  <div class="tabs">
      <label class="tab" id="one-tab" for="one">My Assigned Products     
      </label>
      
       <label class="tab" id="two-tab" for="two">Order Received</label>
       <label class="tab" id="three-tab" for="three">Commision</label>
        <label class="tab" id="four-tab" for="four">Top Bloggers</label>
        <label class="tab" id="five-tab" for="five">Product Review</label>
    </div>
  <div class="panels">








  <div class="panel" id="four-panel"  >
  <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
   <thead>     
   <tr>
   <td></td>
   <td></td>
   <td></td>
  <td>
  
  <!--  <div class="sortoption " style="width:100%">
    <div class="form-group mr-3 downArrow">
      <select class="form-control" id="sortorder" >
        <option value="0">Sort by status</option>
        <option value="pending">Pending Payment</option>
        <option value="shipped">Shipped</option>
        <option value="on-hold">On Hold</option>
        <option value="completed"> Completed</option>
        <option value="processing"> Processing</option>
        <option value="cancelled">Cancelled</option>
        <option value="refunded">Refunded</option>
        <option value="failed">Failed</option>
      </select>
    </div>
    </div> -->
    </td>


  </tr>  
  
    

    <tbody>
    <tr>
     <th>Rank</th>
     <th>Name</th>
     <th>Commision Amount</th>
    </tr>
    <?php
    $tblcom = $wpdb->prefix.'blogger_commision';
    $trm    = $wpdb->prefix.'terms';
    $qrybg = "SELECT t.name,`cmid`,`blogger_id`,`ord_id`,sum(`commi_amt`) as tot FROM " .$tblcom. ","
    .$trm. " t where t.term_id = blogger_id group by(`blogger_id`) order by tot desc limit 10 " ;

     
      $res = $wpdb->get_results( $qrybg); 
        $i=1;
      foreach($res as $vl){    ?>
      <tr>
      <?php if($vl->blogger_id == $bgid){  $bgrank = $i ;?>
        <td><span class="bgrank"><?php echo $i; ?></span></td>       
        <td><span class="bgrank"><?php echo $vl->name;?></span></td>
        <td><span class="bgrank"><?php echo $vl->tot;?></span></td>
      <?php }else{ ?>
        <td><?php echo $i; ?></td>       
        <td><?php echo $vl->name;?></td>
        <td><?php echo $vl->tot;?></td>
        <?php } ?>
      </tr> 
     <?php $i = $i +1;}?>
     <tr><td colspan="4"><span class="bgrank"><?php echo "Congradulations !!!! You are in position " .$bgrank ;?></span></td></tr>
    
  </table>  
  </div> 

  <div class="panel" id="one-panel">

  <section class="innerresults">
  <div class="container">
<div class="row rsltContent">
  <div class="col-lg-12">


<div class="packSort d-flex flex-wrap justify-content-end mb-1 mt-4">
 <?php /* <div class="sortoption ">
  <div class="form-group mr-3 downArrow">
    <select class="form-control" id="exampleFormControlSelect1">
      <option>Sort by :Exclusive</option>
      <option>Exclusive</option>
      <option>Exclusive</option>
      <option>Exclusive</option>
    </select>
  </div>
</div> 

   <div class="d-flex ">
 <div class="form-group m-0">
    <input type="text" class="form-control">
  </div>
  <button type="submit" class="btn locSearchbtn"> <img src="images/searchicon.png"></button>
  </div>*/ ?>

</div>
 <div class="row">
 <?php
 
    $tbl3 = $wpdb->prefix.'blogger_product';
         $qrybg = "select bl.* from ". $tbl3 . " bl where 
                   bl.blogger_id  =  " .$bgid . " AND bl.bp_status = 1";                 

        $bid = array();
        $res = $wpdb->get_results( $qrybg); 
        $i = 1; 
	if(count($res)>0){ 	
        foreach($res as $result){    
            $productId = $result->product_id ;
            $product = wc_get_product( $productId );
            $date= date_create($result->time);
            $bid[] =  $result->bpid ;
            $rfcode = strval($result->bpid);
            $image2 = wp_get_attachment_image_src( get_post_thumbnail_id($productId), 'product-main' );
            $postUrl = 'http' . ( isset( $_SERVER['HTTPS'] ) ? 's' : '' ) . '://' . "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}"; 
            $sb_url = urlencode($product->get_permalink().'?refcode='.$result->bpid);
            $sb_title = str_replace( ' ', '%20', $product->get_title());
            $sb_thumb = $image2[0];

            //$whatsappURL2 = '<a href="whatsapp://send?text='.$title.' '.$url.'" target="_blank" class="whatsapp">'
            $whatsappURL = 'https://api.whatsapp.com/send?text='.$sb_title . ' ' . $sb_url;  
                        

          if(!empty($sb_thumb)) {
              $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;media='.$sb_thumb[0].'&amp;description='.$sb_title;
          }else {
               $pinterestURL = 'https://pinterest.com/pin/create/button/?url='.$sb_url.'&amp;description='.$sb_title;
           }
   
            
            ?>
 <?php 
   if($product->get_status()=='publish'){?>
	 <div class="col-lg-4 col-md-6">
	  <div class="resultBox">
	   <div class="boxpic">
	   <a href="<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>" target="_blank">
		 <img src="<?php echo $image2[0];?>" alt="" class="w-100"></a>
	   </div>
	 <div class="boxDetails text-center" style="min-height:200px;">
		<h2><a href="<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>" target="_blank"><?php echo $product->get_title(); ?></a></h2>
		
		<p> <?php 
           $terms = get_the_terms($result->product_id, 'product_cat');
            $product_cat = array();
            foreach ($terms as $term) {    
             $product_cat[] = $term->name;
            }
             $cate  = implode(' , ',$product_cat);
             echo '<span style="font-size:14px;font-weight:normal;">Category :'. $cate .'<span>';
        ?> </p>
		<h3><?php echo $product->get_price_html(); ?></h3>
    <div>
  <!--<input id="myInput<?php echo $result->product_id;?>" class="side-cop" type="text" value="<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>" >
  <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/copyimg.jpeg" onclick="myFunction('<?php //echo $result->product_id;?>')">
          -->
  <input type="text" value="<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>" id="myInput<?php echo $result->product_id;?>">
  <!--<button onclick="myFunction()" >Copy to clipboard</button>-->
  <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/copyimg.jpeg" onclick="myFunction('<?php echo $result->product_id;?>')">

</div>	  
</div>
	 <div class="d-flex">
		<div class="cart dashcart"> 
	<span class="dashsocial" style="font-size:12px;font-weight:bold;"> <a target="_blank" class="share-button share-facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>" title="Share on Facebook"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/social/facebook.png" alt=""></a></span>
  <span class="dashsocial" style="font-size:12px;font-weight:bold;"> <a target="_blank" class="share-button share-twitter" href="https://twitter.com/intent/tweet?url=<?php echo $product->get_permalink().'?refcode='.$result->bpid; ?>&text=<?php echo the_title(); ?>&via=<?php the_author_meta( 'twitter' ); ?>" title="Tweet this"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/social/twitter.png" alt=""></a>
  <span class="dashsocial" style="font-size:12px;font-weight:bold;"><a target="_blank" class="share-button share-pinterest" href="<?php echo $pinterestURL;?> data-pin-custom="true" rel="nofollow"><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/social/pinterest.png" alt=""></a>
  <span class="dashsocial" style="font-size:12px;font-weight:bold;"><a target="_blank" class="share-button share-pinterest" href="<?php echo $whatsappURL; ?>" data-pin-custom="true" rel="nofollow">
   <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/social/whatsapp.png" alt=""></a></span>

     </div>
		<?php /*<div class="wishicon">BGCODE :<?php echo $result->bpid; ?></div> */?>
	 </div>
	 </div>
	</div>

   <?php }
       } 
    }else{ ?>
                <p class="woocommerce-info" style="width:100%;"><?php esc_html_e( 'No products assigned yet.', 'woocommerce' ); ?></p>
      <?php   } ?>
</div>

</div>

  </div>
  </div>
</section>

 
  </div>


  <div class="panel" id="two-panel">
  <div class="sortoption " style="width:40%;float:right;margin-top:10px;">
    <div class="form-group mr-3 downArrow">
      <select class="form-control" id="sortorder" onchange="ordertypechange();">
      <option value="BGCODE">Direct Booking</option>
      <option value="REFEREDCODE">Booking by reference</option>
        

      </select>
    </div>
    </div>  
  <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
   <thead>     
   <th>Order ID </th>
   <th>Product </th>
   <th>Order Status </th>
    </thead> 
   <tbody id="replaceorders" >
    <?php 
     $orme  = $wpdb->prefix.'wc_order_stats';
     $ormeta = $wpdb->prefix.'woocommerce_order_itemmeta';
     $ormeta2 = $wpdb->prefix.'woocommerce_order_items';
     $orderarray = array(); 
     $orderitems = array(); 
 
      /* $ormequery = "select order_id from " .$orme. " where customer_id = " .$user_id ;
       $ormeres   = $wpdb->get_results($ormequery); 
       foreach($ormeres as $ormeval){
             $orderarray[]  = $ormeval->order_id;
       } */
      //print_r($orderarray);
      $orderidsarray = array();
   foreach($bid as $bidval){
       $bgname = $bloggername.'('.$bidval.')';
       $blogrna = "'".$bgname."'";
  
        $qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
        FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
        item.meta_key = 'BGCODE' AND
        item.order_item_id = ord.order_item_id AND
        item.meta_value  = " .$blogrna ;


         $res2 = $wpdb->get_results( $qrybg2); 
        // print_r($res2);

        // echo 'count'.count($res2);
      
         foreach($res2 as $result2){ 
            $orderidsarray[] = $result2->order_id;
            $order = wc_get_order($result2->order_id);
            $ordrdate = date_create($order->get_date_created());   
            if(has_post_parent($result2->order_id)){$flg = "no";}  
            if($flg != 'no'){        
           ?>       
           <tr id="statuschecked">

              <td><?php echo $result2->order_id .$flg.'<br/>'; ?>
              <?php echo 'Order Created On : '.date_format( $ordrdate,'d-m-Y');?></td>      
            
              <td><?php echo $result2->order_item_name;?></td>          
              <td><?php echo $order->get_status();?></td>
      
            </tr>
          
          <?php  }  }
           //else condition 
        }?>
        <tbody>
        <input type="hidden" name="blgname" id="blgname" value="<?php echo $bloggername; ?>">
        <input type="hidden" name="blid" id="blid" value="<?php echo $bgid; ?>">
        
      </table>     
    
  </div>




  <div class="panel" id="three-panel">
  <div class="sortoption " style="width: 30%;float: right;margin-top: 30px;">
    <div class="form-group mr-3 downArrow">
      <input type="hidden" name="revbg" id="revbg" value="<?php echo $bgid;?>">
      <select class="form-control" id="revenueorder" onchange="revenuesorting();">
        <option value="0">Filter Revenue</option>
        <option value="today">Todays Revenue</option>
        <option value="week">Weekly Revenue</option>
        <option value="monthly">Monthly Revenue</option>
        <option value="yearly">Yearly Revenue</option>    
      </select>
    </div>
    </div>

   <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
        <thead>        
      
        <tr>
            <th class="booking-id"><span class="nobr">Order ID/Type</span></th>   
            <th class="booking-id"><span class="nobr">Order Type</span></th>          
            <th class="booking-id"><span class="nobr">Status</span></th>
            <th class="booking-id"><span class="nobr">Date</span></th>
            <th class="booking-id"><span class="nobr">Commision</span></th>
           
        </tr>
        </thead>
      <tbody id="revenuereplace">
        <?php 
          $comtb  = $wpdb->prefix.'blogger_commision';
          $qrycom = "SELECT * FROM " .$comtb. " WHERE blogger_id   = " .$bgid ;
          $res2 = $wpdb->get_results( $qrycom); 
          foreach($res2 as $result2){
            $ordtype =  $result2->commi_type;
            if($ordtype='orderbyref'){$type = "Order By Ref";}else{$type = "Direct Order";}
        ?>
           <tr>
            <td><?php  $order = new WC_Order($result2->ord_id);
$items = $order->get_items();
foreach ( $items as $item ) {
    $product_name = $item['name']; 
   echo $product_name. '------'.$result2->ord_id;  
}  ?></td>            
            <td><?php echo $type; ?></td>
            <td><?php echo $result2->commi_status; ?></td>
            <td><?php echo $result2->commi_date; ?></td>
            <td><?php echo $result2->commi_amt; ?></td>
            
          </tr>
         
        <?php } ?>

       <tr>
       <td></td>
       <td></td>  
       <td></td> 
 
       <td><strong>Total Income:</strong></td>
       <?php 
         $tblcom = $wpdb->prefix.'blogger_commision';
         $qrybgtot = "SELECT sum(`commi_amt`) as tot FROM " .$tblcom. " where blogger_id  = " .$bgid. 
                     " group by(`blogger_id`) " ;
   
         $restot = $wpdb->get_results($qrybgtot); 
          foreach($restot as $result2){?>
             <td><strong><?php echo $result2->tot;?></strong></td>
           <?php } ?>
       </tr>




    </tbody>
   </table>
   </div>
        
   <div class="panel" id="five-panel"> 
  <div style="display:none;" id="myDiv">
  <form  class="wordpress-ajax-form" method="post" id="myForm" action="" enctype="multipart/form-data">
      <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
        <thead>      
    
        <tr><td>Add Review:</td>
          <td><textarea name="review" style="width:60%;" id="review">
            <?php //echo $inrry->bp_pro_review ;  ?>  
          </textarea> </td>
        </tr>
        <td> Select Image Files to Upload: </td>
        <td><input type="file" name="files[]" multiple > </td>

        <tr>
          <td colspan="2">
          <input type="hidden" name="reviewbpid" id="reviewbpid" value="">
	        <?php //wp_nonce_field( 'custom_action_nonce', 'bgcode_of_nonce_field' ); ?>
           <button type="button" id="myButton<?php //echo $result->bpid; ?>" onclick="toggleText(<?php //echo $result->bpid; ?>)" class="starbutton">Hide </button>
          <button type="button" name="savereview" class="starbutton"  onclick="saveReview();">Submit </button>
          </td>
        </tr>
        
        </table>
      </form>
      <?php
      //IF any file is attached

/*      
if ( $_FILES ) {
    $files = $_FILES["files"];  
    foreach ($files['name'] as $key => $value) {    
            if ($files['name'][$key]) {
                $file = array( 
                    'name' => $files['name'][$key],
                    'type' => $files['type'][$key], 
                    'tmp_name' => $files['tmp_name'][$key], 
                    'error' => $files['error'][$key],
                    'size' => $files['size'][$key]
                );

                    $_FILES = array ("files" => $file); 
                    foreach ($_FILES as $file => $array) {              
                        $newupload = my_handle_attachment($file,$pid); 
                    }
            } 
        } 
    }
?>


<form class="formimages" action="" enctype="multipart/form-data" method="post">
	<label>Select Images</label>
	<input type="file" name="files[]" id="gallery-photo-add" multiple> <small>Max 2 MB (PNG, JPEG, JPEG)</small>
	<input type="submit" value="Upload" class="saveyt" name="submitdata">
</form>*/ ?>



     </div>

     <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
        <thead>      
        <tr>
            <th class="booking-id"><span class="nobr">Product Name</span></th>
            <th class="booking-id"><span class="nobr">Product Category</span></th>
            <th class="booking-id"><span class="nobr">Review</span></th>            
            <th class="booking-from" ><span class="nobr"></span></th>
           
        </tr>
        </thead>
      <tbody>
       <?php 
        $tblstr = $wpdb->prefix.'blogger_product_review';
        foreach($res as $result){    
            $productId = $result->product_id ;
            $product = wc_get_product( $productId );
            $date= date_create($result->time);
            $inrry =$wpdb->get_row( $wpdb->prepare( "select bp_pro_review,bp_pro_star from ".$tblstr." 
            where bpid = " . $result->bpid ));
  
         
       ?>
     

        <tr class="booking">
        <td class="booking-id" data-title="Booking"><?php echo $product->get_title(); ?></td>
        <td class="booking-id" data-title="Booking">
        <?php 
           $terms = get_the_terms($result->product_id, 'product_cat');
          // print_r($terms);
           $product_cat = array();
           foreach ($terms as $term) {    
             $product_cat[] = $term->name;
               }
             $cate  = implode(' , ',$product_cat);
             echo $cate;
        ?></td>
        <td id="reviewtd<?php echo $result->bpid; ?>"> <?php if($inrry->bp_pro_review ==''){echo "No review added yet";}else{echo $inrry->bp_pro_review ;}  ?>    </td>
       
         <td class="booking-from" data-title="From" id="rwform<?php echo $result->bpid; ?>">
         <button type="button" id="myButton<?php echo $result->bpid; ?>" onclick="toggleText(<?php echo $result->bpid; ?>)">Add / Update   </button>        
   
        
        </td>

        
      </tr>

    <?php } //print_r( $bgid); ?>

    </tbody>
  </table>
  </div>

  
  </div>



</div>



<?php } ?>
  
 <?php	 
	do_action( 'woocommerce_before_my_account' );

	/**
	 * Deprecated woocommerce_after_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_after_my_account' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
