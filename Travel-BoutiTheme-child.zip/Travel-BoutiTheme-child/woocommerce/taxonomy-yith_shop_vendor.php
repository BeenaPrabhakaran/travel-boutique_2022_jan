	<?php get_header('shop'); 
      global $yith_woocompare; 
      global $wpdb;
      $lang = apply_filters( 'wpml_current_language', NULL ); 
   // echo 'lang'.$lang;
?>


  <?php
     $catalog_orderby_options = apply_filters(
      'woocommerce_catalog_orderby',
      array(
        'menu_order' => __( 'Default sorting', 'woocommerce' ),
        //'popularity' => __( 'Sort by popularity', 'woocommerce' ),
        //'rating'     => __( 'Sort by average rating', 'woocommerce' ),
      //  'date'       => __( 'Sort by latest', 'woocommerce' ),
        'price'      => __( 'Sort by price: low to high', 'woocommerce' ),
       'price-desc' => __( 'Sort by price: high to low', 'woocommerce' ),
     )
);

 /*$default_orderby = wc_get_loop_prop( 'is_search' ) ? 'relevance' : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', '' ) );
   $orderby = isset( $_GET['orderby'] ) ? wc_clean( wp_unslash( $_GET['orderby'] ) ) : $default_orderby;

   if ( wc_get_loop_prop( 'is_search' ) ) {
     $catalog_orderby_options = array_merge( array( 'relevance' => __( 'Relevance', 'woocommerce' ) ), $catalog_orderby_options );

     unset( $catalog_orderby_options['menu_order'] );
   }

   if ( ! $show_default_orderby ) {
     unset( $catalog_orderby_options['menu_order'] );
   }

   if ( ! wc_review_ratings_enabled() ) {
     unset( $catalog_orderby_options['rating'] );
   }

   if ( ! array_key_exists( $orderby, $catalog_orderby_options ) ) {
     $orderby = current( array_keys( $catalog_orderby_options ) );
   }*/

 
 ?>  

<section class="innerresults">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 ">
      <?php woocommerce_breadcrumb(); 
     
      ?>
  </div>
</div>
  <?php 
    
    if($_REQUEST['orid']){
        $vid = $_GET['orid'];
    }else{
       $vid = get_queried_object()->term_id; 
      // $vid = '41';
    }
    //echo 'vid'.$vid;
    $taxonomy = get_queried_object(); 
    $thumbvendor_id = get_term_meta( $vid, 'avatar', true ); 
    $headerimg    = get_term_meta($vid,'header_image',true);
    $term_object = get_term($vid);
    $bgslug = $term_object->slug;
    
    $imagenow  = wp_get_attachment_image_src( $thumbvendor_id, 'blogger-size-detail' );
    $imagehead = wp_get_attachment_image_src( $headerimg,'blogger-header',true );
   
    
    ?>
<div class="row">
  <div class="col-lg-12 ">
 
 
  <div class="blogersbanner d-flex justify-content-center">
  <div class="bloggerpic">
  <div class="d-flex">
  <?php if($imagenow[0]){ ?>
        <img src="<?php echo $imagehead[0];?>" alt="" class="partnerpart">
   <?php } else { ?>
        <img src="<?php echo site_url();?>/wp-content/uploads/woocommerce-placeholder.png" alt="" class="placedones">
    <?php } ?>
  <h4>Travel <span>BoutiqueKW</span><br>
 <?php echo  $taxonomy->name; ?></h4>
 <input type="hidden" name="blogid" id="blogid" value="<?php echo $vid; ?>"> 
</div>
</div>
 </div> 


</div>
</div>

<div class="row rsltContent">
 <?php 
 if(isset($_REQUEST['cats'])){ $cat_id1 = $_GET['cats']; ?>

 <div class="col-lg-3">
 <div class="filterBox">
  
  <?php if($lang == 'ar'){?>
     <div class="filterHead"> <?php echo 'مصنف بواسطة' ; ?> </div>
     <div class="fltersubHead"><?php echo 'خدمات' ; ?>  </div>
  <?php }else{ ?>
    <div class="filterHead"> FILTER BY </div>
     <div class="fltersubHead"> Services </div>
  <?php } ?>

  <div class="filterService" id="find-table">

   <?php
    $args = array(
     'taxonomy'   => "product_cat",
     'hide_empty' =>0,
  
     
  );
  $product_categories = get_terms($args);    
    foreach($product_categories as $cat) { 
      if($cat->term_id != 15){
      ?>
       <label class="filtercheck"><?php echo $cat->name ; 
       
       if($cat->term_id == $cat_id1){
       ?>
        <input type="checkbox" name="cate" value="<?php echo $cat->term_id ; ?>" style="float: left;margin-right: 10px;" checked>
        <span class="checkmark"></span>
      <?php }else{ ?>
        <input type="checkbox" name="cate" value="<?php echo $cat->term_id ; ?>"  style="float: left; margin-right: 10px;">
        <span class="checkmark"></span>
    <?php  } ?>
      </label>      
   
   <?php }   }  ?>


  </div>
  <?php if($lang == 'ar'){?>
     <div class="fltersubHead"> <?php echo 'السعر' ; ?> </div>
  <?php }else{?>
    <div class="fltersubHead"> Price </div>
   <?php } ?>
  <div class="filterService">
    <div class="priceAmount">
    <input type="text" id="amount_min" >
    <input type="text" id="amount_max"> 
</div>
  <div id="slider-range"  ></div>
  </div>



  <div class="fltersubHead"> Location </div>
  <div class="filterService">
    <div class="d-flex mt-4">
 <div class="form-group m-0">
    <input type="text" class="form-control" id="city"  name="city" autocomplete="off" >
    <div id="key" style="padding: 10px;padding: 10px;
    border-top: 1px solid #ced4da;
    border-left: 1px solid #ced4da;
    border-right: 1px solid #ced4da;
    border-bottom: 1px solid #ced4da;display:none;"></div>
  </div>
  </div>

</div>
<div style="text-align: right; margin-right: 25px;">
<button type="button" class="btn locSearchbtn" name="locsub" id="locsub" onclick="PrcFilterchange()" style="color:#fff;">Apply Filter  </button> 
  <!--<img src="<?php //echo get_stylesheet_directory_uri();?>/images/searchicon.png">--> 
  </div>
 </div>
</div> <?php } ?>
<?php 
 if(isset($_REQUEST['cats'])){  ?>
      <div class="col-lg-9">  
<?php }else{?>
  <div class="col-lg-12"> 
 <?php } ?>
<?php /* if($headerimg !=''){ ?>

<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="<?php echo $imagehead[0]; ?>" alt="First slide">
       <div class="carousel-caption d-none d-md-block">
        DUBAI PACKAGE
       </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="<?php echo $imagehead[0]; ?>" alt="Second slide">
      <div class="carousel-caption d-none d-md-block">
        DUBAI PACKAGE
       </div>
    </div>
  
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
  </a>
</div>
 <?php  } 
<div class="packSort d-flex flex-wrap justify-content-end mb-1 mt-4">

  <div class="sortoption ">
    <div class="form-group mr-3 downArrow">
    <div class="sortoption ">
      <div class="form-group mr-3">
     
      <select name="orderby" id="orderby" class="form-control orderby" onchange="sortChange()" aria-label="<?php esc_attr_e( 'Shop order', 'woocommerce' ); ?>" style="width:auto;" >
        <?php foreach ($catalog_orderby_options as $id => $name ) : ?>
          <option value="<?php echo esc_attr( $id ); ?>" <?php selected( $orderby, $id ); ?> ><?php echo esc_html( $name ); ?></option>
        <?php endforeach; ?>
      </select>

      </div>
    </div>

   <?php /* <select class="form-control" id="exampleFormControlSelect1">
      <option>Sort by :Exclusive</option>
      <option>Exclusive</option>
      <option>Exclusive</option>
      <option>Exclusive</option>
    </select> 
  </div>
</div>

<div class="d-flex ">  
 <div class="form-group m-0">
    <input type="text" class="form-control" name="searchtext" id="searchtext" placeholder="Search By Product Name">
  </div>
  <button type="submit" class="btn locSearchbtn" onclick="textSearch()"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/searchicon.png"></button>       
</div>

</div> */ ?>
  <?php
     
      $tbl5 = $wpdb->prefix.'blogger_product';
      $qry5 ="select * from " .  $tbl5 ." 
               where bp_status = '1' AND blogger_id = $vid  AND lan =  '".$lang."' ";
     
     //$arab = apply_filters( 'wpml_object_id', $vid,'vendors',false);     
       // echo 'arab'. $arab;
       // echo 'original'.get_term(icl_object_id($arab, 'vendors', false))->term_id;
       $original = apply_filters('wpml_object_id', $vid, 'vendors', 'true', 'en') ;    
               $pids = array();
               $bpid = array();
               
       $pidval =  implode(",",$pids);   
  
       $results5 = $wpdb->get_results( $qry5); 
       $rowcount5 = count($results5); //PHP count()
       foreach($results5 as $result5){ 
        $pids[] = $result5->product_id;     
        $bpid[] = $result5->bpid;     
      }
 
  if(!isset($_REQUEST['cats'])){ //cats listing section     
     ?>

      
 <div class="row" id="result">
 
    <?php 
    // echo "comeing";

     $product_cat  = array();
     $catids = array();
      $i = 0;
      foreach($pids as $val){  
       $terms = get_the_terms($val, 'product_cat');
       foreach ($terms as $term) {
          $product_cat[] = $term->name;
            break;
          }       
      }  
   
      $product_cat = array_unique($product_cat);
      $i = 0;

     foreach($product_cat as $val){  
       $catid = get_cat_ID($val);
       $tbl5 = $wpdb->prefix.'terms';
       $tbl6 = $wpdb->prefix.'termmeta';
       $tbl7 = $wpdb->prefix.'term_taxonomy';

       //$img = get_the_category_thumbnail($catid);  

       $qry5 ="select t.term_id, tm.* , tx.description from " .$tbl5."   
       t , " .$tbl6. " tm , " .$tbl7. " tx where 
       t.term_id = tx.term_id AND
       t.term_id = tm.term_id AND 
       tm.meta_key = 'thumbnail_id' AND
       t.name = '".$val."' " ;
        $results5 = $wpdb->get_results( $qry5);  
        foreach($results5 as $vl){ 
          $image = wp_get_attachment_url($vl->meta_value );
         
      ?>
      
    <div class="col-lg-3 col-md-4">
      <div class="resultBox">
    
      <?php if($image != ''){ ?>
        <div class="boxpic">
        <img src="<?php echo $image;?>" alt="" class="partnerpart">
        </div>
   <?php } else { ?>
    <div class="boxpiccc">
        <img src="<?php echo site_url();?>/wp-content/uploads/woocommerce-placeholder.png" alt="" class="placedones">
        </div>
    <?php } ?>

      
   <div class="boxDetails text-center">
        <h2><?php echo $val;?></h2>
        <p><?php echo $vl->description; ?></p>
     
      </div>


    <div class="d-flex">
    <?php if($lang == 'ar'){  
      $arabcat = apply_filters( 'wpml_object_id',$vl->term_id,'category',false,'en'); 
      //echo 'cat'.$arabcat ;
      ?> 
    <div class="cart">
      <a href="<?php echo site_url();?>/ar/مدون/<?php echo $bgslug; ?>/?cats=<?php echo $vl->term_id;?>&orid=<?php echo $vid; ?>" style="color:#fff;"> <?php echo 'اذهب إلى ' . $val;?></a>
    </div>
    <?php }else{?>
    <div class="cart">
      <a href="<?php echo site_url();?>/blogger/<?php echo $bgslug; ?>/?cats=<?php echo $vl->term_id;?>" style="color:#fff;"> Go To <?php echo $val;?></a>
    </div>
    
    <?php } ?> 
   </div>
      <?php  } ?>
   </div>
   </div>
     <?php //} ?>
  

  <?php //$i = $i + 1; 

      } //foreach 
 


   }else{ 
      $cat_id1 = $_GET['cats'];
     // echo $cat_id1;
      $exist = array();
      $catpids = array();
        $args = array(      
        'post_type' => 'product',
        'post_status' => 'publish',
        'tax_query' => array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field'    => 'term_id',
                            'terms'    => array($cat_id1),
                            ),
                        ),
            );

    $the_query = new WP_Query($args);    
      while($the_query->have_posts() ) {
              $the_query->the_post();
           //   echo  get_the_title() .'</br>';
              $exist[] =  get_the_ID();
          }
      foreach($results5 as $result5){ 
        if(in_array($result5->product_id,$exist)){
                $catpids[] = $result5->product_id;     
        }     
    }
   // print_r($exist);
   // print_r($catpids);
    if(count($catpids) > 0){
    ?>
    <div class="row" id="result">
 
    <?php 
       $i = 0;
     foreach($catpids as $val){  
      // echo $val;
         $product3 = wc_get_product($val);
         $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($val),'prod-thumb');
         $sts = $product3->get_status();
        // echo 'tst'.$sts;
         if($sts == 'publish'){
        //echo "exist";
      ?>
    <div class="col-lg-4 col-md-4">
      <div class="resultBox">
      
      <?php if($image3[0]){ ?>
        <div class="boxpic">
        <img src="<?php echo $image3[0];?>" alt="" class="partnerpart">
        </div>
   <?php } else { ?>
    <div class="boxpiccc">
        <img src="<?php echo site_url();?>/wp-content/uploads/woocommerce-placeholder.png" alt="" class="placedones">
        </div>
    <?php } ?>

      
   <div class="boxDetails text-center">
        <h2><?php echo mb_strimwidth(get_the_title($val), 0,100, '...');?></h2>
        <p><?php echo mb_strimwidth($product3->get_short_description($val),0,60,'...');?></p>
      <?php if ($product3->is_type( 'booking' )) { ?>  
        <h3><?php echo $product3->get_price_html(); ?></h3>
       <?php }elseif($product3->product_type=='variable') {   
						$available_variations = $product3->get_available_variations();
						$count = count($available_variations)-1;
						$variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
						$variable_product1= new WC_Product_Variation( $variation_id );
						$regular_price = $variable_product1 ->regular_price;
						$sales_price = $variable_product1 ->sale_price;
                    ?>  
              <h3>KD <?php echo $sales_price;?></h3>
							<h3>KD <?php echo $regular_price;?></h3> 
         <?php }else{ ?>  
            <h3><?php echo $product3->get_price_html(); ?></h3>
          <?php } ?>
      </div>
      <div class="d-flex">
      <?php if($lang == 'ar'){?> 
          <div class="cart"><a href="<?php echo $product3->get_permalink().'?bgcode='.$bpid[$i]; ?>" style="color:#fff;"> <?php echo 'أضف إلى السلة';?> </a></div>
      <?php }else{ ?>
          <div class="cart"><a href="<?php echo $product3->get_permalink().'?bgcode='.$bpid[$i]; ?>" style="color:#fff;">ADD TO CART </a></div>

       <?php } ?> 
          
        </div>

   </div>
   </div>
     <?php } ?>
  

  <?php $i = $i + 1; } //foreach ?>
  <input type="hidden" name="prodid" id="prodid" value="<?php echo $pidval; ?>"> 
   <?php     
     }else{ //if loop ?>
      <p class="woocommerce-info" style="width:100%;"><?php esc_html_e( 'No products were found matching your selection.', 'woocommerce' ); ?></p>
     <?php } 



     } // else condion cat exist ?>
   </div>

  </div>
  </div>
</section>

<?php echo hand_picked_deals(); ?>
<?php get_footer('shop');?>

