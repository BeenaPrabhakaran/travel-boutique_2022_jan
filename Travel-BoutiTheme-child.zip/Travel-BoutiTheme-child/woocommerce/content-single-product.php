<style>
	 /*#sidebar{display:none !important;}
	 //ol .sidebar{display:none;}
    /* nav ol.breadcrumb{display:none !important;} 
    .bread nav ol.breadcrumb{display:block !important;} */    
  
	 .cart{background-color:#fff;}
</style>
 <?php
   if(isset($_GET['bgcode'])) {
        $bgid  = $_GET['bgcode'];
   }
   if(isset($_GET['refcode'])) {
        $bgid  = $_GET['refcode'];
   } 
   //echo'bgcode'. $bgid;

   $tblbg = $wpdb->prefix.'terms';
   $tblbg4 = $wpdb->prefix.'blogger_product';
   $bgqry ="select bg.blogger_id, t.name from " . $tblbg4  ." bg ," .$tblbg . " t where 
            bg.blogger_id = t.term_id   
            AND bg.bpid = " .$bgid;
         /* echo "select bg.blogger_id, t.name from " . $tblbg4  ." bg ," .$tblbg . " t where 
          bg.blogger_id = t.term_id   
          AND bg.bpid = " .$bgid; */
         
  $bgres = $wpdb->get_results($bgqry);  
  foreach($bgres as $bgn){
  $bloggername  =  $bgn->name;
      //echo $bloggername;
  } 
global $product; ?>	
<section class="innerresults" style="min-height:200px;">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 bread ">
	  <?php woocommerce_breadcrumb(); ?>
  </div>
</div>

<div class="row">
  <div class="col-lg-12 ">
 <div class="innerBanner d-flex justify-content-center">
  <img src="<?php echo get_stylesheet_directory_uri();?>/images/dubaiPack.jpg">
  <h2><?php echo $product->get_name(); ?></h2>
 </div>
</div>
</div>

<div class="row rsltContent">
<div class="col-lg-6">
 <?php do_action( 'woocommerce_before_single_product_summary' );  ?>
</div>


<div class="col-lg-6">
<div class="pacdtlsBox">
  <h2><?php echo $product->get_name(); ?></h2>
  <h5><?php
   $vendor_id = get_post_field( 'post_author', $product->product_id );
   $vendor_id = get_post_field( 'post_author', $product_id );
 // $vendor = get_userdata( $vendor_id );
 // $name = $vendor->display_name;
  //echo 'By '.$bloggername;?> </h5>
  <h3><?php echo $product->get_price_html(); ?></h3>
     <p><?php echo $product->get_short_description(); ?> </p>
      <?php //do_action( 'woocommerce_single_product_summary' ); ?>
   </div>
  </div>
</div>  
<div class="dtlsInclusion">
<div class="row">
  <div class="col-lg-12">
  <?php do_action( 'woocommerce_single_product_summary' ); ?>

</div>
</div>
</div>


<div class="row">
<div class="col-lg-12">
<?php
  $product_tabs = apply_filters( 'woocommerce_product_tabs', array() );

  if ( ! empty( $product_tabs ) ) : 
  
    $liname = array('pills-home','pills-profile','pills-contact');
     $i = 1;
 ?>
  <div class="dtlTabs">
    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
  <?php foreach ( $product_tabs as $key => $product_tab ) : ?>
	<li class="nav-item" >
	<a class="nav-link <?php if($i==1){echo "active";}?>" id="pills-<?php echo $i; ?>-tab" data-toggle="pill" href="#pills-<?php echo $i; ?>" role="tab" aria-controls="pills-<?php echo $i; ?>" aria-selected="<?php if($i==1){echo 'true';}?>">

			<?php echo wp_kses_post( apply_filters( 'woocommerce_product_' . $key . '_tab_title', $product_tab['title'], $key ) ); ?>
		</a>
	</li>
 <?php $i= $i +1 ; endforeach; ?>

</ul>
<div class="tab-content" id="pills-tabContent">
<?php 
   $i = 1;
  foreach ( $product_tabs as $key => $product_tab ) : ?>

  <div class="tab-pane <?php if($i==1){echo "show active";} ?>" id="pills-<?php echo $i; ?>" role="tabpanel" aria-labelledby="pills-<?php echo $i; ?>-tab">
    <?php
		if ( isset( $product_tab['callback'] ) ) {
			call_user_func( $product_tab['callback'], $key, $product_tab );
		}
	?>

 </div>
  <?php $i= $i+1;
  endforeach; ?>
 <?php do_action( 'woocommerce_product_after_tabs' ); ?>
  
</div>

  </div>
  <?php endif; ?>

</div>
</div>
  </div>
</section>