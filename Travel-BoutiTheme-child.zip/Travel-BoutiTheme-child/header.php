<?php $lang = apply_filters( 'wpml_current_language', NULL );

  //echo 'lang' .$lang;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>

<head>
     <meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="google" value="notranslate">
  <!-- Favicons -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/images/favicon.png" rel="icon">
  <link href="imgages/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600&family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400;500;600;700&display=swap" rel="stylesheet">
 
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@100&display=swap" rel="stylesheet">
 

  <!-- Bootstrap core CSS -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/jquery-ui.min.css" rel="stylesheet">
    <link href="<?php echo get_stylesheet_directory_uri();?>/css/owl.carousel.min.css" rel="stylesheet">
   <link href="<?php echo get_stylesheet_directory_uri();?>/css/custom.css" rel="stylesheet">
  
  <!-- Include following into your head tag
*******************************-->
<?php /*
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> */ ?>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
<style>
 p.counter-count{
     font-family: 'Teko', sans-serif;
    font-weight: 400;
    letter-spacing: 2px;
    text-transform: uppercase;
    font-size: 68px;
    line-height: 55px;
    display: inline-flex;
    margin-bottom: 0px;
    color:#333;
}


   
  </style>
 
 <script type="text/javascript">

   $(document).ready(function() {
    $('ul li.wpml-ls-current-language').click(function(e){ 
        $lng = $(this).find("span.wpml-ls-native").text();
        alert($lng);
        if($lng == 'English'){
            $("#lang").val('en');    
        }else{
           $("#lang").val('ar'); 
        }
     // alert($("#lang").val());
    });

  var queryString = window.location.search;
  var urlParams = new URLSearchParams(queryString);     
  if(localStorage.getItem('orderbgid') !== null){ 
		$("#wdm_name").val(localStorage.getItem('orderbgid')) ;
 
   }else{	 
 	    var page_type = urlParams.get('bgcode');    
	  localStorage.setItem('orderbgid', page_type);
		$("#wdm_name").val(localStorage.getItem('orderbgid')) ; 

   }

   if (localStorage.getItem('refcode') > 0){
		$("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 
   }else{  	 
 	    var page_type2 = urlParams.get('refcode');
		localStorage.setItem('refcode', page_type2);
   	$("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 

    }
	
  });

  
  function selBlogger(){
    var serv = $("#serv").val();
    var lan = $("#lang").val();
    $.ajax({
          type:'POST',
          data:{"action":"pickbloggers","catid": serv },       
          url: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
          success: function(data) {
           // alert(data);
             $("#blogsel").html(data);          
        }
      });
  }

  function selpage(){
    var catid = $("#serv").val();
    var blgvl = $("#blg").val();
   var lan = $("#lang").val();
    if(lan == 'ar'){
       window.location.href= blgvl+'&cats='+catid;
    }else{
      window.location.href='<?php echo site_url();?>/blogger/'+blgvl+'?cats='+catid;
      
    }
  }
  </script>
 
 

<?php wp_head(); ?>
<?php //echo 'lmge45345345'. $lang; ?>

  
</head>

<body>
 
<?php 
 $settingspost_id = '44826';
 $lang = apply_filters( 'wpml_current_language', NULL );
 ?>

<?php $site = $_SERVER['REQUEST_URI']; 
  // echo "urlreq" . $site;
?>
<header>
<input type="hidden" name="lang"  id="lang" value="<?php echo $lang ; ?>">
  <div class="topHeader DeskShow">
  <div class="container">
    <div class="row">
        <div class="col-lg-5">
          <p class="d-flex"> <i class="hmPhoneIcon"> </i><span><?php echo get_field('phone_number',$settingspost_id);?></span> <span class="pl-2 pr-2 hmtopseprt"> | </span> <i class="hmmailIcon"> </i><span><a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>"><?php echo get_field('email_link',$settingspost_id);?></a> </span></p>
         
           
        </div> 
        <div class="col-lg-7">
         
        <?php if($lang == 'ar'){ ?> 
        
        <ul class="d-flex justify-content-end">    


          <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/globe.svg" alt=""> 
           <?php echo do_shortcode('[wpml_language_selector_widget]'); ?> 
          
           <a href="<?php echo site_url();?>/ar/cart/"><li><?php echo esc_html_e( 'عربة التسوق', 'twentytwentyone' ); ?></li></a>
          <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>/ar/">
          <li data-toggle="modal"><i class="hmSignInIcon"></i><span class="iconarab"><?php echo esc_html__( 'خروج', 'twentytwentyone' );?></span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/ar/my-account/">
          <li data-toggle="modal"><i class="hmSignInIcon"></i><span class="iconarab"><?php echo esc_html__( 'تسجيل الدخول', 'twentytwentyone' );?></span></li>
          </a>
           <?php } ?> 
           <a href="<?php echo site_url();?>/ar/my-account/">
          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span class="iconarab"><?php echo esc_html__( 'حسابي', 'twentytwentyone' );?></span></li> </a>

          </ul>
       <?php }else{ ?>
        <ul class="d-flex justify-content-end">    
        <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/globe.svg" alt=""> 
           <?php echo do_shortcode('[wpml_language_selector_widget]'); ?>

        <a href="<?php echo site_url();?>/cart/"><li data-toggle="modal">  <i class="cartIcon"></i>
          <span><?php echo esc_html_e( 'Cart', 'twentytwentyone' ); ?></span></li></a>

        <?php if(is_user_logged_in()){?>
         <a href="<?php echo wp_logout_url( home_url() ); ?>/">
        <li data-toggle="modal">
          <i class="hmSignInIcon"></i><span><?php echo esc_html__( 'Sign Out', 'twentytwentyone' );?></span></li>
        </a>
        <?php } else { ?>
          <a href="<?php echo site_url();?>/my-account/">
        <li data-toggle="modal"><i class="hmSignInIcon"></i><span><?php echo esc_html__( 'Sign In', 'twentytwentyone' );?></span></li>
        </a>
        <?php } ?> 
        <a href="<?php echo site_url();?>/my-account/">
        <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span><?php echo esc_html__( 'My Account', 'twentytwentyone' );?></span></li> </a>
        </ul>
     <?php  }  ?>
        </div>
    </div>
  </div>
</div>

    <!-- Mobile Navigation -->
 <section class="mobileShow " id="wrapper">
  <a href="#" class="menu"><img src="<?php echo get_stylesheet_directory_uri();?>/images/mobmenu.png"></a>
          
</section>

  <nav class="slide-content">
    <div class="hmclose"><img src="<?php echo get_stylesheet_directory_uri();?>/images/hmclose.png"></div>
 
 
  <ul class="pt-2">
  <li><?php echo do_shortcode('[wpml_language_selector_widget]'); ?> </li>
           
  <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>">
          <li data-toggle="modal" data-target=""><i class="hmSignInIcon"></i><span>Sign Out</span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/my-account/">
          <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/my-account/">Sign In</a></span></li>
          </a>
           <?php } ?> 

    <a href="<?php echo site_url();?>/my-account/">          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span>My Account</span></li> 
    </a>
    <li><a href="<?php echo site_url();?>/">Home</a></li>
    <li class="dropdown"><a href="" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
     <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
  </div>
    </li>
   <li <?php if($site == '/how-it-works/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/how-it-works">How it works</a></li>
   <li <?php if($site == '/contact-us/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/contact-us"  >Contact</a></li>  </ul>
</nav>
<div class="slide-fade"></div>
    <!-- Mobile Navigation close-->

   <div class="container">
    <div class="row headpad">
    <div class="col-lg-4 col-md-4 col-12">
       
    <?php
    if($lang == 'ar'){?>     
    <a href="<?php echo site_url();?>/ar"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo.png" alt="" class="img-fluid hmlogo"></a>
  
  <?php }else{ ?>
    <a href="<?php echo site_url();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo.png" alt="" class="img-fluid hmlogo"></a>

  <?php } ?>
   </div>
    <div class="col-lg-8">
      
 <?php
  if($lang == 'ar'){?>
  <div class="searchBox" style="padding-right:16px;">
  <form class="d-flex flex-wrap justify-content-between">

    <div class="col_1">
    <div class="form-group hmslectlistar hmslectArrowar">
    <select class="form-control" name="serv" id="serv" onchange="selBlogger();">
      <option><?php echo 'اختر الخدمة'; ?></option>
    <?php 
   
      $args = array(
        'taxonomy'   => "product_cat",
        'hide_empty' =>0,
      
    );
   $product_categories = get_terms($args);    
    foreach($product_categories as $cat) {
     if($cat->term_id != 15){?>
       <option value="<?php echo $cat->term_id ; ?>"><?php echo $cat->name ; ?></option>
    <?php }
    
     } ?>
    </select>
    </div>
   </div>

   <div class="col_1">
    <div class="form-group hmslectlistar hmslectArrowar" id="blogsel">
    <select class="form-control " name="blg" id="blg">
      <option><?php echo 'حدد المدون'; ?></option>

    </select>
    </div>
   </div>

<div class="col_2">
  <button type="button" class="btn SearchBtnar" onclick="selpage()"><?php echo 'بحث ';?></button>
</div>

</form>
</div>
 <?php }else{ ?>
  <div class="searchBox">
  <form class="d-flex flex-wrap justify-content-between">

<div class="col_1">
<div class="form-group hmslectlist hmslectArrow">
<select class="form-control" name="serv" id="serv" onchange="selBlogger();">
  <option>Select Service</option>
<?php 

  $args = array(
    'taxonomy'   => "product_cat",
    'hide_empty' =>0,
  
);
$product_categories = get_terms($args);    
foreach($product_categories as $cat) {
 if($cat->term_id != 15){?>
   <option value="<?php echo $cat->term_id ; ?>"><?php echo $cat->name ; ?></option>
<?php }

 } ?>
</select>
</div>
</div>

<div class="col_1">
<div class="form-group hmslectlist hmslectArrow" id="blogsel">
<select class="form-control" name="blg" id="blg">
  <option>Select Blogger</option>

</select>
</div>
</div>

<div class="col_2">
<button type="button" class="btn SearchBtn" onclick="selpage()">Search</button>
</div>

</form>
</div>
 <?php } ?>
  
  </div>
  </div>
  </div>

<div class="headMenu DeskShow">
<div class="container">
 
<?php if($lang == 'ar'){ ?> 

 <ul class="d-flex justify-content-center">
  <li class="active"><a href="<?php echo site_url();?>/ar/">مسكن</a></li>
  <li class="dropdown"><a href="<?php echo site_url();?>/ar/" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">خدمات </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/شريحة جوال"><?php echo 'شريحة جوال ';?> </a>
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/تأمين"><?php echo 'تأمين'; ?></a>
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/الحزم"><?php echo  'الحزم '; ?> </a>
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/سفر-المجموعات"><?php echo 'سفر المجموعات' ;?> </a>
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/اختبار-pcr"><?php echo 'اختبار PCR' ; ?></a>
      <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/خدمات-المطار"><?php echo 'خدمات المطار ' ;?> </a>
    </div>
  </li>
  <li <?php if($site == '/ar/كيف-تعمل/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/ar/كيف-تعمل"><?php echo 'كيف-تعمل'; ?></a></li>
  <li <?php if($site == '/ar/contact-us/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/ar/اتصل"  > <?php echo 'اتصل'; ?></a></li>  
  </ul>
<?php }else{ ?>
  <ul class="d-flex justify-content-center">
  <li class="active"><a href="<?php echo site_url();?>/">Home</a></li>
  <li class="dropdown"><a href="<?php echo site_url();?>/" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
    </div>
  </li>
  <li <?php if($site == '/how-it-works/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/how-it-works">How it works</a></li>
    <li <?php if($site == '/contact-us/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/contact-us"  >Contact</a></li>  
  </ul>


 <?php } ?>


 </div>
</div>
</header>
