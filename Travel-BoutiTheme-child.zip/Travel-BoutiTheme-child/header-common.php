<?php $lang = apply_filters( 'wpml_current_language', NULL ); ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> >

<head>
     <meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="google" value="notranslate">
	<?php wp_head(); ?>
 

  <!-- Favicons -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/images/favicon.png" rel="icon">
  <link href="imgages/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600&family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400;500;600;700&display=swap" rel="stylesheet">
 
  <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@100&display=swap" rel="stylesheet">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/jquery-ui.min.css" rel="stylesheet">
    <link href="<?php echo get_stylesheet_directory_uri();?>/css/owl.carousel.min.css" rel="stylesheet">
   <link href="<?php echo get_stylesheet_directory_uri();?>/css/custom.css" rel="stylesheet">
  <!-- Include following into your head tag
*******************************-->
<?php /*
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> */ ?>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
<style>
 p.counter-count{
     font-family: 'Teko', sans-serif;
    font-weight: 400;
    letter-spacing: 2px;
    text-transform: uppercase;
    font-size: 68px;
    line-height: 55px;
    display: inline-flex;
    margin-bottom: 0px;
    color:#333;
}


   
  </style>

<script type="text/javascript">
   $(document).ready(function() { 
  	var queryString = window.location.search;
  	var urlParams = new URLSearchParams(queryString);
	
  //	alert(queryString);
 // alert(localStorage.getItem('orderbgid'));
 // alert(localStorage.getItem('refcode'));
     
  if (localStorage.getItem('orderbgid') !== null){
     //	alert('orderbgidyes');
		//alert(localStorage.getItem('orderbgid'));
		$("#wdm_name").val(localStorage.getItem('orderbgid')) ;
 
   }else{
	  // alert('locabgnull');
 	    var page_type = urlParams.get('bgcode');
       // alert(page_type);
	  localStorage.setItem('orderbgid', page_type);
	//	alert(localStorage.getItem('orderbgid'));
		$("#wdm_name").val(localStorage.getItem('orderbgid')) ; 

   }

   if (localStorage.getItem('refcode') > 0){
	   // alert('locarefnullnot');
		//alert(localStorage.getItem('refcode'));
		$("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 
   }else{  
	   //  alert('locarefnull');
 	    var page_type2 = urlParams.get('refcode');
       // alert(page_type2);
		localStorage.setItem('refcode', page_type2);
   	//	alert(localStorage.getItem('refcode'));
		$("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 

    }
	
  });
  </script>
 
 




</head>

<body>
<?php $settingspost_id = '44826'; ?>
<?php $site = $_SERVER['REQUEST_URI']; 
//echo "urlreq" . $site;
  
?>
<header>
  <div class="topHeader DeskShow">
  <div class="container">
    <div class="row">
        <div class="col-lg-4">
          <p class="d-flex"> <i class="hmPhoneIcon"> </i><span><?php echo get_field('phone_number',$settingspost_id);?></span> <span class="pl-2 pr-2 hmtopseprt"> | </span> <i class="hmmailIcon"> </i><span><a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>"><?php echo get_field('email_link',$settingspost_id);?></a> </span></p>
        </div>
        <div class="col-lg-8">
        <?php if($lang == 'ar'){ ?> 
        
        <ul class="d-flex justify-content-end">    


          <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/globe.svg" alt=""> 
              <?php echo do_shortcode('[wpml_language_selector_widget]'); ?> 
          <a href="<?php echo site_url();?>/ar/cart/"><li><?php echo esc_html_e( 'عربة التسوق', 'twentytwentyone' ); ?></li></a>
          <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>/ar/">
          <li data-toggle="modal"><i class="hmSignInIcon"></i><span><?php echo esc_html__( 'خروج', 'twentytwentyone' );?></span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/ar/my-account/">
          <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/ar/my-account/"><?php echo esc_html__( 'تسجيل الدخول', 'twentytwentyone' );?></a></span></li>
          </a>
           <?php } ?> 
           <a href="<?php echo site_url();?>/ar/my-account/">
          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span><?php echo esc_html__( 'حسابي', 'twentytwentyone' );?></span></li> </a>

          </ul>
       <?php }else{ ?>
        <ul class="d-flex justify-content-end">    
        <img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/globe.svg" alt=""> 
            <?php echo do_shortcode('[wpml_language_selector_widget]'); ?> 
        <a href="<?php echo site_url();?>/cart/"><li><?php echo esc_html_e( 'Cart', 'twentytwentyone' ); ?></li></a>
        <?php if(is_user_logged_in()){?>
          <a href="<?php echo wp_logout_url( home_url() ); ?>/">
        <li data-toggle="modal"><i class="hmSignInIcon"></i><span><?php echo esc_html__( 'Sign Out', 'twentytwentyone' );?></span></li>
        </a>
        <?php } else { ?>
          <a href="<?php echo site_url();?>/my-account/">
        <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/my-account/"><?php echo esc_html__( 'Sign In', 'twentytwentyone' );?></a></span></li>
        </a>
        <?php } ?> 
        <a href="<?php echo site_url();?>/my-account/">

        <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span><?php echo esc_html__( 'My Account', 'twentytwentyone' );?></span></li> </a>
        </ul>
     <?php  }  ?>

        </div>
    </div>
  </div>
</div>

    <!-- Mobile Navigation -->
 <section class="mobileShow " id="wrapper">
  <a href="#" class="menu"><img src="<?php echo get_stylesheet_directory_uri();?>/images/mobmenu.png"></a>
</section>
  <nav class="slide-content">
    <div class="hmclose"><img src="<?php echo get_stylesheet_directory_uri();?>/images/hmclose.png"></div>
  <ul class="pt-2">
  <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>">
          <li data-toggle="modal" data-target=""><i class="hmSignInIcon"></i><span>Sign Out</span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/my-account/">
          <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/my-account/">Sign In</a></span></li>
          </a>
           <?php } ?> 
    <a href="<?php echo site_url();?>/my-account/">          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span>My Account</span></li> 
    </a>





    <li><a href="<?php echo site_url();?>/">Home</a></li>
    <li class="dropdown"><a href="" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
     <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
  </div>
    </li>
    <li <?php if($site == '/how-it-works/') {?> class = "active" <?php } ?>><a href="<?php echo site_url();?>/how-it-works/">How it works</a></li>
    <li <?php if($site == '/contact-us/') {?> class = "active" <?php } ?>><a href="<?php echo site_url();?>/contact-us"  >Contact</a></li>

  </ul>
</nav>
<div class="slide-fade"></div>
    <!-- Mobile Navigation close-->

   <div class="container">
    <div class="row headpad">
    <div class="col-lg-4 col-md-4 col-12">
    <?php
    if($lang == 'ar'){?>     
    <a href="<?php echo site_url();?>/ar"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo.png" alt="" class="img-fluid hmlogo"></a>
  
  <?php }else{ ?>
    <a href="<?php echo site_url();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo.png" alt="" class="img-fluid hmlogo"></a>

  <?php } ?>    </div>
    <div class="col-lg-8">

  </div>
  </div>
  </div>

<div class="headMenu DeskShow">
<div class="container">
<?php if($lang == 'ar'){ ?> 

<ul class="d-flex justify-content-center">
 <li class="active"><a href="<?php echo site_url();?>/ar/">مسكن</a></li>
 <li class="dropdown"><a href="<?php echo site_url();?>/ar/" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">خدمات </a>
   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/شريحة جوال"><?php echo 'شريحة جوال ';?> </a>
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/تأمين"><?php echo 'تأمين'; ?></a>
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/الحزم"><?php echo  'الحزم '; ?> </a>
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/سفر-المجموعات"><?php echo 'سفر المجموعات' ;?> </a>
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/اختبار-pcr"><?php echo 'اختبار PCR' ; ?></a>
     <a class="dropdown-item" href="<?php echo site_url();?>/ar/category/خدمات-المطار"><?php echo 'خدمات المطار ' ;?> </a>
   </div>
 </li>
 <li <?php if($site == '/ar/كيف-تعمل/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/ar/كيف-تعمل"><?php echo 'كيف-تعمل'; ?></a></li>
 <li <?php if($site == '/ar/contact-us/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/ar/اتصل"  > <?php echo 'اتصل'; ?></a></li>  
 </ul>
<?php }else{ ?>
 <ul class="d-flex justify-content-center">
 <li class="active"><a href="<?php echo site_url();?>/">Home</a></li>
 <li class="dropdown"><a href="<?php echo site_url();?>/" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services </a>
   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
     <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
     <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
     <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
     <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
     <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
     <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
   </div>
 </li>
 <li <?php if($site == '/how-it-works/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/how-it-works">How it works</a></li>
   <li <?php if($site == '/contact-us/') {?> class = 'active' <?php } ?>><a href="<?php echo site_url();?>/contact-us"  >Contact</a></li>  
 </ul>


<?php } ?>
 </div>
</div>
</header>
