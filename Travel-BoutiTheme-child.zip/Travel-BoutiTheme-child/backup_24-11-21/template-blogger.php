<?php
/**
 * Template Name: Blogger Listing  Page
 * ?>
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();      
  $settingspost_id = '58';?>
<section class="pt-4">
<div class="container">
  <div class="row ">

<div class="col-lg-12 col-12 order-2 order-lg-1 d-flex justify-content-center">
<div class="hmHeadings">
<h2 class="bloggerlist"> <?php echo "Bloggers"; ?> </h2>
</div>
</div>

</div>

<div class="row" style="padding-top:20px;">
 <?php
    global $wpdb;
    $tbl1 = $wpdb->prefix.'terms';
    $tbl2 = $wpdb->prefix.'termmeta';
    $tbl3 = $wpdb->prefix.'term_taxonomy';
    $qry ="select t.term_id as bgid,t.name as bgname,t.slug as vendurl,
           tm.term_id ,tm.meta_key,tx.description 
          from ".$tbl1. " t ,".$tbl2." tm , ".$tbl3." tx 
          where t.term_id = tm.term_id AND 
          tx.term_id = t.term_id AND 
          tx.taxonomy = 'yith_shop_vendor' AND
          tm.meta_key ='owner'";




    $results = $wpdb->get_results( $qry); 
    foreach($results as $result){   
       $thumbvendor_id = get_term_meta($result->bgid, 'avatar', true ); 
       $imagenow = wp_get_attachment_image_src( $thumbvendor_id, 'partner-size' ); 
      $inrry =$wpdb->get_row( $wpdb->prepare( "select tm.term_id ,tm.meta_value
            from ".$tbl2." tm 
            where tm.term_id = $result->bgid AND 
            tm.meta_key ='enable_selling' "));
               
       if($inrry->meta_value =='yes'){
 ?>
     <div class="col-lg-3 pr-1 pl-1">
      <div class="bloggerBox">
      <div class="bloggerPic d-flex justify-content-center">
      <?php if($imagenow[0]){ ?>
        <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>">
       <img src="<?php echo $imagenow[0];?>" alt="" ></a>
          <?php } else { ?>
      <img src="<?php echo site_url();?>/wp-content/uploads/no-blogger.png" alt="">
     <?php } ?>
       </div>
     <div class="bloggerDetails">
       <h3> <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>"><?php echo $result->bgname; ?></a></h3>
        <p> <?php echo limit_text($result->description,12) ;?> </p>
      </div>
      </div>
    </div>
    <?php } } ?>



</div>
</div>
</section>         
  <?php get_footer();
?>