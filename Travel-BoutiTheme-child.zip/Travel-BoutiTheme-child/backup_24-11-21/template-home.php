<?php
 /**
 * Template Name: Home Page
 */

    get_header();
    global $product;
     $settingspost_id = '58'; ?>


<section class="pt-4">
  <div class="container">
    <div class="row ">
<div class="col-lg-4 col-6">
  <img src="<?php echo get_stylesheet_directory_uri();?>/images/hmUmberla.png">
</div>
<div class="col-lg-4 col-12 order-2 order-lg-1 d-flex justify-content-center">
  <div class="hmHeadings">
  <h2> <?php echo get_field('home_content_first_section_label',$settingspost_id);?> </h2>
</div>
</div>
<div class="col-lg-4 col-6 order-1 order-lg-2 d-flex justify-content-end">
 <img src="<?php echo get_stylesheet_directory_uri();?>/images/hmCrossPic.png">
</div>
</div>

<div class="row">
   <?php
      global $wpdb;
      $tbl1 = $wpdb->prefix.'terms';
      $tbl2 = $wpdb->prefix.'termmeta';
      $tbl3 = $wpdb->prefix.'term_taxonomy';
      $qry ="select t.term_id as bgid,t.name as bgname,tm.term_id ,t.slug as vendurl,tm.meta_key,tx.description 
            from ".$tbl1. " t ,".$tbl2." tm , ".$tbl3." tx 
      where t.term_id = tm.term_id AND 
      tx.term_id = t.term_id AND 
      tx.taxonomy = 'yith_shop_vendor' AND
      tm.meta_key ='owner' limit 0,12";
     
      $results = $wpdb->get_results( $qry); 
      foreach($results as $result){   
         $thumbvendor_id = get_term_meta($result->bgid, 'avatar', true ); 
         $imagenow = wp_get_attachment_image_src( $thumbvendor_id, 'partner-size' ); 
        $inrry =$wpdb->get_row( $wpdb->prepare( "select tm.term_id ,tm.meta_value
              from ".$tbl2." tm 
              where tm.term_id = $result->bgid AND 
              tm.meta_key ='enable_selling' "));
                 
         if($inrry->meta_value =='yes'){
   ?>
       <div class="col-lg-2 pr-1 pl-1">
        <div class="bloggerBox">
        <div class="bloggerPic d-flex justify-content-center">
        <?php if($imagenow[0]){ ?>
          <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>">
         <img src="<?php echo $imagenow[0];?>" alt="" > </a>
            <?php } else { ?>
        <img src="<?php echo site_url();?>/wp-content/uploads/no-blogger.png" alt="">
       <?php } ?>
         </div>
       <div class="bloggerDetails">
         <h3>  <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>"><?php echo $result->bgname; ?></a></h3>
          <!--<p> <?php //echo limit_text($result->description,12) ;?> </p>-->
        </div>
        </div>
      </div>
      <?php } } ?>

<div class="col-lg-12 d-flex justify-content-center pt-4">
 <a href="<?php echo get_field('home_content_first_section_view_more_link',$settingspost_id);?>"><button class="btn moreButton"><?php echo get_field('home_content_first_section_view_more_link_text',$settingspost_id);?></button>
</a>

</div>

</div>
</div>
</section>
<section class="hmAbout pt-5">
  <div class="container">
    <div class="row">
   <div class="col-lg-12">
   <?php echo get_field('home_content_second_section_heading',$settingspost_id);?>
    <?php
      $abt_postid = get_field('about_us_page_link',$settingspost_id);
      $content_post = get_post($abt_postid);
      $content = $content_post->post_excerpt; ?>
    <p class="aboutInertext">
       <?php echo $content; ?>
   </div>
<div class="col-lg-3 col-6 aboutBdr counter">
  <div class="aboutDtls count-up">
  <h1><p class="counter-count">57</p>  <i class="aboutCountryicon"></i></h1>
  <p>countries  </p>
</div>
</div>
<div class="col-lg-3 col-6 aboutBdr">
  <div class="aboutDtls">
  <h1><p class="counter-count">2</p>K <i class="aboutDesticon"></i></h1>
  <p>destinations  </p>
</div>
</div>
<div class="col-lg-3 col-6 aboutBdr">
  <div class="aboutDtls">
  <h1><p class="counter-count">269</p> <i class="abouthappyClnticon"></i></h1>
  <p>HAPPYCLIENTS  </p>
</div>
</div>
<div class="col-lg-3 col-6">
  <div class="aboutDtls">
  <h1><p class="counter-count">25</p> <i class="aboutteamicon"></i></h1>
  <p>TEAM MEMBERS  </p>
</div>
</div>
   </div>
  </div>
</section>
<section class="addBg">
  <div class="container">
  <div class="owl-carousel" id="hmaddSlider">
  <?php
      $args = array( 'post_type' => 'sidead', 'orderby'=>'menu_order', 'order' => 'ASC' ); 
      $loop = new WP_Query( $args );   
      while ( $loop->have_posts() ) : $loop->the_post(); ?>
      <div class="item">
         <img src="<?php the_field('side_ad_image');?>">
      </div>
     <?php endwhile; ?>
   </div>
  </div>
</section>
 <?php echo hand_picked_deals(); ?>
 <?php get_footer(); ?>