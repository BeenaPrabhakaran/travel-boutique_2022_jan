<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header('common');
$lang = apply_filters( 'wpml_current_language', NULL );
?>
 <?php 
    if ( have_posts() ) {?>
     	<h1 class="page-title">
			<?php
			printf(
				/* translators: %s: Search term. */
				esc_html__( 'Results for "%s"', 'twentytwentyone' ),
				'<span class="page-description search-term">' . esc_html( get_search_query() ) . '</span>'
			);
			?>
		</h1> 
<?php
    if($lang == 'ar'){?>
	<section class="pt-4 arabisearch" style="min-height:400px;">
  <?php }else{ ?>
    <section class="pt-4" style="min-height:400px;">
	<?php } ?>
  <div class="container">
   <div class="row">
	   <div>
     <?php
		printf(
			esc_html(
				/* translators: %d: The number of search results. */
				_n(
					'We found %d result for your search.',
					'We found %d results for your search.',
					(int) $wp_query->found_posts,
					'twentytwentyone'
				)
			),
			(int) $wp_query->found_posts
		);
		?>
		</div>
		<?php
            while ( have_posts() ) {
				the_post();
		
				get_template_part( 'template-parts/content/content-excerpt', get_post_format() );
			} // End the loop.
		
			// Previous/next page navigation.
			twenty_twenty_one_the_posts_navigation();

          ?>
      </div>
   </div>
</section>
<?php 
	} else {?>
   <?php
    if($lang == 'ar'){?>
	<section class="pt-4 arabisearch" style="min-height:400px;">
  <?php }else{ ?>
    <section class="pt-4" style="min-height:400px;">
	<?php } ?>



	
	  <div class="container">
		<div class="row">
	    <?php	get_template_part( 'template-parts/content/content-none' ); ?>
		</div>
	  </div>
	</section>


<?php 	}
   get_footer('common'); ?>
