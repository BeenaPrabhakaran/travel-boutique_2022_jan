<?php
/**
 Template Name: How it Works
 *
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 ** @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header(); ?>
    <!-- banner -->
	<?php $bg_image = get_field('banner_image');?>
	<section class="serbanner" <?php if( !empty($bg_image) ): echo 'style="background-image: url(' . $bg_image['url'] . ');"'; endif; ?>>
		<div class="w-100 h-100 d-table">
			<div class="d-table-cell align-bottom">
                <div class="container">
			       <div class="row">
			            <div class="col-md-12 col-lg-12">
				     		<h1 style="padding: 50px 0; color:#410161;"><?php the_title(); ?></h1>
							
				        </div>
			        </div>
		        </div>
		    </div>
		</div>
	</section>
	<!-- end -->
	<!-- content -->
	<section class="about-us content-block">
		<div class="container">
			<div class="row">
				<div class="col-lg-5 ">
				 	<div class="w-100 h-100 d-table">
						<div class="abt-mid align-middle">
				 		   <?php the_post_thumbnail(); ?>
				 	    </div>
				 	</div>
				</div>
				<div class="col-lg-7 ">
				 	<div class="w-100 h-100 d-table">
						<div class="d-table-cell align-middle">
								<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
								the_content();
								endwhile; else: ?>
								<p >Sorry, no posts matched your criteria.</p>
								<?php endif; ?>
							</div>
						</div>
				 	</div>
				</div> 
		</div>
	</section>
	
<style type="text/css">
.serbanner{
    position: relative;
    top: -5px;
    background-repeat: no-repeat;
    background-position: center center;
    background-size: cover;
    width: 100%;
}
.about-us{
   margin-top:70px; 
}
.about-us h3, h2{
    font-size: 28px;
    color: #410161 !important;
    text-transform:uppercase;
}
</style
<?php


get_footer();

?>