<?php
 /**
 * Template Name: Home Page
 */
    get_header();
    global $product;
     $settingspost_id = '58'; ?>
<script type="text/javascript">
  $(document).ready(function() {
    var ids = localStorage.getItem('bloggershown');    
   
     var lan = $("#lang").val();
    // alert(lan);
   if(ids){
    // alert('id present');
       var bgname = localStorage.getItem('bloggershown');
     
       var bgs  = JSON.parse(bgname);     
        $.ajax({
             type:'POST',
             data:{"action":"homeblogshowload","showedblogids": bgs,"lang": lan},          
             url: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
             success: function(data) {          
            //  alert(data);   
              $("#showbloggerresult").html(data);    
              }
           });
    }else{
   
         var bgname = '0';
         //alert(bgname);
        // alert('id not present');
        $.ajax({
             type:'POST',
             data:{"action":"homeblogshow","lang": lan},          
             url: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
             success: function(data) {    
              //alert(data);    
               $("#showbloggerresult").html(data);         

              }

           });
     
       }

  });
</script> 
<script type="text/javascript">
 function storeids(idss) {  
    var ids = idss; 
     localStorage.setItem('bloggershown', JSON.stringify(ids));
    }
    function destroyids(){    
        localStorage.removeItem('bloggershown');

    }
 </script>  
 <?php 
    $lang = apply_filters( 'wpml_current_language', NULL); 
    // echo $lang . 'lang' ;
    
    ?>
<section class="pt-4">
  <div class="container">
    <div class="row ">
<div class="col-lg-4 col-6">
  <img src="<?php echo get_stylesheet_directory_uri();?>/images/hmUmberla.png">
</div>
<div class="col-lg-4 col-12 order-2 order-lg-1 d-flex justify-content-center">
  <div class="hmHeadings">
   
  <?php if($lang == 'ar'){ ?>
  <h2> <?php echo get_field('home_content_first_section_label_arabic',$settingspost_id);?> </h2>
  <?php }else{?>
    <h2> <?php echo get_field('home_content_first_section_label',$settingspost_id);?> </h2>
  <?php } ?>
   

</div>
</div>
<div class="col-lg-4 col-6 order-1 order-lg-2 d-flex justify-content-end">
 <img src="<?php echo get_stylesheet_directory_uri();?>/images/hmCrossPic.png">
</div>
</div>
<div class="row" id="showbloggerresult">
  <!-- blogger result -->
</div>
<div class="col-lg-12 d-flex justify-content-center pt-4">
<?php if($lang == 'ar'){ ?>
 <a href="<?php echo get_field('home_content_first_section_view_more_link_arabic',$settingspost_id);?>">
 <button class="btn moreButton">
   <?php   echo get_field('home_content_first_section_view_more_link_text_arabic',$settingspost_id);?>
   </button>
</a>    
   <?php  } else{ ?>
    <a href="<?php echo get_field('home_content_first_section_view_more_link',$settingspost_id);?>">
    <button class="btn moreButton">
      <?php  echo get_field('home_content_first_section_view_more_link_text',$settingspost_id);?>
      </button>
    </a>   
  <?php } ?>

</div>
</div>
</section>
<section class="hmAbout pt-5">
  <div class="container">
    <div class="row">
   <div class="col-lg-12">
   <?php 
     if($lang == 'ar'){
        echo get_field('home_content_second_section_heading_arabic',$settingspost_id);
     } else{
      echo get_field('home_content_second_section_heading',$settingspost_id);
     }
      $abt_postid = get_field('about_us_page_link',$settingspost_id);
      $content_post = get_post($abt_postid);
      $content = $content_post->post_excerpt; ?>
    <p class="aboutInertext">
       <?php echo $content; ?>
   </div>
<div class="col-lg-3 col-6 aboutBdr counter">
  <div class="aboutDtls count-up">
  <h1><p class="counter-count">57</p>  <i class="aboutCountryicon"></i></h1>
  <?php if($lang == 'ar'){ ?>
    <p> <?php echo 'الدول'; ?> </p>
  
 <?php }else{ ?> <p>countries  </p> <?php } ?>
</div>
</div>
<div class="col-lg-3 col-6 aboutBdr">
  <div class="aboutDtls">
  <h1><p class="counter-count">2</p>K <i class="aboutDesticon"></i></h1>
  <?php if($lang == 'ar'){ ?>
    <p> <?php echo 'الأماكن' ; ?> 
 <?php }else{ ?> <p>destinations  </p> <?php } ?>

</div>
</div>
<div class="col-lg-3 col-6 aboutBdr">
  <div class="aboutDtls">
  <h1><p class="counter-count">269</p> <i class="abouthappyClnticon"></i></h1>
   <?php if($lang == 'ar'){ ?>
    <p> <?php echo 'عملاء سعداء' ; ?>
 <?php }else{ ?> <p>HAPPYCLIENTS  </p> <?php } ?>
</div>
</div>
<div class="col-lg-3 col-6">
  <div class="aboutDtls">
  <h1><p class="counter-count">25</p> <i class="aboutteamicon"></i></h1>
 <?php if($lang == 'ar'){ ?>
    <p> <?php echo 'أعضاء الفريق'  ; ?> 
 <?php }else{ ?> <p>TEAM MEMBERS  </p> <?php } ?>
</div>
</div>
   </div>
  </div>
</section>
<section class="addBg">
  <div class="container">
  <div class="owl-carousel" id="hmaddSlider">
  <?php
      $args = array( 'post_type' => 'sidead', 'orderby'=>'menu_order', 'order' => 'ASC' ); 
      $loop = new WP_Query( $args );   
      while ( $loop->have_posts() ) : $loop->the_post(); ?>
      <div class="item">
         <img src="<?php the_field('side_ad_image');?>">
      </div>
     <?php endwhile; ?>
   </div>
  </div>
</section>
 <?php echo hand_picked_deals(); ?>
 <?php get_footer(); ?>