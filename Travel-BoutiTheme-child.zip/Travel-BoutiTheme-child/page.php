<?php
  /*get_header();

while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/content/content-page' );

	// If comments are open or there is at least one comment, load up the comment template.
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
endwhile; // End of the loop.

get_footer();*/ ?>
<?php
 /**
 * Template Name: Home Page
 */

    get_header('common');
    global $product;
     $settingspost_id = '58'; ?>


<section class="pt-4" style="min-height:400px;">
  <div class="container">
   <div class="row">
       <?php
        while ( have_posts() ) :
			the_post();
			get_template_part( 'template-parts/content/content-page' );
		
			// If comments are open or there is at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		endwhile; // End of the loop.

      ?>
      </div>
   </div>
</section>


 <?php get_footer('common'); ?>