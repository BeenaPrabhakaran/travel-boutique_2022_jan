<?php

define( 'WCML_MULTI_CURRENCIES_DISABLED', 0 );
define( 'WCML_MULTI_CURRENCIES_PER_LANGUAGE', 1 ); // obsolete - migrate to 2.
define( 'WCML_MULTI_CURRENCIES_INDEPENDENT', 2 );

define( 'WCML_TRANSLATION_METHOD_MANUAL', 0 );
define( 'WCML_TRANSLATION_METHOD_EDITOR', 1 );

define( 'WCML_CART_CLEAR', 0 );
define( 'WCML_CART_SYNC', 1 );

define( 'WCML_JS_MIN', defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' );
