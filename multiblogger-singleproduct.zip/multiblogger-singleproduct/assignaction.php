<?php
//require(__DIR__ . '/wp-blog-header.php');
require_once( dirname( dirname( dirname( dirname(__FILE__)))).'/wp-load.php');
$t=time();
$ti = date("Y-m-d",$t);
global $wpdb;

$table  = $wpdb->prefix.'blogger_product';
$table2 = $wpdb->prefix.'term_relationships';
if($_POST['save']){
extract($_POST);

echo $selaction;




/*foreach($prodsel as $sel){
    global $wpdb;










    $qry2 ="SELECT bpid FROM "
        .$table. " WHERE product_id = " . $sel. " AND blogger_id = " . $blogger ;

    $results2 = $wpdb->get_results( $qry2); 
    $rowcount = count( $results2  ); //PHP count()
   if($rowcount == 0){  
    $wpdb->insert( 
        $table, 
        array( 
            'product_id' =>  $sel, 
            'blogger_id' => $blogger ,
            'bp_status'=> $selaction,
            'time'=>$ti
        ), 
        array( 
            '%d', 
            '%d',
            '%d',
            '%s'

        ) 
     ); 

     //$vendor_id = intval($blogger);
    // wp_set_object_terms( $sel, $vendor_id, 'WC_PRODUCT_VENDORS_TAXONOMY' );


    
   }else{ 

       
       $wpdb->update( 
        $table, 
        array( 
            'bp_status' => $selaction
        ), 
        array( 'blogger_id' => $blogger , 'product_id' => $sel )
       );




    } 

  }
 // https://localhost/travel-boutique/wp-admin/admin.php?page=assign-products
 //header("Location .admin_url?page=assign-products") ;
 header("Location: https://3.234.242.230/travel-boutique-beta/wp-admin/admin.php?page=assign-products");*/
} 
 
?>

