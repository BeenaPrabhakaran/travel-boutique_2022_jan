<?php
  global $wpdb;
 $charset_collate = $wpdb->get_charset_collate();
 $table_name = $wpdb->prefix .'blogger_product';
$sql = "CREATE TABLE $table_name (
  bpid bigint(20) NOT NULL AUTO_INCREMENT, 
  product_id bigint(20),
  blogger_id bigint(20),
  bp_status  tinyint(1),
  time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
  PRIMARY KEY  (bpid)
) $charset_collate;";
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
?>