<?php
/** 
Plugin Name:Multiblogger Single Product Assign
Plugin URI:http://travel-blogue.com
Description:Assign a single product to more than one bloggers
Version:1.0.0
Author:Admin Nextgencia
Author URI:http://travel-blogue.com
*/
function installer(){ // db create table
    include('installer.php');
}
register_activation_hook(__file__, 'installer');

add_action('admin_menu', 'blogger_product_menu'); // adding admin side menu
function blogger_product_menu(){
    global $current_user;
    $user_id = get_current_user_id();
    if($user_id =='1'){
  // $my_page = add_menu_page( 'Blogger List', 'Blogger List', 'manage_options', 'blogger-list', 'blogger_list' );
   $my_page2 = add_menu_page( 'Assign Prodcut To Blogger', 'Assign Prodcut To Blogger', 'manage_options', 'assign-products', 'assign_products' );
   $my_page3 = add_menu_page( 'Add Commission To Blogger', 'Add Commission To Blogger', 'manage_options', 'add-commission', 'add_commission' );
   $my_page4 = add_menu_page( 'View Commission', 'View Commission', 'manage_options', 'view-commission', 'view_commission' );
   $my_page5 = add_menu_page( 'Approve Reviews', 'Approve Reviews', 'manage_options', 'approve-review', 'approve_review' );
        //add_action( 'load-' . $my_page, 'add_multiblogger_css_files' );
       // add_action( 'load-' . $my_page2, 'add_multiblogger_css_files' );
    
    
   } 
} 

function view_commission(){//include file for listing commission
    include('commission.php');;
}
function assign_products(){//include file for assigning proucts
    include('assign-products.php');
}

function add_commission(){
 include('blogcommission.php');

}
 function approve_review(){
     include('approvereview.php');
 }




 /*add_action('admin_print_styles','add_multiblogger_css_files');
 function add_multiblogger_css_files(){
  //wp_enqueue_script('your-script-name', $this->urlpath  . '/your-script-filename.js', array('jquery'), '1.2.3', true);
  // wp_enqueue_style( 'css2', plugins_url('/css/css2.css', __FILE__), false, '1.0.0', 'all'); 
     wp_enqueue_style( 'tailwind.output', plugins_url('/css/tailwind.output.css', __FILE__), false);
 }

  //wp_register_script( 'my_plugin_script', plugins_url('js/jquery.js', __FILE__), array('jquery'));
 
  //wp_enqueue_script( 'my_plugin_script' );
 */
?>