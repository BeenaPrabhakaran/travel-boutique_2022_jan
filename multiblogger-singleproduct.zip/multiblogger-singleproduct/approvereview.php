<!DOCTYPE html>
<!-- saved from url=(0038)https://windmill-dashboard.vercel.app/ -->
<html :class="{ &#39;theme-dark&#39;: dark }" x-data="data()" lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <body>
   <link href="<?php echo plugins_url();?>/multiblogger-singleproduct/css/tailwind.output.css" rel="stylesheet">
 <?php
  // Include alert.php file
    include_once 'assignaction.php';
  
 ?>
 <script type="text/javascript">

 function assignedproduct(){
  var re = jQuery.noConflict();
   var ab = re("#blogger").val();
   re.ajax({
          type:'POST',
          data:{"action":"bloggerproinfo","bgval":ab},       
          url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
          success: function(data) {   
            re("#bloginfodet").html(data);  
         
        }
     });    
 }

 function changeapproved(rowid){
  var ar = jQuery.noConflict();
  var rwid = rowid;
  var appr = ar("#revapprove"+rwid).val();
  //var rwid = ar("#rewid").val();

   ar.ajax({
          type:'POST',
          data:{"action":"chanereviewstatus","rowid":rwid,"sts":appr},       
          url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
          success: function(data) { 
          // alert(data);
             ar("#statusdiv").html('Review status changed');
             ar("#status"+rw).html(data);  
         
        }
     }); 
 } 
 </script> 
 <style>

.prsave{
    background-color: #000;
    color: #fff;
    padding: 5px;
    width: 95px;
    border-radius: 5%;
    /* margin-top: 14px; */
    vertical-align: bottom;
}
.prchk{
  text-align: center;
  vertical-align: middle;
}
.primg{
  text-align: center;
  vertical-align: middle;
}
.error{border:4px solid #d63638 !important;}

 </style>
   <div class="flex h-screen bg-gray-50 dark:bg-gray-900" :class="{ &#39;overflow-hidden&#39;: isSideMenuOpen }">
      <!-- Desktop sidebar -->

      <!-- Backdrop -->

<div class="flex flex-col flex-1 w-full">

  <main class="h-full overflow-y-auto">
    <div class="container px-6 mx-auto grid">
      <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
      &nbsp;
      </h2>
      <!-- CTA -->
      <a class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-purple-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple" >
        <div class="flex items-center">
          <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
          </svg>
          <span>List Of All Reviews</span>
        </div>

      </a>
      <!-- Cards -->
  <?php /*    <form  method="POST" action="<?php echo plugins_url('assignaction.php', __FILE__ ); ?>" > */ ?>
      <form  method="POST" >
   

         <!-- New Table -->
       
            <div class="w-full overflow-hidden rounded-lg shadow-xs" style="margin-top:20px;">
              <div class="w-full overflow-x-auto">
                <table class="w-full whitespace-no-wrap">
                  <thead>
                <div id="statusdiv" style="padding: 25px; font-size: 17px; color: red;"></div>
                <tr class="text-xs font-semibold tracking-wide text-left text-gray-500 uppercase border-b dark:border-gray-700 bg-gray-50 dark:text-gray-400 dark:bg-gray-800">
                    <th class="px-4 py-3">Product Name</th>
                    <th class="px-4 py-3">Name</th> 
                    <th class="px-4 py-3">Email</th>  
                    <th class="px-4 py-3">Review</th>  
                    <th class="px-4 py-3">Date</th>              
                    <th class="px-4 py-3">Status</th>
                </tr>
                </thead>
                <tbody class="bg-white divide-y dark:divide-gray-700 dark:bg-gray-800" id="bloginfodet"> 
             <?php 
             global $wpdb;
             $tblreview = $wpdb->prefix.'blogger_product_review';
             $tblpro    = $wpdb->prefix.'blogger_product';
             $apprarray = array('Approved','Not Approved');
             $qryrw ="select rev.*,p.product_id,p.bpid from " .$tblreview. " rev," .$tblpro. " p where
                      rev.bpid = p.bpid ";  
             $resrew = $wpdb->get_results($qryrw); 
             foreach($resrew as $res){ 
             
             ?>                     
               
              <tr class="text-gray-700 dark:text-gray-400">
              <td class="px-4 py-3" class="primg"><?php echo get_the_title($res->product_id) ;?>  
            
            </td>
              <td class="px-4 py-3" class="primg"><?php echo $res->bp_name ;?>   </td>
              <td class="px-4 py-3" class="primg"> <?php echo $res->bp_email ;?> </td>             
              <td class="px-4 py-3" class="primg"><?php echo $res->bp_pro_review ;?> </td>
              <td class="px-4 py-3" class="primg"> <?php echo $res->bp_date ;?> </td>             
              <td class="px-4 py-3" class="primg" id="status<?php echo $res->bg_prod_rewid;?>"> 
              <select name="revapprove" id="revapprove<?php echo $res->bg_prod_rewid;?>" onchange="changeapproved('<?php echo $res->bg_prod_rewid;?>');">
              <?php 
                foreach($apprarray as $app){
                 if($res->bp_status == $app){?>
                 <option value="<?php echo $app ;?>" selected><?php echo $app ;?></option>
                <?php }else{ ?>
                 <option value="<?php echo $app ;?>"><?php echo $app ;?></option>

              <?php }  }?>
              </select>
            </td>             
              </tr>
          
           <?php 
             }
           ?>

          </tbody>
        </table>
      </div>
    </form>   
  </div>


    </div>
  </main>
</div>
</div>
<script>
  function enbbut(){
    var ab = jQuery.noConflict();
    ab("#prsave").removeAttr("disabled");

  }
  function  addassignprod(){  
    var cd = jQuery.noConflict();
    var prodarray = [];
    var blogval     = cd('#blogger').val();
    var selaction   =  cd('#selaction').val();
    cd("input:checkbox[name=prodsel]:checked").each(function() {
          prodarray.push(cd(this).val());
        });
    cd.ajax({
              type:'POST',
              data:{"action":"assignproductsblog","blogid": blogval,"slact":selaction,"prodarr": prodarray},       
              url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
              success: function(data) {  
             //   alert(data);        
               cd("#result").html(data);
              window.location.reload();
              
            }		
          }); 

  }
</script>

</body></html>