<?php
class YITH_WISHLIST_API{
	protected $base='wc';

    function __construct(){
        add_action('rest_api_init',array($this, 'rentzon_register_routes'));
    }
    public function rentzon_register_routes(){
    	register_rest_route( $this->base, '/getuserwishlist', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_wishlist_for_user'),
          ) );
    	register_rest_route( $this->base, '/sliders', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_sliders'),
          ) );
    }
    public function rentzon_get_wishlist_for_user($args){
    	var_dump($args);
    	die();
    }

    public function rentzon_get_sliders(){
		$args = array(
		    'post_type' => 'sliders',
		    'posts_per_page' => 3,
		    'orderby'        => 'date',
			'order'          => 'ASC'
		);
		$data=[];
		$loop = new wp_Query($args);
		$i=1;
		if ( $loop->have_posts() ) :
			while($loop->have_posts()) : $loop->the_post();
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );
			$mobimage = get_post_meta( get_the_ID(), 'mobile_banner', true );
			$image_attributes = wp_get_attachment_url( $mobimage );
		$data[$i]['image']=$image[0];
		$data[$i]['mobile_image']=$image_attributes;	
		$i++;
		endwhile;
		endif;
    	return $data;	
    }
}

$general_api =new YITH_WISHLIST_API();
?>