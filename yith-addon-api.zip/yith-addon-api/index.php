<?php
/**
 * Plugin Name: Yith Vendor Addon API
 * Description: this plugin is to add  addon feature to the current woocommerce api
 * Author: VV
 */
  

if ( ! defined( 'YITH_WAPO' ) && !defined('WC_VERSION') ) {
	exit;
}
require_once( __DIR__ . '/vendor/autoload.php');
require_once( plugin_dir_path(__FILE__)."add-ons/index.php");
require_once( plugin_dir_path(__FILE__)."general/class.general.php");
require_once( plugin_dir_path(__FILE__)."wishlist/class.wishlist.php");
