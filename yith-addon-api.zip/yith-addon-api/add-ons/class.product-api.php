<?php
/**
 * @summary - this class is for adding add-ons to the product related api in woocomerce
 */
use Automattic\WooCommerce\Client;

class YITH_PRODUCT_WC_API{
   private $wc_client = '';
   protected $base='wc';
   protected $authenticated_base ='/jwt-auth/v1';
   private $consumer_key= 'ck_c589b701477fcaaa219fac12df635b68689133e6';
   private $consumer_secret= 'cs_81e9c51d9c7aec03b93923e48608716cf2b7044b';

    function __construct(){
        add_action('rest_api_init',array($this, 'rentzon_register_routes'));
    }
	
    public function rentzon_register_routes(){
        $this->wc_client = new Client(
            get_site_url(), 
            $this->consumer_key , 
            $this->consumer_secret
        );  
         register_rest_route( $this->base, '/products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'get_bookable_search_data'),
          ) );
		register_rest_route( $this->base, '/getprod', array(
            'methods' => 'POST',
            'callback' => array($this,'get_bookable_products'),
          ) );
		
		register_rest_route( $this->base, '/products', array(
              'methods' => 'POST',
              'callback' => array($this,'get_bookable_search_data'),
            ) );
		register_rest_route( $this->base, '/products', array(
              'methods' => 'GET',
              'callback' => array($this,'get_bookable_search_data'),
            ) );
		
		register_rest_route( $this->base, '/products/(?P<id>\d+)', array(
              'methods' => 'POST',
              'callback' => array($this,'get_bookable_search_data'),
            ) );
		
//          register_rest_route( $this->base, '/productslatest/(?P<id>\d+)', array(
//             'methods' => 'POST',
//             'callback' => array($this,'get_bookable_search_data_latest'),
//           ));
//           
          register_rest_route( $this->base, '/products/categories', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_product_categories'),
          ));
          register_rest_route( $this->base, '/products/categories/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_product_single_category'),
          ));
          register_rest_route( $this->base, '/product/available-time/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_product_available_time'),
          ));
          
          register_rest_route( $this->base, '/product/not-available-dates/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_product_not_available_dates'),
          ));
          
          register_rest_route( $this->base, '/product/total-cost/(?P<id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_get_all_totals'),
          ));
		  register_rest_route( $this->base, '/locations', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_locations'),
          ));
          register_rest_route( $this->base, '/users', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_create_customer'),
          ));
		  
		   register_rest_route( $this->base, '/product-reviews/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_product_review'),
          ));
		  
		  register_rest_route( $this->base, '/product-reviews', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_create_product_review'),
			
          ));
		register_rest_route( $this->base, '/getsubcategories/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_subcatgories'),
			
          ));
		register_rest_route( $this->base, '/get-related-products/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_related_products'),
			
          ));

    }
	
	public function get_bookable_products($args){
	  $order_by = isset($args['order_by'])?$args['order_by']:'date';
      $order    = isset($args['order'])?$args['order']:'DESC';
	  $min_price      = isset($args['min_price']) ? $args['min_price']:NULL;
      $max_price      = isset($args['max_price']) ? $args['max_price']:NULL;	
	  // search for booking details and get product ids
	  if(!isset($args['id'])):	
	  $search_params = array();
	  if(isset( $args[ 'date' ] ) && !empty($args[ 'date' ])):	
	  	$search_params['from'] =  $args[ 'date' ];
	  endif;
	  if(isset( $args[ 'search' ] ) && !empty($args[ 'search' ])):
	    $search_params['s'] =	$args[ 'search' ];
	  endif;
	  if(isset( $args[ 'category' ] ) && !empty($args[ 'category' ])):
	    $search_params['categories'] = $args[ 'category' ];
	  endif;
	  if(isset( $args[ 'sub_category' ] ) && !empty($args[ 'sub_category' ])):
		 $search_params['categories'] =	array($args[ 'sub_category' ]);
	  endif;	
	  $tags = isset( $args[ 'sublocation' ] ) ? $args[ 'sublocation' ] : array();
	  if(!!$tags){
		 $tags = $this->get_termids($tags);
		  $search_params['tags']  =$tags;
	 }	
	  if(isset( $args[ 'location' ] )):
	    $search_params['location'] =	$args[ 'location' ];
	  endif;
	  if(!empty($search_params)):		
	   $product_ids = YITH_WCBK()->search_form_helper->search_booking_products( $search_params );
	  endif;	
	  //return 	 $product_ids;
	  if(!empty($search_params) && empty($product_ids)):
		return new WP_REST_Response(array());
	  endif;	
	$query_args = array(
    	'post_type'           => 'product',
		'fields'               => 'ids',
    	'post_status'         => 'publish',
    	'ignore_sticky_posts' => 1,
		'no_found_rows'       => 1,
    	'posts_per_page'      => isset($args['per_page'])?$args['per_page']: -1,
    	'orderby'             => $order_by,
    	'order'               => $order == 'ASC' ? 'asc' : 'desc',
	);
	
	if($query_args['posts_per_page'] != -1):
		$query_args['paged'] = isset($args['page'])? $args['page']:1;
	endif;	
	// search for booking details and get product ids		
	  if(isset($args['featured'])): 	
	   $tax_query[] = array(
         'taxonomy' => 'product_visibility',
         'field'    => 'name',
         'terms'    => 'featured',
          'operator' => 'IN', // or 'NOT IN' to exclude feature products
       );
	 endif;
	 if(isset($args['flash_deal'])) :
         $meta_query[] = array(
             'key'     => 'flash_deal',
             'value'   => 1,
             'compare' => 'IN',
         );   
     endif;
    if(isset($args['exclude_ids'])):
		 $query_args['post__not_in' ]  = $args['exclude_ids'];
	endif;
		
	if($min_price || $max_price):	
	   if($min_price && !$max_price){
          $max_price =100000000000000;
        }
        if(!$min_price && $max_price){
             $min_price =1;
        }
	   $meta_query[] = array(
             'key' => '_price',
             'value' => array($min_price, $max_price),
             'compare' => 'BETWEEN',
             'type' => 'NUMERIC'
         );	
	 endif;	
	 if($order_by == 'popularity' || isset($args['best_sellers']) || isset($args['total_sales'])):
		$query_args['meta_key']  = 'total_sales';
  		$query_args['orderby']   = 'meta_value_num';
	 endif;
	 if($order_by == 'rating'):
		$query_args['meta_key']  = '_wc_average_rating';
  		$query_args['orderby']   = 'meta_value_num';
	 endif;
	if($order_by == 'price'):
		$query_args['meta_key']  = '_price';
  		$query_args['orderby']   = 'meta_value_num';
	endif;	
	if(isset($args['rating'])):
	  $product_visibility_terms = wc_get_product_visibility_term_ids();
	   $tax_query[]=array(
			'taxonomy'      => 'product_visibility',
			'field'         => 'term_taxonomy_id',
			'terms'         => array($product_visibility_terms[ 'rated-' . $args['rating'] ]),
			'operator'      => 'IN',
			'rating_filter' => true,
		);
    endif;	
	if(!empty($product_ids)):
	 $query_args['post__in']= $product_ids;
	endif;
	if(!empty($tax_query)):
	 $query_args['tax_query']= $tax_query;
	endif;
	if(!empty($meta_query)):
	 $query_args['meta_query']= $meta_query;
	endif;
	 	
	 $query = new WP_Query($query_args);
     $product_ids = $query->posts;
	 else:
	 $product_ids = array($args['id']); 	
	endif;	
	 $product_data=array();	
	 foreach ($product_ids as  $product_id) {
        $product_details= wc_get_product($product_id); 
        $attachment_ids = $product_details->get_gallery_image_ids();
        $main_image_id =$product_details->get_image_id();
		$gallery_images = array();
		$gallery_images[] = wp_get_attachment_url( $main_image_id );
		if(count($attachment_ids) > 0 ):  
			foreach( $attachment_ids as $attachment_id ) 
			 {
			   $gallery_images[] = wp_get_attachment_url( $attachment_id );
			 }  
		endif;  
        $pro =[];  
        $pro['name'] = html_entity_decode($product_details->get_title());
        $pro['id'] = $product_details->get_id();
		$pro['gallery_images'] = $gallery_images;  
        $pro['regular_price'] =  round(wc_get_price_to_display($product_details),3);
		$pro['has_persons'] =  $product_details->has_persons();
		$pro['duration'] =  html_entity_decode($product_details->get_duration()); 
		$pro['duration_unit'] =  html_entity_decode($product_details->get_duration_unit());
		// get date details
		$date_details =  yith_wcbk_get_booking_form_date_info($product_details, array());
		if(isset($date_details['default_start_date']) && $date_details['default_start_date'] != '' ):  
		$pro['default_date'] = $date_details['default_start_date'];
		$pro['default_time'] = $product_details->get_default_start_time(); 
		endif;   
		$is_fixed_blocks     = $product_details->is_type_fixed_blocks();
		$min = $product_details->get_minimum_duration();
		$max = $product_details->get_maximum_duration();
		$checkin_time =  $product_details->get_check_in();
		$checkout_time =  $product_details->get_check_out();
		$pro['check_in_time'] = !! $checkin_time ? $checkin_time : null;
		 $pro['check_out_time'] = !! $checkout_time ? $checkout_time : null;
		$show_duration_field = !$is_fixed_blocks && $min !== $max;	
        $pro['show_duration_field'] =  $show_duration_field;
        if($show_duration_field):
		   $pro['duration_min'] = $min;
		   $pro['duration_max'] = $max;
        endif;
        $pro['duration_number'] =   $show_duration_field ? $pro['duration'] : ( $pro['duration'] * $min );	
        $pro['duration_label'] = html_entity_decode(yith_wcbk_get_product_duration_label( $pro['duration_number'], $pro['duration_unit'], !$show_duration_field ));		
		if($pro['has_persons']):
		  $pro['min_persons'] =  $product_details->get_minimum_number_of_people();
		  $pro['max_persons']= $product_details->get_maximum_number_of_people();
		endif;
        $pro['sale_price'] =  $product_details->get_sale_price();
        $pro['image'] =  wp_get_attachment_image_src( get_post_thumbnail_id( $pro['id'] ), 'thumbnail' )[0];
        $pro['review_count'] =$product_details->get_review_count();
        $pro['rating'] =$product_details->get_average_rating();
		//$pro['rating_html'] =wc_get_rating_html( $product_details->get_average_rating() );
        $pro['stock_status'] = $product_details->get_stock_status();
        $pro['description'] = html_entity_decode(wp_strip_all_tags($product_details->get_description()));
        $pro['short_description'] =html_entity_decode( wp_strip_all_tags($product_details->get_short_description()));
        $pro['categories'] = wp_strip_all_tags($product_details->get_categories());
        $pro['category_ids'] = $product_details->get_category_ids();
		$datetime_created  = $product_details->get_date_created(); // Get product created datetime
		$timestamp_created = $datetime_created->getTimestamp();
		$pro['location'] = get_post_meta($pro['id'],'_yith_booking_location',true);
		$pro['created'] = $datetime_created;
		$pro['created_date'] = $timestamp_created;  
		$pro['total_sales'] = $product_details->get_total_sales();
        $vendor = YITH_Vendor::retrieve($product_id,'product');
        $pro['vendor_id'] = $vendor->id;
        $pro['vendor_name'] = $vendor->name;
        $product_data[] = $pro;
      }	
	return $product_data;		
	}
	
	/*
    * @summary - GET related products
    */
    public function rentzon_get_related_products($args){
        $limit=isset($args['limit']) ? $args['limit'] : -1;
        try{
         if(!isset($args['id'])){
             throw new Exception('Product id is required');
         }
         $product = wc_get_product($args['id']);
          if(!$product){
            throw new Exception('Product not found'); 
         }
        $d = $product->get_upsell_ids( 'edit' );
         $related_products= array();
    
         if(!empty($d)):
         
          foreach($d as $product_id):
            $data = array('id'=> $product_id);
            $prod=$this->get_bookable_search_data($data);
            if(is_array($prod) && !empty($prod)):
                $related_products[]= $prod[0];
            endif;
          endforeach;  
         endif;
           return new WP_REST_Response($related_products,200); 
        } catch (Exception $error) {
          return new WP_Error('PRODUCT_ERROR' ,$error->getMessage(), array( 'status' => 400 )); 
        }
            
    }
	
	
    /*
    *Get available-dates for a product
    */
    
    public function rentzon_get_product_not_available_dates($args){
      try{
         if(!isset($args['id'])):
           throw new Exception("Product id is required");
         endif;       
          $product = wc_get_product($args['id']);
          $date_info_args=array();
          if ( !empty( $args[ 'month_to_load' ] ) && !empty( $args[ 'year_to_load' ] ) ) {
                        $month_to_load  = $args[ 'month_to_load' ];
                        $year_to_load   = $args[ 'year_to_load' ];
                        $start          = "$year_to_load-$month_to_load-01";
                        $date_info_args = array( 'start' => $start );
               }
          $date_info = yith_wcbk_get_booking_form_date_info( $product, $date_info_args );
          $response = array(
                  'not_available_dates' => $product->get_not_available_dates( $date_info[ 'current_year' ], $date_info[ 'current_month' ], $date_info[ 'next_year' ], $date_info[ 'next_month' ], 'day' ));
          
          return $response;
        // return $response->not_available_dates;
       } 
       catch (Exception $error){
        return new WP_Error($error->code ,$error->message, $error->data );
       } 
    }
    /*
    * GET total cost in the cart
    */
    
    public function rentzon_get_all_totals($args){
      $request = array();
      try{
        if(!isset($args['id'])):
          throw new Exception("product id is required");
        endif;
        $request['product_id'] = $args['id'];
        if(!isset($args['datetime'])):
          throw new Exception("From time is required");
        endif;
        $request['from'] = $args['datetime'];
        if(isset($args['duration'])):
          $request['duration'] = $args['duration'];
        endif;
        if(isset($args['to'])):
          $request['to'] = $args['to'];
        endif;
        if(isset($args['persons'])):
          $request['persons'] = $args['persons'];
        endif;
        
        if(isset($args['person_types'])):
          $request['person_types'] = $args['person_types'];
        endif;
        
        if(isset($args['addons'])):
           
          $addon_cost = $this->calculte_addons_cost($args['addons'], $args['id']);
        endif;
         $product_cost = $this->rentzon_get_product_total_cost($request);
         $product_cost['addon_cost'] = $product_cost['is_available'] ? round($addon_cost,3) : null;
          $product_cost['total_cost'] = $product_cost['is_available'] ? round(($product_cost['product_price'] + $addon_cost),3) : null;
		  
         return $product_cost;
        
      } catch (Exception $error) {

        return new WP_Error('400' ,$error->getMessage, $error->data );   
      }
           
    }
    
    
    public function calculte_addons_cost($addons ,$product_id = 0){
        $cost = 0;
        if (is_array($addons)) :
         foreach ($addons as  $addon):
           $addon['product_id'] = $product_id;
           $addon['option_value'] = $addon['value'];
           $addon['product_price'] = wc_get_product($product_id)->get_price();
           $cost =$cost + $this->calculate_single_addon_cost($addon);
         endforeach;
        endif;
        return $cost;
    }
    
    
    public function calculate_single_addon_cost($addon){

        if ( ! isset( $addon['product_id'] ) || ! isset( $addon['product_price'] ) || ! isset( $addon['type_id'] ) || ! isset( $addon['option_index'] ) ) {
				return 0;
			}

			$product_id = intval( $addon['product_id'] );

			if ( $product_id > 0 ) {

				$type_id = intval( $addon['type_id'] );

				$product = wc_get_product( $product_id );

				$product_price = floatval( $addon['product_price'] );

				if ( is_object( $product ) && $type_id > 0 && $product_price > 0 ) {

					$single_group_type = YITH_WAPO_Type::getSingleGroupType( $type_id );

					if ( is_array( $single_group_type ) ) {
						$single_group_type = $single_group_type[0];
					}

					if ( is_object( $single_group_type ) ) {

						$option_index = $addon['option_index'];

						if ( $option_index >= 0 ) {

							$options = $single_group_type->options;
							$options = maybe_unserialize( $options );

							if ( is_array( $options ) ) {
                                $yith_frontend = new YITH_WAPO_Frontend('2.0.0'); 
								$price            = $options['price'][ $option_index ];
                               
								$price_type       = $options['type'][ $option_index ];
								$value            = isset( $addon['option_value'] ) ? $addon['option_value'] : null;
								$price_calculated = $yith_frontend->get_display_price( $product, $price, $price_type, true, null, $product_price, $value );
								return floatval($price_calculated);
							}
						}
					}
				}

			}

    } 
    
    
    /*
    * Calculate product cost
    */
    
    public function rentzon_get_product_total_cost($request){
           $booking_data = false;
            $request      = is_array( $request ) ? $request : $_POST;

            $request      = apply_filters( 'yith_wcbk_ajax_booking_data_request', $request );

            if ( empty( $request[ 'product_id' ] ) || empty( $request[ 'from' ] ) || ( empty( $request[ 'duration' ] ) && empty( $request[ 'to' ] ) ) ) {

                $booking_data = array( 'error' => _x( 'Required POST variable not set', 'Error', 'yith-booking-for-woocommerce' ) );

            } else {

                $date_helper = YITH_WCBK_Date_Helper();
                $product_id  = $request[ 'product_id' ];
                /** @var WC_Product_Booking $product */
                $product = wc_get_product( $product_id );


                if ( $product ) {
                    $from = strtotime( $request[ 'from' ] );
                    if ( isset( $request[ 'to' ] ) ) {
                        $to = strtotime( $request[ 'to' ] );
                    } else {
                        $duration = absint( $request[ 'duration' ] ) * $product->get_duration();
                        if ( $product->is_full_day() ) {
                            $duration -= 1;
                        }
                        $to = $date_helper->get_time_sum( $from, $duration, $product->get_duration_unit() );
                    }


                    $is_available_args = YITH_WCBK_Cart::get_booking_data_from_request( $request );
                    $is_available_args = apply_filters( 'yith_wcbk_product_form_get_booking_data_available_args',
                                                        $is_available_args,
                                                        $product,
                                                        $request );

                    $is_available_args[ 'return' ] = 'array';

                    $availability = $product->is_available( $is_available_args );
                    $is_available = $availability[ 'available' ];

                    $bookable_args = array(
                        'product'               => $product,
                        'bookable'              => $is_available,
                        'from'                  => $from,
                        'to'                    => $to,
                        'non_available_reasons' => $availability[ 'non_available_reasons' ]
                    );
                    
                    if ( $is_available ) {
                        $show_totals = YITH_WCBK()->settings->show_totals();
                        $totals      = $product->calculate_totals( $request, $show_totals );
                        $price       = $product->calculate_price_from_totals( $totals );
                        $price       = apply_filters( 'yith_wcbk_booking_product_calculated_price', $price, $request, $product );
                    } else {
                        $totals      = array();
                    }

                    $booking_data = array(
                        'is_available' => $is_available,
                        'product_price'  => round($price,3),
                    );

                    $booking_data = apply_filters( 'yith_wcbk_product_form_get_booking_data', $booking_data, $product, $bookable_args, $request );
                }
            }

            if ( !$booking_data ) {
                $booking_data = array( 'error' => _x( 'Product not found', 'Error', 'yith-booking-for-woocommerce' ) );
            }
            
         return $booking_data;   
       
    }
	
	public function rentzon_get_subcatgories($request){
       $parent_id =$request->get_param('id');
	   $args = array(
			'hierarchical' => 1,
			'show_option_none' => '',
			'hide_empty' => 0,
			'parent' => $parent_id,
			'taxonomy' => 'product_cat'
		);
		$subcats = get_categories($args);
	    $results = array();
		if(is_array($subcats)):
		  foreach($subcats as $subcat):
		     $thumbnail_id = get_term_meta( $subcat->term_id, 'thumbnail_id', true ); 
             $image = wp_get_attachment_url( $thumbnail_id ); 
		    $results[]= array('name' => $subcat->name, 'id'=> $subcat -> term_id, 'image' => $image);
		  endforeach;
		endif;
		return $results;
	}
	
	public function rentzon_create_product_review($request){
        try{  
		  $args['product_id'] = $request['product_id'];	
		  $args['review'] = $request['review'];	
		  $args['reviewer'] = $request['reviewer'];	
		  $args['reviewer_email'] = $request['reviewer_email'];	
		  $args['rating'] = $request['rating'];	
		  $args['status'] = 'hold';		
		  $review = $this->wc_client->post('products/reviews/',$args);		
		  if(!is_array($review)):
		    $review = array();
		  endif;	
		  return new WP_REST_Response(array('Successfully added the review'), 200);	
			
        }
        catch(Exception $err){
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }

        return $review;
	}
	
	/*GET PRODUCT REVIEW*/
	public function rentzon_get_product_review($request){
		$results=array();
		$id= absint($request->get_param('id'));
		$number = null !=$request->get_param('per_page') ? $request->get_param('per_page'): 4;
		$page = null !=$request->get_param('page') ? $request->get_param('page'): 1;
		$offset = null !=$request->get_param('offset') ? $request->get_param('offset'): 0;
		$args = array ('post_id' => $id, 'number' => $number, 'paged' => $page,'status' => 'approve');
		$comments = get_comments( $args );
        try{
		if($comments):
         foreach($comments as $key => $comment): 
          $review = $this->wc_client->get('products/reviews/'.absint($comment->comment_ID));
		  if($review->rating):
		   $results[$key]['rating'] = $review->rating; 
		  endif;
		  if($review->reviewer):
		   $results[$key]['reviewer'] = $review->reviewer; 
		  endif;
		  if($review->reviewer_avatar_urls):
		   $results[$key]['reviewer_url'] = $review->reviewer_avatar_urls; 
		  endif;
		  if($review->review):
		   $results[$key]['review'] = wp_strip_all_tags($review->review); 
		  endif;
		  if($review->date_created):
		   $results[$key]['date_created'] = $review->date_created; 
		  endif;
		 endforeach; 
		   
		endif;
        }
        catch(Exception $err){
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }

        return $results;
	}
	
	
	/* Get all locations in the required regions */
	
	public function rentzon_get_locations(){
       try{  
	  $result = wp_remote_get('https://countriesnow.space/api/v0.1/countries');	
	  if($result['response']['code'] != 200){
		 throw new Exception('Citites not found'); 
	  }
	  
	  $countries_data= json_decode($result['body'])->data;
	  $required_data=['United Arab Emirates','Saudi Arabia','Qatar','Kuwait'];
	  $cities=[];
	  foreach($countries_data as $country_data):
	    if(in_array($country_data->country, $required_data)):
		  $cities_countries = array() ;
		  foreach($country_data->cities as $city):
		   $cities_countries[] = $city;
		  endforeach; 
		  $cities = array_merge($cities_countries,$cities);
		endif;
	  endforeach;
	  sort($cities);
	  return $cities;
	   }catch (Exception $err) {   
	return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));
	   }
	}
	
	
    /**
    *Create a user
    * return User
    **/
    public function rentzon_create_customer($request){
          $userdata = $request->get_params();
        try{
		 	
		  $user_data['first_name'] = wp_strip_all_tags($userdata['firstName']);
          $user_data['last_name'] = wp_strip_all_tags($userdata['lastName']);
          if(isset($userdata['username']) && !empty($userdata['username'])){
			  $username = wp_strip_all_tags($userdata['username']);
		  }else{
			  throw new Exception('Username is required');
		  }
		  if(isset($userdata['password']) && !empty($userdata['password'])){
			  $password = wp_strip_all_tags($userdata['password']);
		  }else{
			  throw new Exception('Password is required');
		  }
		  if(isset($userdata['email']) && !empty($userdata['email'])){
			  $email = wp_strip_all_tags($userdata['email']);
		  }else{
			  throw new Exception('Email is required');
		  }
		  $new_customer_data = apply_filters(
			'woocommerce_new_customer_data',
			array_merge(
				$userdata,
				array(
					'user_login' => $username,
					'user_pass'  => $password,
					'user_email' => $email,
					'role'       => 'customer',
				)
			)
		);	
			  
		  $userId = wp_insert_user( $new_customer_data );	
		 	
          
          if(is_wp_error($userId)){
            throw new Exception($userId->get_error_message());
          }
          update_user_meta( $userId, 'billing_phone', $userdata['mobile'] );
          return $userId;
        }catch(Exception $error){
          //   var_dump($error->getMessage());
           return new WP_Error(400 ,$error->getMessage(),array( 'status' => 400 ));
        }

    }


    /**
    * Returns all products
    * @return array
    **/
    public function rentzon_get_all_products($request){
        $results=null;
        try{
        $results = $this->wc_client->get('products',$request->get_params());
        $results =$this-> append_addons($results);

        }
        catch(Exception $err){
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }

        return $results;
    }

    

    /**
    *Returns availability time based on duration
    * @return availabilitytime
    **/
    public function rentzon_get_product_available_time($request){
    try{
      $args['product_id']=isset($request['id'])?$request['id']:0;
      $args['from'] =isset($request['date'])?$request['date']:NULL;
      $args['duration']=isset($request['quantity'])?$request['quantity']:NULL;;
      $product = wc_get_product( $args['product_id'] );
        $formatted_time =array(); 
         $time_data=array();
        if ( $product && $product instanceof WC_Product_Booking ) {
            $time_data  = $product->create_availability_time_array( $args['from'],$args['duration'] );
           foreach($time_data as $time):
            $formatted_time[] =array('value' => $time ,"name" => apply_filters('yith_wcbk_ajax_booking_available_times_formatted_time','',$time,$product) );
           endforeach;        
        } 
       //return $time_data;     
       return $formatted_time; 
      }catch(Exception $err){
        $error_data =json_decode($err->getResponse()->getBody());
        return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
      }
    }
	
	public function get_termids($search_text){
	$term_ids =array();	
   	$args = array(
    	'taxonomy'      => 'product_tag', // taxonomy name
    	'orderby'       => 'id', 
    	'order'         => 'ASC',
    	'hide_empty'    => false,
    	'fields'        => 'all',
    	'name__like'    => trim($search_text)
	 ); 		
	 $result = get_terms($args);
	 if(is_array($result) && count($result)> 0)	:
	   foreach($result as $t):
		$term_ids[] = $t->term_id;
	   endforeach;	
	 endif;	
	 return $term_ids;	
	}
	
	
    /**
    *Return query
    *
    **/

    public function get_bookable_search_data($args){
      $product_data = $this->get_bookable_products($args);
	  if(isset($args['id'])):	
      	$product_data= $this->append_addons_and_details($product_data);
	  endif;
      return $product_data;
    }
	
	
    
	public function order_by_price($a,$b){
		if ( $a['regular_price'] == $b['regular_price'] ) {
		return 0;
	}
	return ( $a['regular_price'] < $b['regular_price'] ) ? -1 : 1;
	}
	
	public function order_by_popularity($a,$b){
		if ( $a['total_sales'] == $b['total_sales'] ) {
		return 0;
	 }
	 return ( $a['total_sales'] < $b['total_sales'] ) ? -1 : 1;
	}
	
	public function order_by_date($a,$b){
		if ( $a['created_date'] === $b['created_date'] ) {
		return 0;
	}
	return ( $a['created_date'] < $b['created_date'] ) ? -1 : 1;
	}
	
	public function order_by_rating($a,$b){
	   if ( $a['rating'] === $b['rating'] ) {
		return 0;
	 }
	 return ( $a['rating'] < $b['rating'] ) ? -1 : 1;
	}
    
    public function rentzon_get_product_categories($request){
        $page = isset($request['page']) ? absint($request['page']) : 1;
        $number = isset($request['per_page']) ?  absint($request['per_page']) : -1;
        $order =  isset($request['order']) ?  $request['order'] : 'DESC';
        $orderby =  isset($request['orderby']) ?  $request['orderby'] : 'name';
        $hideempty =  isset($request['hide_empty']) ?  $request['hide_empty'] : true;
        $search =  isset($request['search']) ?  $request['search'] : null;
        $taxonomy = 'product_cat';
        $args = array(
           'taxonomy'  => $taxonomy,
           'number'    => $number,
           'offset'    => ($page - 1) * $number,
           'orderby'   => $orderby,
           'order'     => $order,
           'hide_empty'    => $hideempty,
           'parent' => 0,
        );
        if ($search):
          $args['search'] = $search;        
        endif;
       
        try{
        $query = new WP_Term_Query($args);
        $results = $query->get_terms();
        foreach($results as $key => $product_cat):
           $thumbnail_id = get_woocommerce_term_meta($product_cat->term_id, 'thumbnail_id', true);
           $image =(object) array('src' => '');
           if( $thumbnail_id):
            $imageurl =  wp_get_attachment_image_src( $thumbnail_id, 'shop_catalog' );
            $image->src = is_array( $imageurl)?  $imageurl[0]: '';
           endif;

           $product_cat->id =  $product_cat->term_id;
           $product_cat->image =  $image;
        endforeach;
        }
        catch(Exception $err){
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }

        return array_values($results);
    }
     public function rentzon_get_product_single_category($request){
        $id=intval($request->get_params('id'));
        $results=null;
        try{
        $results = $this->wc_client->get('products/categories/'.$id,$request->get_params());
        }
        catch(Exception $err){
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }

        return $results;
    }

    public function append_addons_and_details($productlist=[]){
        foreach ($productlist as $key=> $data_product) {
				//check for cancellation policy
				if(class_exists('ACF') ) :
				$productlist[$key]['cancellation_policy'] = wp_strip_all_tags(get_field('cancellation_policy',$data_product['id'])); 
				endif;
				//end cancellation policy
				//checck for addons
				if(class_exists('YITH_WAPO_Type')){
                    $types= YITH_WAPO_Type::getAllowedGroupTypes( $data_product['id'] );
					$addon_data=[];
                    if(is_array($types)):
					  foreach($types as  $addon):
						if($addon->options):
						//get options
						  $options = maybe_unserialize($addon->options);
						  $addon_options=[];
						   for($i=0;$i < count($options['label']);$i++):
                            $addon_options[$i]['option_index'] = $i;
							if(array_key_exists('label',$options)):
						     $addon_options[$i]['label'] =$options['label'][$i];
							endif;
							if(array_key_exists('image',$options)):
						     $addon_options[$i]['image'] =$options['image'][$i];
							endif; 
							if(array_key_exists('image_alt',$options)):
							 $addon_options[$i]['image_alt'] =$options['image_alt'][$i];
							endif; 
							if(array_key_exists('description',$options)):
							 $addon_options[$i]['description'] =$options['description'][$i];
							endif; 
							if(array_key_exists('placeholder',$options)):
							 $addon_options[$i]['placeholder'] =$options['placeholder'][$i];
							endif;
                            if(array_key_exists('price',$options)):							
							 $addon_options[$i]['price'] =$options['price'][$i];
							endif; 
							if(array_key_exists('type',$options)):
							 $addon_options[$i]['type'] =$options['type'][$i];
							endif; 
							 if(array_key_exists('min',$options)):
							 $addon_options[$i]['min'] =$options['min'][$i];
							 endif;
							 if(array_key_exists('max',$options)):
							 $addon_options[$i]['max'] =$options['max'][$i];
							 endif;
							 
						   endfor;
						   	$addon_data[]=array('id'=> $addon->id, 'options' => $addon_options,'label' => $addon->label,'type' => $addon->type,'description' => $addon->description,'required' => $addon->required === '1'? true:false );
						endif;	
					  endforeach;
					   if(count($addon_data)):	
				         $productlist[$key]['addons'] = $addon_data;
					endif;
                  endif;  				   
                }
                // add product types 
            $product_data = wc_get_product($data_product['id']);
            $productlist[$key]['has_people_types'] = $product_data->has_people_types_enabled();            
            $productlist[$key]['has_persons'] =  $product_data->has_persons() && !$productlist[$key]['has_people_types'] ;
           		
            if($productlist[$key]['has_persons'] && !$productlist[$key]['has_people_types']):
                $productlist[$key]['min_persons'] =  $product_data->get_minimum_number_of_people();
                $productlist[$key]['max_persons']= $product_data->get_maximum_number_of_people();
            endif;
            if($productlist[$key]['has_people_types']):
                $productlist[$key]['people_types'] =$this->getPersonTypesDetails( $product_data->get_people_types());
            endif;
            }
        return $productlist;
    }
    
    /*Get product type details */
    public function getPersonTypesDetails($people_types = []) {
      $return_data = [];
      foreach( $people_types as $key => $type ) :
	    if($type['enabled'] === 'yes'):	
        $type['name'] = get_the_title(absint($key));
        $return_data[] = $type;
	   endif;	
      endforeach;
      return $return_data;
    }

}

$yith_custom_api =new YITH_PRODUCT_WC_API();
