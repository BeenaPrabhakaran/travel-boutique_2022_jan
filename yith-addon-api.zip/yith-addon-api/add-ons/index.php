<?php
if ( ! defined( 'YITH_WAPO' ) && !defined('WC_VERSION') ) {
	exit;
}
require plugin_dir_path(__FILE__)."class.product-api.php";
require plugin_dir_path(__FILE__)."class.cart-api.php";
require plugin_dir_path(__FILE__)."class.order-api.php";

