<?php 
/*Uses co-cart plugin for working*/

class YITH_CART_WC_API{
	protected $base_url = '';
	protected $base='wc';
    protected $authenticated_base ='/jwt-auth/v1';
	function __construct(){
		$this->base_url = get_site_url();
		//add_action('rest_api_init',array($this,'add_cors_http_header'));
        add_action('rest_api_init',array($this, 'rentzon_register_routes'));
		//add_filter( 'woocommerce_add_cart_item', array( $this, 'woocommerce_add_cart_item' ), 10, 2 );
		add_filter( 'cocart_add_to_cart_validation', array($this,'rentzon_cart_validation'), 10, 7 );
		add_filter( 'bdpwd_date_format' , array($this,'filter_date_format_pwd_reset'), 10 , 1 );
		add_filter( 'bdpwr_max_attempts' , array($this,'filter_date_format_pwd_attempts') , 10 , 4 );
		add_filter( 'bdpwr_code_expiration_seconds',array($this,'filter_date_format_pwd_time') ,  10 , 1 );
		add_filter( 'bdpwr_code_email_text',array($this,'filter_code_email_text') ,  10 , 4 );
    }
	
	public function filter_code_email_text( $text , $email , $code , $expiry){
	$msg =	'A password reset was requested for your account and your password reset code is '.$code.'.';
  	 if( $expiry !== 0 ) { 
    	$msg .= ' Please note that this code will expire within 15 minutes.';
  		} 
		return $msg;	
	}
	
	public function filter_date_format_pwd_time( $seconds ) {
  		return 900;
	}
	
	public function filter_date_format_pwd_attempts($attempts){
		return -1;	
	}
	
	public function filter_date_format_pwd_reset($format){
		 return 's';
	}
	
	public function woocommerce_add_cart_item($cart_item_data, $product_id){
		echo '<pre/>';
		print_r($cart_item_data);die;
	}
	
	/*cart validation for product using cocart*/
	public function rentzon_cart_validation($passed_validation, $product_id, $quantity, $variation_id, $variation, $cart_item_data, $product_type){
		if ( YITH_WCBK_Product_Post_Type_Admin::is_booking( $product_id ) ) :
				$product_id = apply_filters( 'yith_wcbk_booking_product_id_to_translate', $product_id );
				$product = wc_get_product( $product_id );
                if($product):
				 $availability_args = array(
							'from' => $cart_item_data['yith_booking_data']['from'],
							'to'   => $cart_item_data['yith_booking_data']['to'],
						);
						$r_persons         = isset( $cart_item_data['yith_booking_data']['persons'] ) ? max( 1, absint( $cart_item_data['yith_booking_data']['persons'] ) ) : 1;
						if ( $product->has_people() ) {
							$availability_args['persons'] = $r_persons;
						}
						$availability_args['return'] = 'array';
						$availability                = $product->is_available( $availability_args );
						
						//check availibility
						if ( ! $availability['available'] ) :
						 $passed_validation=false;
						endif;
						
						//check people min max
						if ( $product->has_people() ) :
							$min_persons = $product->get_minimum_number_of_people();
							$max_persons = $product->get_maximum_number_of_people();
							if ( $r_persons < $min_persons ) {
								$passed_validation = false;
							}

							if ( $max_persons > 0 && $r_persons > $max_persons ) {
								$passed_validation = false;
							}
						endif;
						//check people min max end
						//check already in cart
						if ( $passed_validation && $product->get_max_bookings_per_unit() ) :
							// check if there are booking products already added to the cart in the same dates
							$from                      = $cart_item_data['yith_booking_data']['from'];
							$to                        = $cart_item_data['yith_booking_data']['to'];
							$count_persons_as_bookings = $product->has_count_people_as_separate_bookings_enabled();
							$include_externals         = $product->has_external_calendars();
							$max_booking_per_block     = $product->get_max_bookings_per_unit();
							$unit                      = $product->get_duration_unit();
                             $yith_wcbk_cart= YITH_WCBK_Cart::get_instance();
							$bookings_added_to_cart_in_same_dates = $yith_wcbk_cart->count_added_to_cart_bookings_in_period( compact( 'product_id', 'from', 'to', 'count_persons_as_bookings' ) );
							$booked_bookings_in_same_dates        = YITH_WCBK_Booking_Helper()->count_max_booked_bookings_per_unit_in_period( compact( 'product_id', 'from', 'to', 'unit', 'include_externals', 'count_persons_as_bookings' ) );
							$_existing_bookings                   = $bookings_added_to_cart_in_same_dates + $booked_bookings_in_same_dates;
							$_booking_weight                      = ! ! $count_persons_as_bookings ? $r_persons : 1;

							if ( $_existing_bookings + $_booking_weight > $max_booking_per_block ) {
								$_remained      = $max_booking_per_block - $_existing_bookings;
								$_remained_text = '';
								if ( ! ! $_remained ) {
									if ( $product->has_people() && $count_persons_as_bookings ) {
										$_remained_text = sprintf( __( 'Too many people selected (%s remained)', 'yith-booking-for-woocommerce' ), $_remained );
									} else {
										$_remained_text = sprintf( __( '(%s remained)', 'yith-booking-for-woocommerce' ), $_remained );
									}
								}

								$passed_validation = false;
							}
						endif;
						
				endif;
        endif;
		return  $passed_validation;
	}
	
	/*register cart apis*/
	public function rentzon_register_routes(){
		//authenticated route		  
          register_rest_route( $this->authenticated_base, '/add-to-cart', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_add_to_cart'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
		  //authenticated route
		  register_rest_route( $this->authenticated_base, 'get-cart-key', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_the_current_cart'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
		  
		    //authenticated route
		  register_rest_route( $this->authenticated_base, 'delete-cart-item', array(
            'methods' => 'DELETE',
            'callback' => array($this,'rentzon_delete_item_from_cart'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
		
		register_rest_route( $this->authenticated_base, '/apply-coupon', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_apply_coupon_to_cart'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
          
		register_rest_route( $this->authenticated_base, '/get-payment-details', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_get_payment_details'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
		
          register_rest_route( $this->authenticated_base, '/remove-coupon', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_remove_coupon_to_cart'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));		
		  
		  //authenticated route
		  register_rest_route( $this->authenticated_base, 'get-cart', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_the_current_cart_data'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
		  //authenticated route
		  register_rest_route( $this->authenticated_base, 'get-cart-total', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_cart_total'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
          
          register_rest_route( $this->authenticated_base, '/orders', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_orders'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
          register_rest_route( $this->authenticated_base, '/orders/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this,'rentzon_update_orders'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
          
	}
	
	public function rentzon_get_payment_details($args){
		try{
		 if(!isset($args['tap_id']) && empty($args['tap_id'])):
			throw new Exception('Tap Id not found');
		 endif; 
		 $response_data = array('payment_method' => null, 'reference_id' => null); 	
		 $available_gateways = WC()->payment_gateways->get_available_payment_gateways();
	     if(array_key_exists('tap',$available_gateways)):
	     	$settings = $available_gateways['tap']->settings;
 	     	$testmode = $settings['testmode'] == 'yes';
 	     	$private_key = $testmode ? $settings['test_private_key'] : $settings['private_key'];
 	  	 	$payment_mode ='charges';
	        $url ="https://api.tap.company/v2/".$payment_mode."/".$args['tap_id'];
       			$args=array(
             		'headers'     => array(
             		"Authorization"=>"Bearer ".$private_key,
             		"Content-type"=>"application/json"
             		),
         		);
	  			
 	  		 $response=wp_remote_get($url,$args);
			 $status_code =  wp_remote_retrieve_response_code($response);
 	  		 $response = json_decode( wp_remote_retrieve_body($response));
			  if($status_code == 200 ):
			   $response_data['payment_method'] = $response->source->payment_method;
			   $response_data['reference_id'] = $response->reference->payment;
			  $response_data['message'] = 'Payment Data';
			  else:
			  	if(isset($response->errors) && is_array($response->errors)):
			   		throw new Exception($response->errors[0]->description);
			  	else:
			    	throw new Exception("Payment Gateway error");
			  	endif;
			  endif;
			 return new WP_REST_Response($response_data);
		 endif;	
		}catch(Exception $err){
			$error_data['message'] = $err->getMessage();
			return new WP_REST_Response($error_data,400);
		}
	}
	
	
	public function rentzon_apply_coupon_to_cart($request){
		try{ 
         $coupon_code = isset($request['coupon_code']) ? $request['coupon_code'] : false;
         if(!$coupon_code){
             throw new Exception('Invalid Coupon');
          }
      	$url = $this->base_url.'/wp-json/cocart/v1/coupon';
		$args = $this->create_header($request, 'POST');
		$args['body'] = array('coupon' => $coupon_code);	
		$response = wp_remote_request( $url, $args );
		$cart_data= wp_remote_retrieve_body($response);	
		if(wp_remote_retrieve_response_code($response) !== 200):
			throw new Exception('Invalid Coupon');
		endif;	
		return json_decode($cart_data);
		} catch(Exception $err){
			return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));	
		}		
    }
    
    
    public function rentzon_remove_coupon_to_cart($request){
        try{ 
         $coupon_code = $request['coupon_code'];
      	$url = $this->base_url.'/wp-json/cocart/v1/coupon';
		$args = $this->create_header($request, 'DELETE');
		$args['body'] = array('coupon' => $coupon_code);	
		$response = wp_remote_request( $url, $args );
		$cart_data= wp_remote_retrieve_body($response);
		return json_decode($cart_data);
		} catch(Exception $err){
			return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));	
		}
    }
	
	public function rentzon_update_orders($args){
        try{
         $order_id = isset($args['id']) ? $args['id']: null;
         $status = isset($args['status']) ? $args['status']: 'cancelled';
         $order_note = isset($args['order_note']) ? $args['order_note']: null;
		 $payment_tap_id = 	isset($args['tap_id']) ? $args['tap_id']: null;	
		 $payment_tap_payment_type = 	isset($args['tap_payment_type']) ? $args['tap_payment_type']: null;
		 $payment_tap_payment_ref	=isset($args['tap_payment_ref']) ? $args['tap_payment_ref']: null;
		 if($payment_tap_id): 	
         	$tap_response = $this->rentzon_get_payment_details($args);
		 endif;	
		  if(isset($tap_response->data) && array_key_exists('payment_method', $tap_response->data)):
			$payment_tap_payment_type =$tap_response->data['payment_method'];
		  endif;
		 if(isset($tap_response->data) && array_key_exists('reference_id', $tap_response->data)):
			$payment_tap_payment_ref =$tap_response->data['reference_id'];
		  endif;		
         if(!$order_id):
           throw new Exception("No Order id");
         endif;
         
         $order =wc_get_order($order_id);
         if(isset($order_note)):
              $order->add_order_note($order_note );
         endif;
		 if(isset($payment_tap_id )):
			update_post_meta($order->get_id(),'tap_reference_id', $payment_tap_id ); 
		 endif;
		if(isset($payment_tap_payment_type )):
			update_post_meta($order->get_id(),'order_tap_payment_method', $payment_tap_payment_type ); 
		 endif;
		if(isset($payment_tap_payment_ref )):
			update_post_meta($order->get_id(),'order_tap_method_id', $payment_tap_payment_ref ); 
		 endif;	
			
		 	
		 if($status == 'processing' && $order->get_id()):
			$order->set_status('processing');
         	$order->save();
		 	do_action('yith_wcbk_check_order_with_booking',$order->get_id(),array());
			do_action('woocommerce_order_status_processing',$order->get_id());
			do_action('woocommerce_checkout_update_order_meta',$order->get_id(),array());
         endif;
		  if($status == 'cancelled' && $order->get_id()):	
            $order->set_status($status);
          	$order->save();
		 endif;	
         if($status == 'processing'):
          	$url = $this->base_url.'/wp-json/cocart/v1/clear';
		    $args = $this->create_header($args, 'POST');
		    $response = wp_remote_request( $url, $args );         
         endif;  
		$order_details['id'] = $order->get_id();
        $created_date= $order->get_date_created('edit')->format('c');
        $created_date = isset($created_date) ? date_format(date_create($created_date), 'F d, Y'): null;
        $order_details['created_date'] =$created_date;
        $order_details['status'] =$order->get_status();
        $order_details['total'] =$order->get_total();
        $order_details['subtotal'] =$order->get_subtotal();
        $order_details['shipping_total'] =$order->get_shipping_total();
        $order_details['discount_total'] =$order->get_discount_total();
        $items = $order->get_items();
        $order_details['items']=array();
        if(is_array($items)):
         foreach($items as $item):
		  $addons =	$item->get_meta('_ywapo_meta_data');
		 $vendor =YITH_Vendor::retrieve($item->get_product_id(),'product');
		 $vendor_name = $vendor->name;
	     $addons = empty($addons) ? array(): $addons;		
          $order_details['items'][] = array('name' => $item->get_name(), 'quantity' => $item->get_quantity(), 'addons' =>  $addons ,'price' =>$item->get_total(),'vendor_name' =>$vendor_name ); 
         endforeach;
        //add billing details 
        $order_details['billing_first_name'] = $order->get_billing_first_name();
        $order_details['billing_last_name'] = $order->get_billing_last_name();
        $order_details['billing_address_1'] = $order->get_billing_address_1();
        $order_details['billing_address_2'] = $order->get_billing_address_2();
        $order_details['billing_company'] = $order->get_billing_company();
        $order_details['billing_city'] =  $order->get_billing_city();
        $order_details['billing_state'] =  $order->get_billing_state();
        $order_details['billing_postcode']=  $order->get_billing_postcode();
        $order_details['billing_country']=  $order->get_billing_country();
        $order_details['billing_email'] = $order->get_billing_email();
        $order_details['billing_phone'] = $order->get_billing_phone();
        
        //shipping details
        $order_details['shipping_first_name'] = $order->get_shipping_first_name();
        $order_details['shipping_last_name'] = $order->get_shipping_last_name();
        $order_details['shipping_address_1'] = $order->get_shipping_address_1();
        $order_details['billing_address_2'] = $order->get_shipping_address_2();
        $order_details['shipping_company'] = $order->get_billing_company();
        $order_details['shipping_city'] =  $order->get_shipping_city();
        $order_details['shipping_state'] =  $order->get_shipping_state();
        $order_details['shipping_postcode']=  $order->get_shipping_postcode();
        $order_details['shipping_country']=  $order->get_shipping_country(); 
		$order_details['payment_method']=$payment_tap_payment_type;
		$order_details['reference_id']=	 $payment_tap_payment_ref;
		endif;	
         $data = array('order'=> $order_details, 'status' => $status);
         return new WP_REST_Response($data,200);
         
        } catch (Exception $error){
            return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));
        }
    }
        
    public function rentzon_orders($args){
        $order_details =array();
        $order_details['customer_id'] = isset($args['customer_id']) ? $args['customer_id'] : 0;
		
        try{         
        $new_order = wc_create_order($order_details); // order created
        
        if(!$new_order->get_id()):
         throw new Exception('Order not created.Server Error');
        endif;
        	
			
        if(isset($args['shipping_methods']) && is_array($args['shipping_methods'])):
          foreach($args['shipping_methods'] as $shipping_method):
             $shipping_item = new WC_Order_Item_Shipping();
            $props = array();
            if(isset($shipping_method['label'])):
             $props['method_title']  =  $shipping_method['label']; 
            endif;
            if(isset($shipping_method['method_id'])):
             $props['method_id']  =  $shipping_method['method_id']; 
            endif;
            if(isset($shipping_method['cost'])):
             $props['total']  =  wc_format_decimal($shipping_method['cost']); 
            endif;
            if(isset($shipping_method['taxes'])):
             $props['taxes']  =  $shipping_method['taxes']; 
            endif;
            if(!empty($props)):
			$shipping_item->set_props($props);
			$new_order->add_item( $shipping_item );
			endif;
          endforeach;        
        endif;    
        	
		// get cart shipping details
			
        	/*$url = $this->base_url.'/wp-json/cocart/v1/get-cart';
			$args = $this->create_header($args, 'GET');
			$response = wp_remote_request( $url, $args );
			$cart_data= wp_remote_retrieve_body($response);
			$cart_items = json_decode($cart_data);
	  //check if any shipping
          if(isset($cart_items->shipping_methods)):
		  foreach($cart_items->shipping_methods as $shipping_method):
			$shipping_item = new WC_Order_Item_Shipping();
			$shipping_item->set_props(array('method_title' => $shipping_method->label, 'method_id' => $shipping_method->id, 'total' => wc_format_decimal($shipping_method->cost), 'taxes' => $shipping_method->taxes));
			$new_order->add_item( $shipping_item );
		  endforeach;	
		  endif;*/
			
        $order_details['payment_method'] = isset($args['payment_method']) ? $args['payment_method'] : 'cod';
        $new_order->set_payment_method($order_details['payment_method']); // added payment method
        $order_details['payment_method_title'] = isset($args['payment_method_title']) ? $args['payment_method_title'] : 'Cash On Delivery';
        
         $new_order->set_payment_method_title($order_details['payment_method_title']); // added payment method title

        
        // billing details
        $order_details['billing']['first_name'] = isset($args['billing_first_name']) ? $args['billing_first_name'] : null;
        update_user_meta($order_details['customer_id'], 'billing_first_name', $order_details['billing']['first_name']);
        $order_details['billing']['last_name'] = isset($args['billing_last_name']) ? $args['billing_last_name'] : null;
        update_user_meta($order_details['customer_id'], 'billing_last_name',$order_details['billing']['last_name']);
        $order_details['billing']['address_1'] = isset($args['billing_address_1']) ? $args['billing_address_1'] : null;
        update_user_meta($order_details['customer_id'], 'billing_address_1',$order_details['billing']['address_1']);
        $order_details['billing']['address_2'] = isset($args['billing_address_2']) ? $args['billing_address_2'] : null;
        update_user_meta($order_details['customer_id'], 'billing_address_2', $order_details['billing']['address_2']);
        $order_details['billing']['company'] = isset($args['billing_company']) ? $args['billing_company'] : null;
        update_user_meta($order_details['customer_id'], 'billing_company', $order_details['billing']['company']);
        $order_details['billing']['city'] = isset($args['billing_city']) ? $args['billing_city'] : null;
         update_user_meta($order_details['customer_id'], 'billing_city',$order_details['billing']['city']);
        $order_details['billing']['state'] = isset($args['billing_state']) ? $args['billing_state'] : null;
        update_user_meta($order_details['customer_id'], 'billing_state',$order_details['billing']['state']);
        $order_details['billing']['postcode'] = isset($args['billing_postcode']) ? $args['billing_postcode'] : null;
        update_user_meta($order_details['customer_id'], 'billing_postcode',$order_details['billing']['postcode']);
        $order_details['billing']['country'] = isset($args['billing_country']) ? $args['billing_country'] : null;
         update_user_meta($order_details['customer_id'], 'billing_country',$order_details['billing']['country']);
        $order_details['billing']['email'] = isset($args['user_email']) ? $args['user_email'] : null;
        $order_details['billing']['phone'] = isset($args['billing_phone']) ? $args['billing_phone'] : null;
        update_user_meta($order_details['customer_id'], 'billing_phone',$order_details['billing']['phone']);
        //billing details
        $new_order->set_address( $order_details['billing'], 'billing' ); // set billing address
        //shipping details
        $order_details['shipping']['first_name'] = isset($args['shipping_first_name']) ? $args['shipping_first_name'] : null;
        $order_details['shipping']['last_name'] = isset($args['shipping_last_name']) ? $args['shipping_last_name'] : null;
        $order_details['shipping']['address_1'] = isset($args['shipping_address_1']) ? $args['shipping_address_1'] : null;
        $order_details['shipping']['address_2'] = isset($args['shipping_address_2']) ? $args['shipping_address_2'] : null;
        $order_details['billing']['company'] = isset($args['shipping_company']) ? $args['shipping_company'] : null;
        $order_details['shipping']['city'] = isset($args['shipping_city']) ? $args['shipping_city'] : null;
        $order_details['shipping']['state'] = isset($args['shipping_state']) ? $args['shipping_state'] : null;
        $order_details['shipping']['postcode'] = isset($args['shipping_postcode']) ? $args['shipping_postcode'] : null;
        $order_details['shipping']['country'] = isset($args['shipping_country']) ? $args['shipping_country'] : null;
        // shipping details 
        
        $new_order->set_address( $order_details['shipping'], 'shipping' ); // set billing address
        //create order item meta details
        foreach($args['original_data'] as $key => $product_details):
         	$item = new WC_Order_Item_Product();
         	$item->set_order_id($new_order->get_id());
        	$order_details['product_id'] = isset($product_details['product_id']) ? $product_details['product_id'] : 0;
        	$product = wc_get_product($order_details['product_id']);
        	$item->set_product($product); // added product item
        
        	$order_details['total'] = isset($product_details['total']) ? $product_details['total'] : null;
        	$order_details['quantity'] = isset($product_details['quantity']) ? $product_details['quantity'] : 1;
         	$order_details['subtotal'] = isset($product_details['sub_total']) ? $product_details['sub_total'] : null;
        	if( ! $order_details['total'] &&  $order_details['subtotal']):
            	$order_details['total']=$order_details['subtotal'];
        	endif;    
        	$order_details['tax'] = isset($product_details['tax']) ? $product_details['tax'] : 0;
        	$order_details['subtotal_tax'] = isset($product_details['sub_total_tax']) ? $product_details['sub_total_tax'] : 0;
        
        //check if total is there or calculate total
        	if(!order_details['total']):
				$total    = wc_get_price_excluding_tax( $product, array( 'qty' =>  $order_details['quantity'] ) );
				$item->set_total( $total );
				$item->set_subtotal( $total );
        	else:
          		$item->set_total(  $order_details['total'] );
          		if(!$order_details['subtotal']):
            		$item->set_subtotal( $order_details['total'] );
          		else:
           			$item->set_subtotal( $order_details['subtotal'] );
          		endif;
        	endif;
        //check for taxes
        	if(!order_details['tax']):
          		$item->set_taxes(  $order_details['tax'] );
         		 $item->set_subtotal_tax( $order_details['sub_total_tax'] );
        	endif;

       
        //product details
        
        // product meta if booking product
        	if(isset($product_details['product_id']) && YITH_WCBK_Product_Post_Type_Admin::is_booking($product_details['product_id'])):
         	$cart_item_key = isset($product_details['key']) ? $product_details['key'] : null;
         	$order_details['yith_booking_data'] = $this->format_order_details($product_details);

         	apply_filters('woocommerce_checkout_create_order_line_item',$item, $cart_item_key,$order_details, $new_order );
        endif;
        //product meta if booking product
        // addons details 
         $item_id = $item->save();
        if(isset($product_details['addons'])):
          $product_details['yith_wapo_options'] =  $product_details['addons'];      
          do_action('woocommerce_new_order_item', $item_id,$product_details);
        endif;
        //addons details
        endforeach;
        
        //totals
       /* $order_details['total'] = isset($args['total']) ? $args['total'] : 0;
        $new_order->set_total($order_details['total']);
        $order_details['total_tax'] = isset($args['total_tax']) ? $args['total_tax'] : 0;
        $new_order->set_total($order_details['total']);
        $order_details['subtotal'] = isset($args['subtotal']) ? $args['subtotal'] : 0;
        $order_details['subtotal_tax'] = isset($args['subtotal_tax']) ? $args['subtotal_tax'] : 0;
        $order_details['discount_total'] = isset($args['discount_total']) ? $args['discount_total'] : 0;
        $order_details['discount_tax'] = isset($args['discount_tax']) ? $args['discount_tax'] : 0;
       
      */
	 if(isset($args['coupons'])):
			foreach($args['coupons'] as $coupon_details):
		 	$new_order->apply_coupon($coupon_details['coupon']);
		    endforeach;
	endif;		
	  		
      $new_order->calculate_totals();
      $new_order->save();        
     // do_action('yith_wcbk_check_order_with_booking',$new_order->get_id(),array()); 
	  do_action('woocommerce_checkout_update_order_meta',$new_order->get_id(),array());		
	  //do_action('woocommerce_order_details_after_order_table',$new_order );		
	  		
	  
        
         if(!$new_order->get_id()):
          throw new Exception("order not created");      
         endif;
         $data= array("order_id" => $new_order->get_id(), "status" => $new_order->get_status());
         return wp_send_json($data);
        }
        catch(Exception $err){
            return $err->getMessage();
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }
    }
    
    public function format_person_types($person_types = array()){
       $people=array(); 
        foreach($person_types as $key => $persons):
         $people[$persons['id']] =$persons['value'];
        endforeach;
        return $people;
    }
    
    
    public function format_order_details($args){
       $meta_data =array();
        $meta_data['from'] = isset($args['from']) ? strtotime($args['from']): null;
        $meta_data['to'] = isset($args['to']) ? strtotime($args['to']): null;
        $meta_data['duration'] = isset($args['duration']) ? $args['duration']: null;
        $meta_data['persons'] = isset($args['persons']) ? $args['persons']: null;
        $meta_data['person_types'] = isset($args['person_types']) ? $this->format_person_types($args['person_types']): null;
       return $meta_data;
    }
	
	public function rentzon_get_cart_total($request){
		$cart_key = $request->get_param('cart_key');
		$url = $this->base_url.'/wp-json/cocart/v1/totals?cart_key=';
		$args = $this->create_header($request, 'GET');
		$response = wp_remote_request( $url, $args );
		$cart_data= wp_remote_retrieve_body($response);
		return json_decode($cart_data);
	}
	
	
	public function rentzon_get_the_current_cart_data($request){
		$url = $this->base_url.'/wp-json/cocart/v1/get-cart';
		$args = $this->create_header($request, 'GET');
		$response = wp_remote_request( $url, $args );
		$cart_data= wp_remote_retrieve_body($response);
		$cart_items = json_decode($cart_data);
		//return $cart_items;
        if(isset($cart_items->items) && !empty($cart_items->items) ):
         return $this->format_cart_items($cart_items);
        else:
         return (object) array();    
        endif;
	}
	
	public function format_cart_items($cart_items){
		global $woocommerce;
        $cart_data = array();
       
        foreach($cart_items->items as $item):
		 $items = array();	
         $items['key'] = isset($item->key) ? $item->key : null;
         $items['product_name'] =isset($item->product_name) ? $item->product_name : null;
          $items['product_id'] =isset($item->product_id) ? $item->product_id : 0;
         $vendor = YITH_Vendor::retrieve($item->product_id,'product'); 
         $items['vendor'] =isset($vendor->name) ? $vendor->name : null;
         $items['quantity'] =isset($item->quantity) ? $item->quantity : 0;
         $items['image'] =get_the_post_thumbnail_url( $item->product_id );
         $items['price'] =isset($item->product_price) ? $item->product_price : 0;
         $items['sub_total'] =isset($item->line_subtotal) ? $item->line_subtotal : 0;
         if(isset($item->yith_booking_data)):
         $items['duration'] = isset($item->yith_booking_data->duration) ?  $item->yith_booking_data->duration : 1;
         $items['from'] = isset($item->yith_booking_data->from) ? date('F d,Y h:i A', $item->yith_booking_data->from) : null;
         $items['to'] = isset($item->yith_booking_data->to) ? date('F d,Y h:i A', $item->yith_booking_data->to) : null;
         if(isset($item->yith_booking_data->person_types)):
            $return_data =array();
           foreach( $item->yith_booking_data->person_types as $key => $type ) :
                $return_data[] = array('name'=> get_the_title(absint($key)), 'value' => $type, 'id' => $key );
           endforeach;
            $items['person_types'] = $return_data;  
           elseif (isset($item->yith_booking_data->persons)):        
           $items['persons'] = $item->yith_booking_data->persons;
          endif; 
         endif;
         $items['addons'] = isset($item->yith_wapo_options) ? $item->yith_wapo_options : array();
         array_push( $cart_data, $items);        
        endforeach;
		if( isset($cart_items->shipping_methods )):
		$packages =array();
		foreach($cart_items->shipping_methods as $shipping_method):
		$packages[]= $shipping_method;
		endforeach;
		$cart_items->shipping_details = $woocommerce->cart;	
		endif;
        $cart_items->totals->originaltotal = filter_var($cart_items->totals->total, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $cart_items->original_data = $cart_data;
        return $cart_items;
    }
	
	
	/*Delete item from cart*/
	public function rentzon_delete_item_from_cart($request){
	 
	  $item_key = null != $request->get_param('item_key') ?  $request->get_param('item_key') : false;
	  try{
	  if(!$item_key):
	    throw new Exception('Item key required');
	  endif;
	  $url = $this->base_url.'/wp-json/cocart/v1/item';
	  $args = $this->create_header($request, 'DELETE');
	  $args['body']=array('cart_item_key' => $item_key );
	  $response = wp_remote_request( $url, $args );	
	  return $response;
	  } catch(Exception $err){
		return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));  
	  }
	}
	
	/*Get current cart . We are using co-cart plugin */
	
	 public function rentzon_get_the_current_cart($request){
	    
		 $response['key'] = get_current_user_id();
		 return $response;
	 }
	 
	 /**
    * Add to Cart
    **/
    public function rentzon_add_to_cart($request){
      $body =$request->get_params();
	  error_log($body);	
      $args = $this->create_header($request, 'POST');
	  $url = $this->base_url.'/wp-json/cocart/v1/add-item';
      $args['from']=isset($body['date'])?$body['date']:NULL;
      $args['duration']=isset($body['duration'])?$body['duration']:NULL;
      $args['add-to-cart']=isset($body['product_id'])?$body['product_id']:0;
	  $args['persons']=isset($body['persons'])?$body['persons']:1;
	  $args['person_types']=isset($body['person_types'])?$body['person_types']:NULL;
      $args['time']=isset($body['time'])?$body['time']:NULL;
	  $cart_item_data['key']=isset($body['key'])?$body['key']:NULL;
      if($args['time'])
      $args['from']=$args['from'].' '.$args['time'];
      $person_ids_to_numbers =array();
      
      if(is_array($args['person_types']) && !empty($args['person_types'])):
        foreach($args['person_types'] as $person_types):
           $person_ids_to_numbers[$person_types['id']] =$person_types['number'];
        endforeach;    
      endif;
      $args['person_types']=$person_ids_to_numbers;
      
      $booking_data = YITH_WCBK_Cart::get_booking_data_from_request( $args );
	  $booking_data['_added-to-cart-timestamp']=time();
	  $cart_item_data['yith_booking_data'] = $booking_data;
      $cart_item_data['yith_wapo_options']	=isset($body['addons'])?$body['addons']:array();	
      $cart_item_data['yith_wapo_sold_individually']='';
      $cart_item_data['product_id']=$args['add-to-cart'];
		if(!empty($cart_item_data['yith_wapo_options'])):
		$cart_item_data['yith_wapo_options'] =$this->adjust_addon_price($cart_item_data['yith_wapo_options'],$cart_item_data['product_id']);
	  endif;
      $cart_item_data['variation_id']=0;
      $cart_item_data['variation']=array();	
	  $cart_item_data['quantity']=1;
	  $cart_item_data['data']=wc_get_product($args['add-to-cart']);
	  $args['body'] = array('cart_key'=> $cart_item_data['key'],'product_id'=> $cart_item_data['product_id'], 'quantity' => $cart_item_data['quantity'],'variation_id'=> $cart_item_data['variation_id'],'variation'=>$cart_item_data['variation'],'cart_item_data'=> $cart_item_data,'return_cart'=>true);
	  $response = wp_remote_request( $url, $args );
	  try{ 
	   if(200 != wp_remote_retrieve_response_code($response)){
		throw new Exception("Product not added to the cart. Item either already added or does not meet the requirements ");  
	   }
	   return json_decode(wp_remote_retrieve_body($response));
	  }catch(Exception $err){
	    return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 )); 
	  }
    }
	
	public function adjust_addon_price($addons,$product_id = 0 ){
		$updated_addons = array();
		if (is_array($addons)) :
         foreach ($addons as  $addon):
           $addon['product_id'] = $product_id;
           $addon['option_value'] = $addon['value'];
           $addon['product_price'] = wc_get_product($product_id)->get_price();
           $cost =$this->calculate_single_addon_cost($addon);
		
		   $addon['price'] =$cost;
		   $addon['price_original'] =$cost;
		  $updated_addons[] = $addon;
         endforeach;
        endif;
	   return $updated_addons;	
	}
	
	
    public function calculate_single_addon_cost($addon){

        if ( ! isset( $addon['product_id'] ) || ! isset( $addon['product_price'] ) || ! isset( $addon['type_id'] ) || ! isset( $addon['option_index'] ) ) {
				return 0;
			}

			$product_id = intval( $addon['product_id'] );

			if ( $product_id > 0 ) {

				$type_id = intval( $addon['type_id'] );

				$product = wc_get_product( $product_id );

				$product_price = floatval( $addon['product_price'] );

				if ( is_object( $product ) && $type_id > 0 && $product_price > 0 ) {

					$single_group_type = YITH_WAPO_Type::getSingleGroupType( $type_id );

					if ( is_array( $single_group_type ) ) {
						$single_group_type = $single_group_type[0];
					}

					if ( is_object( $single_group_type ) ) {

						$option_index = $addon['option_index'];

						if ( $option_index >= 0 ) {

							$options = $single_group_type->options;
							$options = maybe_unserialize( $options );

							if ( is_array( $options ) ) {
                                $yith_frontend = new YITH_WAPO_Frontend('2.0.0'); 
								$price            = $options['price'][ $option_index ];
                               
								$price_type       = $options['type'][ $option_index ];
								$value            = isset( $addon['option_value'] ) ? $addon['option_value'] : null;
								$price_calculated = $yith_frontend->get_display_price( $product, $price, $price_type, true, null, $product_price, $value );
								return floatval($price_calculated);
							}
						}
					}
				}

			}

    }
	
	public function create_header($request,$method){
		$authorization_header = $request-> get_header('authorization');
		$args = array(
			'method' => $method,
			'headers' => array(
			  'Authorization' => $authorization_header
			)
		);
		return $args;
	}
	 	 
}
$yith_cart_api =new YITH_CART_WC_API();