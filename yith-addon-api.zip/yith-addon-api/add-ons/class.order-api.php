<?php

class YITH_ORDER_WC_API{
    protected $base_url = '';
	protected $base='wc';
    
    function __construct(){
		$this->base_url = get_site_url();
        add_action('rest_api_init',array($this, 'rentzon_register_routes'));  
    }
    
    public function rentzon_register_routes(){
        
		//authenticated route		  
          register_rest_route( $this->authenticated_base, '/orders', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_orders'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
          register_rest_route( $this->authenticated_base, '/orders/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this,'rentzon_update_orders'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ));
    }
    
    public function rentzon_update_orders($args){
        try{
         $order_id = isset($args['id']) ? $args['id']: null;
         $status = isset($args['status']) ? $args['status']: 'cancelled';
         $order_note = isset($args['order_note']) ? $args['order_note']: null;
         var_dump($order_note);die;
         if(!$order_id):
           throw new Exception("No Order id");
         endif;
         $order =wc_get_order($order_id);
         $order->set_status($status);
         if(isset($order_note)):
              $order->add_order_note($order_note );
         endif;  
         $order->save();
         $data = array('order_id'=> $order_id, 'status' => $status);
                
         return wp_send_json($data);
         
        } catch (Exception $error){
            return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));
        }
    }
        
    public function rentzon_orders($args){
        $order_details =array();
        $order_details['customer_id'] = isset($args['customer_id']) ? $args['customer_id'] : 0;
        try{         
        $new_order = wc_create_order($order_details); // order created
        
        if(!$new_order->get_id()):
         throw new Exception('Order not created.Server Error');
        endif;
        $order_details['payment_method'] = isset($args['payment_method']) ? $args['payment_method'] : 'cod';
        $new_order->set_payment_method($order_details['payment_method']); // added payment method
        $order_details['payment_method_title'] = isset($args['payment_method_title']) ? $args['payment_method_title'] : 'Cash On Delivery';
        
         $new_order->set_payment_method_title($order_details['payment_method_title']); // added payment method title

        
        // billing details
        $order_details['billing']['first_name'] = isset($args['billing_first_name']) ? $args['billing_first_name'] : null;
        $order_details['billing']['last_name'] = isset($args['billing_last_name']) ? $args['billing_last_name'] : null;
        $order_details['billing']['address_1'] = isset($args['billing_address_1']) ? $args['billing_address_1'] : null;
        $order_details['billing']['address_2'] = isset($args['billing_address_2']) ? $args['billing_address_2'] : null;
        $order_details['billing']['company'] = isset($args['billing_company']) ? $args['billing_company'] : null;
        $order_details['billing']['city'] = isset($args['billing_city']) ? $args['billing_city'] : null;
        $order_details['billing']['state'] = isset($args['billing_state']) ? $args['billing_state'] : null;
        $order_details['billing']['postcode'] = isset($args['billing_postcode']) ? $args['billing_postcode'] : null;
        $order_details['billing']['country'] = isset($args['billing_country']) ? $args['billing_country'] : null;
        $order_details['billing']['email'] = isset($args['billing_email']) ? $args['billing_email'] : null;
        $order_details['billing']['phone'] = isset($args['billing_phone']) ? $args['billing_phone'] : null;
        //billing details
        $new_order->set_address( $order_details['billing'], 'billing' ); // set billing address
        //shipping details
        $order_details['shipping']['first_name'] = isset($args['shipping_first_name']) ? $args['shipping_first_name'] : null;
        $order_details['shipping']['last_name'] = isset($args['shipping_last_name']) ? $args['shipping_last_name'] : null;
        $order_details['shipping']['address_1'] = isset($args['shipping_address_1']) ? $args['shipping_address_1'] : null;
        $order_details['shipping']['address_2'] = isset($args['shipping_address_2']) ? $args['shipping_address_2'] : null;
        $order_details['billing']['company'] = isset($args['shipping_company']) ? $args['shipping_company'] : null;
        $order_details['shipping']['city'] = isset($args['shipping_city']) ? $args['shipping_city'] : null;
        $order_details['shipping']['state'] = isset($args['shipping_state']) ? $args['shipping_state'] : null;
        $order_details['shipping']['postcode'] = isset($args['shipping_postcode']) ? $args['shipping_postcode'] : null;
        $order_details['shipping']['country'] = isset($args['shipping_country']) ? $args['shipping_country'] : null;
        // shipping details 
        
        $new_order->set_address( $order_details['shipping'], 'shipping' ); // set billing address
        //create order item meta details
        if(isset($args['order_notes'])):
            $new_order->add_order_note( $args['order_notes'] );
        endif;    
        
        foreach($args['original_data'] as $key => $product_details):
         $item = new WC_Order_Item_Product();
         $item->set_order_id($new_order->get_id());
        $order_details['product_id'] = isset($product_details['product_id']) ? $product_details['product_id'] : 0;
        $product = wc_get_product($order_details['product_id']);
        $item->set_product($product); // added product item
        
        $order_details['total'] = isset($product_details['total']) ? $product_details['total'] : null;
        $order_details['quantity'] = isset($product_details['quantity']) ? $product_details['quantity'] : 1;
         $order_details['subtotal'] = isset($product_details['sub_total']) ? $product_details['sub_total'] : null;
        $order_details['tax'] = isset($product_details['tax']) ? $product_details['tax'] : 0;
        $order_details['subtotal_tax'] = isset($product_details['sub_total_tax']) ? $product_details['sub_total_tax'] : 0;
        
        //check if total is there or calculate total
        if(!order_details['total']):
				$total    = wc_get_price_excluding_tax( $product, array( 'qty' =>  $order_details['quantity'] ) );
				$item->set_total( $total );
				$item->set_subtotal( $total );
        else:
          $item->set_total(  $order_details['total'] );
          if(!$order_details['subtotal']):
            $item->set_subtotal( $order_details['total'] );
          else:
           $item->set_subtotal( $order_details['subtotal'] );
          endif;
        endif;
        //check for taxes
        if(!order_details['tax']):
          $item->set_taxes(  $order_details['tax'] );
          $item->set_subtotal_tax( $order_details['sub_total_tax'] );
        endif;

       
        //product details
        
        // product meta if booking product
        if(isset($product_details['product_id']) && YITH_WCBK_Product_Post_Type_Admin::is_booking($product_details['product_id'])):
         $cart_item_key = isset($product_details['key']) ? $product_details['key'] : null;
         $order_details['yith_booking_data'] = $this->format_order_details($product_details);

         apply_filters('woocommerce_checkout_create_order_line_item',$item, $cart_item_key,$order_details, $new_order );
        endif;
        //product meta if booking product
        // addons details 
        if(isset($product_details['addons'])):
         $item->add_meta_data('yith_wapo_options',$product_details['addons']);  
        endif;
        //addons details
        $item->save();
        endforeach;
        
        //totals
       /* $order_details['total'] = isset($args['total']) ? $args['total'] : 0;
        $new_order->set_total($order_details['total']);
        $order_details['total_tax'] = isset($args['total_tax']) ? $args['total_tax'] : 0;
        $new_order->set_total($order_details['total']);
        $order_details['subtotal'] = isset($args['subtotal']) ? $args['subtotal'] : 0;
        $order_details['subtotal_tax'] = isset($args['subtotal_tax']) ? $args['subtotal_tax'] : 0;
        $order_details['discount_total'] = isset($args['discount_total']) ? $args['discount_total'] : 0;
        $order_details['discount_tax'] = isset($args['discount_tax']) ? $args['discount_tax'] : 0;
       
      */
      $new_order->calculate_totals();
      $new_order->save();        
        
        
         if($new_order->get_id()):
          do_action('woocommerce_checkout_order_processed',$new_order->get_id(),array());
         else:
          throw new Exception("order not created");      
         endif;
         $data= array("order_id" => $new_order->get_id(), "status" => $new_order->get_status());
         return wp_send_json($data);
        }
        catch(Exception $err){
            return $err->getMessage();
            $error_data =json_decode($err->getResponse()->getBody());
            return new WP_Error($error_data->code ,$error_data->message, $error_data->data );
        }
    }
    
    public function format_person_types($person_types = array()){
       $people=array(); 
        foreach($person_types as $key => $persons):
         $people[$persons['id']] =$persons['value'];
        endforeach;
        return $people;
    }
    
    
    public function format_order_details($args){
       $meta_data =array();
        $meta_data['from'] = isset($args['from']) ? strtotime($args['from']): null;
        $meta_data['to'] = isset($args['to']) ? strtotime($args['to']): null;
        $meta_data['duration'] = isset($args['duration']) ? $args['duration']: null;
        $meta_data['persons'] = isset($args['persons']) ? $args['persons']: null;
        $meta_data['person_types'] = isset($args['person_types']) ? $this->format_person_types($args['person_types']): null;
       return $meta_data;
    }
   
}

$yith_order_wc_api = new YITH_ORDER_WC_API();