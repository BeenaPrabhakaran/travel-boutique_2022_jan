<?php
class YITH_GENERAL_API{
	protected $base='wc';
    protected $authenticated_base ='/jwt-auth/v1';
    
    function __construct(){
        add_action('rest_api_init',array($this, 'rentzon_register_routes'));
        add_action( 'wp_enqueue_scripts', array($this, 'rentzon_theme_scripts')); // this script has dependency with yith wapo addon plugin and any future update should be handled as per 
        add_filter('jwt_auth_token_before_dispatch', array($this, 'add_additional_user_details'), 10 ,2 );    
        
    }
    
    public function add_additional_user_details($data,$user){
        $data['user_id'] = $user->id;
        $data['username'] = $user->user_login;
        $data['firstName'] = get_user_meta($user->id, 'first_name',true);
        $data['lastName'] = get_user_meta($user->id, 'last_name',true);
        $data['mobile'] = get_user_meta($user->id, 'billing_phone',true);
        return $data;   
    }
    
     public function rentzon_theme_scripts(){
      wp_enqueue_script( 'yith_rentzon_wapo_frontend', plugin_dir_url(__DIR__ ) . 'assets/yith-rentzon-wapo-cart-support.js', array( 'jquery', 'wc-add-to-cart-variation','yith_wapo_frontend' ),'1.0.0' , true );
       wp_enqueue_script( 'yith_rentzon_wapo_search_frontend', plugin_dir_url(__DIR__ ) . 'assets/yith-rentzon-wapo-search-support.js', array( 'jquery' ),'1.0.0' , true );
    }
    
    public function rentzon_register_routes(){
    	register_rest_route( $this->authenticated_base, '/currentuser', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_current_user'),
            'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          ) );
    	register_rest_route( $this->base, '/sliders', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_sliders'),
          ) );
		register_rest_route( $this->base, '/states', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_states'),
          ) );
		
        register_rest_route( $this->authenticated_base, '/add-to-wishlist', array(
            'methods' => 'POST',
            'callback' => array($this,'add_to_wishlist'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
          )); 
          
        register_rest_route( $this->authenticated_base, '/get-wishlist', array(
            'methods' => 'GET ',
            'callback' => array($this,'get_wishlist'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));
        
        register_rest_route( $this->authenticated_base, '/remove-from-wishlist', array(
            'methods' => 'POST ',
            'callback' => array($this,'remove_from_wishlist'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));  
          
        register_rest_route( $this->authenticated_base, '/billing-address/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'get_billing_address'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));
		
		register_rest_route( $this->authenticated_base, '/get-user-orders/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'get_user_orders'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        )); 
		
		register_rest_route( $this->authenticated_base, '/view-single-order/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'view_single_order'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));
		
		register_rest_route( $this->authenticated_base, '/get-user-bookings/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'get_user_bookings'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));        
        
        register_rest_route( $this->authenticated_base, '/get-bookings/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this,'get_bookings_by_id'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));
		
		register_rest_route( $this->authenticated_base, '/cancel-bookings/(?P<id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this,'cancel_bookings_by_id'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        ));
        
        register_rest_route( $this->authenticated_base, '/update-user-details/(?P<id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this,'set_billing_address'),
			'permission_callback' => function($request){	  
					return is_user_logged_in();
			}
        )); 
		register_rest_route( $this->base, '/main-sliders', array(
            'methods' => 'GET',
            'callback' => array($this,'rentzon_get_all_sliders'),
          ) );
		
		register_rest_route( $this->base, '/forget-password', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_set_forget_password'),
          ) );
		register_rest_route( $this->base, '/reset-password', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_set_reset_password'),
          ) );
		register_rest_route( $this->base, '/feedback', array(
            'methods' => 'POST',
            'callback' => array($this,'rentzon_sent_feedback_email'),
          ) );
    }
	
	
	public function rentzon_sent_feedback_email($args){
		try{
		 if(!isset($args['email']) || empty($args['email'])){
			throw new Exception('Email is required'); 
		 }
		if(!isset($args['name']) || empty($args['name'])){
			throw new Exception('Name is required');
		 }
		if(!isset($args['message']) || empty($args['message'])){
			throw new Exception('Message is required');
		} 	
		$message_body = 'There is an enquiry from<br/>';
		$message_body .= 'Name : '.wp_strip_all_tags($args['name']).'<br/>';
		$message_body .= 'Email : '.wp_strip_all_tags($args['email']).'<br/>';
		$message_body .= 'Message : '.wp_strip_all_tags($args['message']).'<br/>';	
		$subject = 'Enquiry Mail';
		$to = get_option('admin_email');
		$headers =array("Content-Type: text/html; charset=UTF-8");	
		if(empty($to)):
			throw new Exception('Server Error. Unable to send mail');
		endif;
		$response = wp_mail($to, $subject, $message_body,$headers);	
		if(!$response):	
			throw new Exception('Server Error. Unable to send mail');
		else:
			$data = array('message' => 'Mail send successfully');
			return new WP_REST_Response($data, 200);	
		endif;	
			
		} catch(Exception $e){
			$data = array('message' => $e->getMessage());
			return new WP_REST_Response($data, 400);
		}
	}
	
	public function rentzon_set_reset_password($args){
		try{
			$url = site_url().'/wp-json/bdpwr/v1/set-password';
			$errors = array();
			if(!isset($args['email'])):
			 $errors[] ='Email is required';
			endif;
            if(!isset($args['code'])):
			  $errors[] = 'Code is required';
			endif;		
			 if(!isset($args['password'])):
			  $errors[] ='Password is required';
			endif;
			if(count($errors)> 0) {
				throw new Exception(json_encode($errors));
			}
			$args = array(
				'method' => 'POST',
				'body' => array('email' => $args['email'], 'code' => $args['code'], 'password' =>$args['password'] )	
			);
			if (function_exists("wp_remote_request")) {
         		$response = wp_remote_request($url, $args);
				$response_body = wp_remote_retrieve_body($response);
				if(isset($response_body)):
				$response_body =json_decode($response_body);
					if(isset($response_body->message)):
					$data =array('message' => $response_body->message);
					endif;	
				endif;
				$response_code = wp_remote_retrieve_response_code($response);
				return new WP_REST_Response($data, $response_code);
     		}
		} catch(Exception $e) {
			
			$data = array('message' => $e->getMessage());
			return new WP_REST_Response($data, 400);
		}
	}
	
	public function rentzon_set_forget_password($args){
		$url = site_url().'/wp-json/bdpwr/v1/reset-password';
		try{
		if(!isset($args['email']) || empty($args['email'])):
			throw new Exception('Email is required');
		endif;	
		$args = array(
		'method' => 'POST',
		'body' => array('email' => $args['email'])	
		);
			if (function_exists("wp_remote_request")) {
         		$response = wp_remote_request($url, $args);
				$response_body = wp_remote_retrieve_body($response);
				if(isset($response_body)):
				$response_body =json_decode($response_body);
					if(isset($response_body->message)):
					$data =array('message' => $response_body->message);
					endif;	
				endif;
				$response_code = wp_remote_retrieve_response_code($response);
				return new WP_REST_Response($data, $response_code);
     		}
		} catch(Exception $e){
			$data = array('message' => $e->getMessage());
			return new WP_REST_Response($data, 400);
		}	
	}
	
	public function rentzon_get_all_sliders(){
		$args = array(
		    'post_type' => 'sliders',
		    'posts_per_page' => 3,
		    'orderby'        => 'date',
			'order'          => 'ASC'
		);
		$main_slider=[];
		$loop = new wp_Query($args);
		if ( $loop->have_posts() ) :
			while($loop->have_posts()) : $loop->the_post();
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );
			$mobimage = get_post_meta( get_the_ID(), 'mobile_banner', true );
		    $product = get_field('product',get_the_ID());
		    $coupon = get_field('coupon_code',get_the_ID());
		    $cost = get_field('cost',get_the_ID());
			$product_id = null;
		    if(!empty($product)):
		      $product_id = $product->ID;
		    endif;
		    $coupon_code =null;
			if(!empty($coupon)):
		      $coupon_code = $coupon;
		    endif;
			$image_attributes = wp_get_attachment_url( $mobimage );
		$main_slider[] = array('image' => $image[0], 'mobile_image' => $image_attributes ,'product_id' => $product_id, 'coupon_code' => $coupon_code , 'cost' => !empty($cost) ? $cost : null  );
		endwhile;
		endif;
		$args = array( 'post_type' => 'footerad', 'orderby'=>'menu_order', 'order' => 'ASC' ); 
		
        $loop = new WP_Query( $args );
		$footer_sliders=[];
		if ( $loop->have_posts() ) :
			while($loop->have_posts()) : $loop->the_post();
			 $image = get_field('footer_ad_image');
			$product = get_field('product',get_the_ID());
		    $coupon = get_field('coupon_code',get_the_ID());
		    $cost = get_field('cost',get_the_ID());
			$product_id = null;
		    if(!empty($product)):
		      $product_id = $product->ID;
		    endif;
		    $coupon_code =null;
			if(!empty($coupon)):
		      $coupon_code = $coupon;
		    endif;
			$footer_sliders[] = array('image' => $image,'product_id' => $product_id, 'coupon_code' => $coupon_code , 'cost' => !empty($cost) ? $cost : null  );
			endwhile;
		endif;
		$data = (object)array('main_sliders' => $main_slider, 'footer_sliders'=> $footer_sliders);
    	return $data;	 
	}
	
	public function rentzon_get_states(){
		$args = array('numberposts' => -1 , 'post_type' => 'locations', 'post_status' => 'publish');
		$results = get_posts($args);
		$locations =array();
		if(is_array($results)):
		  foreach($results as $location):
			$sub_locations = get_fields($location->ID);
			$loc = array('main_location' => $location->post_title, 'sub_locations' => isset($sub_locations['sub_locations']) ?$sub_locations['sub_locations'] : [] );
			$locations[] =$loc;
		  endforeach;
		endif;
		return $locations;
	}
    
    public function set_billing_address($args){
      try{
          if(!isset($args['id'])):
           throw new Exception('No user id specidied');
          endif;
          $customer = new WC_Customer( wp_strip_all_tags($args['id'] ));
          $response = array();
          if(isset($args['c_pwd'])):
            $userdata = get_user_by('id', $args['id']);
            $result = wp_check_password(wp_strip_all_tags($args['c_pwd'] ), $userdata->user_pass, $userdata->ID);
            if(!$result):
             throw new Exception('wrong current password');
            endif;
		    if(!isset($args['n_pwd'])):
		      throw new Exception('No new password provided');
		    endif;
            wp_set_password($args['n_pwd'], $args['id']);
          endif;
          
       // Customer billing information details (from account)
        if(isset($args['billing_first_name'])):
          $customer->set_billing_first_name(wp_strip_all_tags($args['billing_first_name'] ));
        endif;
        if(isset($args['billing_last_name'])):
          $customer->set_billing_last_name(wp_strip_all_tags($args['billing_last_name'] ));
        endif;
        if(isset($args['billing_company'])):
          $customer->set_billing_company(wp_strip_all_tags($args['billing_company'] ));
        endif;
        if(isset($args['billing_address_1'])):
          $customer->set_billing_address_1(wp_strip_all_tags($args['billing_address_1'] ));
        endif;
        if(isset($args['billing_address_1'])):
          $customer->set_billing_address_1(wp_strip_all_tags($args['billing_address_1'] ));
        endif;
        if(isset($args['billing_address_2'])):
          $customer->set_billing_address_2(wp_strip_all_tags($args['billing_address_2'] ));
        endif;
        if(isset($args['billing_city'])):
          $customer->set_billing_city(wp_strip_all_tags($args['billing_city'] ));
        endif;
        if(isset($args['billing_state'])):
          $customer->set_billing_state(wp_strip_all_tags($args['billing_state'] ));
        endif;
        if(isset($args['billing_postcode'])):
          $customer->set_billing_postcode(wp_strip_all_tags($args['billing_postcode'] ));
        endif;
        if(isset($args['billing_country'])):
          $customer->set_billing_country(wp_strip_all_tags($args['billing_country'] ));
        endif;
        if(isset($args['billing_phone'])):
          $customer->set_billing_phone(wp_strip_all_tags($args['billing_phone'] ));
        endif;
      
        // Customer shipping information details (from account)
        
        if(isset($args['shipping_first_name'])):
          $customer->set_shipping_first_name(wp_strip_all_tags($args['shipping_first_name'] ));
        endif;
        if(isset($args['shipping_last_name'])):
          $customer->set_shipping_last_name(wp_strip_all_tags($args['shipping_last_name'] ));
        endif;
        if(isset($args['shipping_company'])):
          $customer->set_shipping_company(wp_strip_all_tags($args['shipping_company'] ));
        endif;
        if(isset($args['shipping_address_1'])):
          $customer->set_shipping_address_1(wp_strip_all_tags($args['shipping_address_1'] ));
        endif;
        if(isset($args['shipping_address_2'])):
          $customer->set_shipping_address_2(wp_strip_all_tags($args['shipping_address_2'] ));
        endif;
        if(isset($args['shipping_city'])):
          $customer->set_shipping_city(wp_strip_all_tags($args['shipping_city'] ));
        endif;
        if(isset($args['shipping_state'])):
          $customer->set_shipping_state(wp_strip_all_tags($args['shipping_state'] ));
        endif;
        
        if(isset($args['shipping_postcode'])):
          $customer->set_shipping_postcode(wp_strip_all_tags($args['shipping_postcode'] ));
        endif;
        if(isset($args['shipping_country'])):
          $customer->set_shipping_country(wp_strip_all_tags($args['shipping_country'] ));
        endif;
        if(isset($args['first_name'])):
          $customer->set_first_name(wp_strip_all_tags($args['first_name'] ));
        endif;
        if(isset($args['last_name'])):
          $customer->set_last_name(wp_strip_all_tags($args['last_name'] ));
        endif;
        
        if(isset($args['display_name'])):
          $r= $customer->set_display_name(wp_strip_all_tags($args['display_name'] ));
        endif;
        if(isset($args['billing_email'])):
          $customer->set_email(wp_strip_all_tags($args['billing_email'] ));
        endif;
        $customer->save();
        $response =array('message' => 'successfully updated details');
        wp_send_json($response,200);
      }
      catch (Exception $error) {
           return new WP_Error(400 ,$error->getMessage(),array( 'status' => 400 ));
      }
    }
	
	public function cancel_bookings_by_id($args){
		try{
		$booking_id = isset($args['id']) ? $args['id']: null;
        if(!$booking_id):
          throw new Exception('booking id not found');
        endif;
        $booking = new YITH_WCBK_Booking($booking_id,array());
		if(!$booking->get_status()):
			throw new Exception('booking id not found');
		endif;	
		$booking->update_status('cancelled');	
		return wp_send_json('cancelled booking id '.$booking_id,200 );	
		} catch(Exception $error) {
		 return new WP_Error('USER_BOOKINGS_ERROR' ,$error->getMessage(), array( 'status' => 400 ));	
		}
	}
	
	public function get_bookings_by_id($args){
        try{
        $booking_id = isset($args['id']) ? $args['id']: null;
        if(!$booking_id):
          throw new Exception('booking id not found');
        endif;
        $booking = new YITH_WCBK_Booking($booking_id,array());
		if(!$booking->get_status()):
			throw new Exception('booking id not found');
		endif;
		$results['booking_id'] = $booking_id;	
        $results['status'] = $booking->get_status_text();
		$results['order_id'] = apply_filters('yith_wcbk_booking_details_order_id',$booking->get_order_id());
		$results['can_be_cancelled'] =$booking->can_be('cancelled_by_user');	
	    $results['title'] = $booking->get_title();
         $results['duration'] = $booking->get_duration_html ();
        if ( $product = wc_get_product( $booking->get_product_id() ) ) :
         $results['product_id'] = $product->get_id();
         $results['product_name'] = $product->get_title();
        endif;
        $results['from'] = $booking->get_formatted_date( 'from' );
        $results['to'] = $booking->get_formatted_date( 'to' );
        
        if ( empty($booking->has_persons )) :
         $results['persons'] =  $booking->persons;
        endif;

        if ( !empty($booking->person_types )) :
            foreach ( $booking->person_types as $person_type ) :
            if ( !$person_type[ 'number' ] )
                continue;
			
            $person_type_id     = absint( $person_type[ 'id' ] );
            $person_type_title  = YITH_WCBK()->person_type_helper->get_person_type_title( $person_type_id );
            $person_type_title  = !!$person_type_title ? $person_type_title : $person_type[ 'title' ];
            $person_type_number = absint( $person_type[ 'number' ] );
            $results['person_types'][] = array('name' => $person_type_title, 'count' => $person_type_number );
            endforeach;
        endif;
        return $results;
        } catch(Exception $error) {
           return new WP_Error('USER_BOOKINGS_ERROR' ,$error->getMessage(), array( 'status' => 400 ));   
        }
    }
    
    public function get_user_bookings($args){
        try{
        $user_id = isset($args['id']) ? $args['id']: null;
        $page = isset($args['page']) ? $args['page'] :1;
        $numberofposts = isset($args['limit']) ? $args['limit'] :-1;
        if(!$user_id):
          throw new Exception('user id not found');
        endif;        
        $yith_get_bookings = new YITH_WCBK_Booking_Helper();
        $args = array(
            'meta_key'   => '_user_id',
            'meta_value' => $user_id,
            'posts_per_page' => $numberofposts,
            'paged' => $page
        );
        $bookings = $yith_get_bookings->get_bookings($args, 'bookings');
        $results = array();
        foreach($bookings as $booking ):
          $results[] = array('id' => $booking->get_id(),'title' => $booking->get_title(), 'status' => $booking->get_status_text(), 'from' => $booking->get_formatted_date( 'from' ), 'can_be_cancelled' => $booking->can_be('cancelled_by_user'), 'to' => $booking->get_formatted_date( 'to' ));
        endforeach;
         return $results;
        }catch( Exception $error ){
          return new WP_Error('USER_BOOKINGS_ERROR' ,$error->getMessage(), array( 'status' => 400 ));  
        }
    }
	public function view_single_order($args){
        try{
        $id = isset($args['id']) ? $args['id'] : null;
        if(!$id):
         throw new Exception('No order id found');
        endif; 
        $order = wc_get_order($id);
		if(!$order):
		throw new Exception('No order found');
		endif;	
        $order_details['id'] = $order->get_id();
        $created_date= $order->get_date_created('edit')->format('c');
        $created_date = isset($created_date) ? date_format(date_create($created_date), 'F d, Y'): null;
        $order_details['created_date'] =$created_date;
        $order_details['status'] =$order->get_status();
        $order_details['total'] =$order->get_total();
        $order_details['subtotal'] =$order->get_subtotal();
        $order_details['shipping_total'] =$order->get_shipping_total();
        $order_details['discount_total'] =$order->get_discount_total();
        $items = $order->get_items();
        $order_details['items']=array();
		$order_details['related_bookings']=array();
		//  get_bookings_by_order	
		$order_id = yit_get_prop( $order, 'id', true, 'edit' );
		$bookings = YITH_WCBK()->booking_helper->get_bookings_by_order( $order_id );
		$booking_details = apply_filters( 'yith_wcbk_order_bookings_related_to_order', $bookings, $order );
		if(!empty($booking_details)):
		foreach($booking_details as $booking):
		
		if(!$booking->post):
		 continue;
		endif;	
		$data = array('id'=> $booking->post->ID);	
		$order_details['related_bookings'][] = $this->get_bookings_by_id($data);
		endforeach;	
		endif;	
        if(is_array($items)):
         foreach($items as $item):
		 $addons =	$item->get_meta('_ywapo_meta_data');
		 $vendor =YITH_Vendor::retrieve($item->get_product_id(),'product');
		 $vendor_name = $vendor->name;
	     $addons = empty($addons) ? array(): $addons;		
          $order_details['items'][] = array('name' => $item->get_name(), 'quantity' => $item->get_quantity(), 'addons' => $addons   ,'price' =>$item->get_total(), 'vendor_name' =>$vendor_name  ); 
         endforeach;
        //add billing details 
        $order_details['billing_first_name'] = $order->get_billing_first_name();
        $order_details['billing_last_name'] = $order->get_billing_last_name();
        $order_details['billing_address_1'] = $order->get_billing_address_1();
        $order_details['billing_address_2'] = $order->get_billing_address_2();
        $order_details['billing_company'] = $order->get_billing_company();
        $order_details['billing_city'] =  $order->get_billing_city();
        $order_details['billing_state'] =  $order->get_billing_state();
        $order_details['billing_postcode']=  $order->get_billing_postcode();
        $order_details['billing_country']=  $order->get_billing_country();
        $order_details['billing_email'] = $order->get_billing_email();
        $order_details['billing_phone'] = $order->get_billing_phone();
        
        //shipping details
        $order_details['shipping_first_name'] = $order->get_shipping_first_name();
        $order_details['shipping_last_name'] = $order->get_shipping_last_name();
        $order_details['shipping_address_1'] = $order->get_shipping_address_1();
        $order_details['billing_address_2'] = $order->get_shipping_address_2();
        $order_details['shipping_company'] = $order->get_billing_company();
        $order_details['shipping_city'] =  $order->get_shipping_city();
        $order_details['shipping_state'] =  $order->get_shipping_state();
        $order_details['shipping_postcode']=  $order->get_shipping_postcode();
        $order_details['shipping_country']=  $order->get_shipping_country();
         
          return wp_send_json_success($order_details,200);  
        endif;    
        } catch( Exception $error) {
          return new WP_Error('MY_ORDER_ERROR' ,$error->getMessage(), array( 'status' => 400 ));  
        }
    }
	
	public function get_user_orders($args){
        try{
          $user_id = isset($args['id']) ? wp_strip_all_tags($args['id']) : null;
          $posts_per_page = isset($args['limit']) ? wp_strip_all_tags($args['limit']) : -1;
          $page = isset($args['page']) ? wp_strip_all_tags($args['page']) : 1;
          if(!$user_id):
            throw new Exception('No user id found');
          endif;
          $user = get_userdata( $user_id );
          if(!$user):
             throw new Exception('No user found for this id');
          endif;
          $args = array(
			'post_parent'=> 0,  
            'customer_id' => $user_id,
            'limit' => $posts_per_page,
            'page' => $page
          );
          $orders = wc_get_orders($args);
          $order_details = array();
          
          if(is_array($orders)):
           foreach($orders as $order):
			$order_actions = wc_get_account_orders_actions($order);
			$order_status = $order->get_status();
			$cancellable = array_key_exists('cancel', $order_actions);
			$payable = array_key_exists('pay', $order_actions);
            $created_date= $order->get_date_created('edit')->format('c');
            $created_date = isset($created_date) ? date_format(date_create($created_date), 'F d, Y'): null;
             $order_details[]=array('id' => $order->get_id(), 'created' =>$created_date ,'status' => $order_status,'count' => $order->get_item_count(), 'total' => $order->get_total(),'payable' => $payable,'cancellable'=> $cancellable);
           endforeach;           
          endif; 
         return wp_send_json_success($order_details,200);           
        } catch(Exception $error){
          return new WP_Error('MY_ORDER_ERROR' ,$error->getMessage(), array( 'status' => 400 ));   
        }
    }
    
    
    public function remove_from_wishlist($args){
        $wishlist_id = isset($args['wishlist_id']) ? $args['wishlist_id'] : null;
        $product_id = isset($args['product_id']) ? $args['product_id'] : null;
        try{
        if($wishlist_id == null):
            throw new Exception( __( 'No wishlist found' ) );
        endif;
        if($product_id == null):
            throw new Exception( __( 'No Product id  found' ) );
        endif;
        $wishlist = YITH_WCWL_Wishlist_Factory::get_wishlist( $wishlist_id, 'edit' );
        
        if(! $wishlist instanceof YITH_WCWL_Wishlist || ! $wishlist->current_user_can( 'add_to_wishlist' )):
           throw new Exception( __( 'No wishlist found' ) );       
       endif;
        
        $removed = $wishlist->remove_product($product_id);
        if(!$removed):
          throw new Exception( __( 'No product was removed' ) ); 
        endif;
        $wishlist->save();
		 $items = array();
        foreach($wishlist->get_items() as $key => $item ):
        $product = wc_get_product($key);
         if($product):
		  $vendor = YITH_Vendor::retrieve($product->get_id(),'product');
		  $vendor_name= $vendor->name;	
	      $rating = $product->get_average_rating();
		 $rating = (float) number_format($rating, 1, '.', '');
		  $review_count = (int) $product->get_review_count();
           $items[] = array('product_id' => $key, 'prouct_name' => $product->get_title(), 'price' => $product->get_price(), 'stock'=>$product->get_stock_status(), 'image' => wp_get_attachment_url($product->get_image_id()), 'vendor' => $vendor_name,'rating' => $rating, 'review_count' => $review_count);
          endif; 
        endforeach; 	
        $data = array('message' => 'Successfully removed to wishlist', 'code' => 'WISHLIST_REMOVED', "wishlist_id"=> $wishlist->get_id(),'items_count' => $wishlist->count_items(),'data' => $items);
            wp_send_json_success($data,200);            
        } catch (Exception $error) {
           return new WP_Error('WISHLIST_ERROR' ,$error->getMessage(), array( 'status' => 400 )); 
        }
        
    }
    
    public function get_wishlist($args){
        $wishlist_id = isset($wishlist_id) ? $wishlist_id : 0;
        $wishlist = YITH_WCWL_Wishlist_Factory::get_wishlist( $wishlist_id, 'edit' );
        try{
			if( ! $wishlist instanceof YITH_WCWL_Wishlist || ! $wishlist->current_user_can( 'add_to_wishlist' ) ){
				throw new Exception( __( 'No wishlist found' ) );
			}
        $items = array();
        foreach($wishlist->get_items() as $key => $item ):
        $product = wc_get_product($key);
         if($product):
		  $vendor = YITH_Vendor::retrieve($product->get_id(),'product');
		  $vendor_name= $vendor->name;	
	      $rating = $product->get_average_rating();
		 $rating = (float) number_format($rating, 1, '.', '');
		  $review_count = (int) $product->get_review_count();
           $items[] = array('product_id' => $key, 'prouct_name' => $product->get_title(), 'price' => $product->get_price(), 'stock'=>$product->get_stock_status(), 'image' => wp_get_attachment_url($product->get_image_id()), 'vendor' => $vendor_name,'rating' => $rating, 'review_count' => $review_count);
          endif; 
        endforeach;           
        $data = array( 'code' => 'GET_WISHLIST', "wishlist_id"=> $wishlist->get_id(),'items_count' => $wishlist->count_items(),'data' => $items );
            wp_send_json_success($data,200);
        } catch(Exception $err){
          return new WP_Error('CANNOT FIND THE WISHLIST' ,$error->getMessage(), array( 'status' => 400 ));   
        }            
    }
    
    /*get billing address of user*/
    public function get_billing_address($args){
      try{
          if(!isset($args['id'])):
           throw new Exception('No user id specidied');
          endif;
          $customer = new WC_Customer( wp_strip_all_tags($args['id'] ));
          $response = array();
          $response['first_name']   = $customer->get_first_name();
          $response['last_name']   = $customer->get_last_name();
          $response['display_name']   = $customer->get_display_name();
          $response['billing_email']   = $customer->get_email(); // Get account
          $response['billing_phone']   = get_user_meta(wp_strip_all_tags($args['id']), 'billing_phone', true );
// Customer billing information details (from account)
        $response['billing_first_name'] = $customer->get_billing_first_name();
        $response['billing_last_name']  = $customer->get_billing_last_name();
        $response['billing_company']    = $customer->get_billing_company();
        $response['billing_address_1']  = $customer->get_billing_address_1();
        $response['billing_address_2']  = $customer->get_billing_address_2();
        $response['billing_city']       = $customer->get_billing_city();
        $response['billing_state']      = $customer->get_billing_state();
        $response['billing_postcode']   = $customer->get_billing_postcode();
        $response['billing_country']    = $customer->get_billing_country();

        // Customer shipping information details (from account)
        $response['shipping_first_name'] = $customer->get_shipping_first_name();
        $response['shipping_last_name']  = $customer->get_shipping_last_name();
        $response['shipping_company']    = $customer->get_shipping_company();
        $response['shipping_address_1']  = $customer->get_shipping_address_1();
        $response['shipping_address_2']  = $customer->get_shipping_address_2();
        $response['shipping_city']       = $customer->get_shipping_city();
        $response['shipping_state']      = $customer->get_shipping_state();
        $response['shipping_postcode']   = $customer->get_shipping_postcode();
        $response['shipping_country']   = $customer->get_shipping_country();
        wp_send_json($response,200);
      }
      catch (Exception $error) {
           return new WP_Error(400 ,$err->getMessage(),array( 'status' => 400 ));
      }
    }
    
    
    /*add to wishlist */
   public function add_to_wishlist($args){
        $defaults = array(
				'add_to_wishlist'     => 0,
				'wishlist_id'         => 0,
				'quantity'            => 1,
				'user_id'             => false,
				'dateadded'           => '',
				'wishlist_name'       => '',
				'wishlist_visibility' => 0
			);

            try{
            $atts['add_to_wishlist'] = isset($args['product_id']) ? $args['product_id'] : 0; 
            $atts['user_id'] = get_current_user_id();
            $atts['wishlist_id'] = isset($args['wishlist_id']) ? $args['wishlist_id'] : 0; 
			$atts = wp_parse_args( $atts, $defaults );
			// filtering params
			$prod_id     = apply_filters( 'yith_wcwl_adding_to_wishlist_prod_id', intval( $atts['add_to_wishlist'] ) );
			$wishlist_id = apply_filters( 'yith_wcwl_adding_to_wishlist_wishlist_id', $atts['wishlist_id'] );
			$quantity    = apply_filters( 'yith_wcwl_adding_to_wishlist_quantity', intval( $atts['quantity'] ) );
			$user_id     = apply_filters( 'yith_wcwl_adding_to_wishlist_user_id', intval( $atts['user_id'] ) );
			$dateadded   = apply_filters( 'yith_wcwl_adding_to_wishlist_dateadded', $atts['dateadded'] );
   
			if ( $prod_id == false  || !wc_get_product($prod_id)) {
				throw new Exception( __( 'Prouct does not exist' ) );
			}

			$wishlist = YITH_WCWL_Wishlist_Factory::get_wishlist( $wishlist_id, 'edit' );

			if( ! $wishlist instanceof YITH_WCWL_Wishlist || ! $wishlist->current_user_can( 'add_to_wishlist' ) ){
				throw new Exception( __( 'An error occurred while adding the products to the wishlist.' ) );
			}

			if( $wishlist->has_product( $prod_id ) ) {
				throw new Exception( __( 'Product already in wishlist' ) );
			}

			$item = new YITH_WCWL_Wishlist_Item();

			$item->set_product_id( $prod_id );
			$item->set_quantity( $quantity );
			$item->set_wishlist_id( $wishlist->get_id() );
			$item->set_user_id( $wishlist->get_user_id() );

			if( $dateadded ){
				$item->set_date_added( $dateadded );
			}

			$wishlist->add_item( $item );
			$wishlist->save();
            $data = array('message' => 'Successfully added to wishlist', 'code' => 'WISHLIST_ADDED', "wishlist_id"=> $wishlist->get_id(),'items_count' => $wishlist->count_items());
            wp_send_json_success($data,200);            
         
           } catch(Exception $error) {
              return new WP_Error('NOT_ADDED_TO_WISHLIST' ,$error->getMessage(), array( 'status' => 400 ));   
           }
    }
    
    public function rentzon_get_current_user($request){
    	$authorization =$request->get_header('authorization');
    	$body=null;
    	$user = wp_get_current_user();
    	if($user):
    	$body['email'] = $user->user_email ;
    	$body['nicename'] = $user->user_nicename ;
        $body['user_id'] = $user->ID;
        $body['username'] = $user->user_login;
        $body['firstName'] = get_user_meta($user->ID, 'first_name',true);
        $body['lastName'] = get_user_meta($user->ID, 'last_name',true);
        $body['mobile'] = get_user_meta($user->ID, 'billing_phone',true);
    	 
    	endif;
    	if(!$body)
    		 return new WP_Error(400,'No user found');  
    	
    	return $body;	
    }

    public function rentzon_get_sliders(){
		$args = array(
		    'post_type' => 'sliders',
		    'posts_per_page' => 3,
		    'orderby'        => 'date',
			'order'          => 'ASC'
		);
		$data=[];
		$loop = new wp_Query($args);
		$i=1;
		if ( $loop->have_posts() ) :
			while($loop->have_posts()) : $loop->the_post();
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );
			$mobimage = get_post_meta( get_the_ID(), 'mobile_banner', true );
			$image_attributes = wp_get_attachment_url( $mobimage );
		$data[$i]['image']=$image[0];
		$data[$i]['mobile_image']=$image_attributes;	
		$i++;
		endwhile;
		endif;
    	return $data;	
    }
}

$general_api =new YITH_GENERAL_API();
?>