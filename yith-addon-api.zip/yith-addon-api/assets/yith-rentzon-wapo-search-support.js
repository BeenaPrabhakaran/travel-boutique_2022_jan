jQuery( function ($) {
   
 $('.yith-wcbk-booking-start-date').attr('required',true);
  $('.yith-wcbk-booking-start-date').removeAttr('readonly');
 $('.yith-wcbk-booking-start-date').attr('onkeypress',"return false");
 $('.yith-wcbk-booking-location').attr('required',true);
 $('.yith-wcbk-booking-search-form-row-categories >.yith-wcbk-booking-categories').removeAttr('multiple');
});
