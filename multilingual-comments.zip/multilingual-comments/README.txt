=== Multilingual Comments ===
Contributors: yame, tsjemo
Tags: wpml, woocommerce, reviews, multilingual, comments, review, comment
Requires at least: 3.0.0
Tested up to: 5.1.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Multilingual Comments is an add-on for WPML / WooCommerce. This plugin makes it possible via its own plugin settings, to show: comments on blog posts in all languages & product reviews in all languages (also the average rating will be calculated as 1 total)

== Description == 

Multilingual Comments is an add-on for WPML / WooCommerce. This plugin makes it possible via its own plugin settings, to show
- comments on blog posts in all languages
- product reviews in all languages (also the average rating will be calculated as 1 total)

For example, if a WooCommerce product has
- 4 English reviews
- 7 French reviews
- 5 Dutch reviews
the product will have 16 reviews, no matter which language is selected.

== Changelog ==

= 1.0 =
* Initial release

= 1.0.1 =
* Bugfix - Division by zero when there are 0 comments