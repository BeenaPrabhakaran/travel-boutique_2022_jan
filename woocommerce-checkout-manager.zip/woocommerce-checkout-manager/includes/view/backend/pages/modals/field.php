<script type="text/html" id='tmpl-wooccm-modal-main'>
<?php include_once( 'parts/main.php' ); ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-tabs'>
<?php include_once( 'parts/tabs.php' ); ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-panels'>
<?php include_once( 'parts/panel-general.php' ); ?>
<?php include_once( 'parts/panel-select2.php' ); ?>
<?php include_once( 'parts/panel-options.php' ); ?>
<?php include_once( 'parts/panel-filter.php' ); ?>
<?php include_once( 'parts/panel-display.php' ); ?>
<?php include_once( 'parts/panel-price.php' ); ?>
<?php include_once( 'parts/panel-datepicker.php' ); ?>
<?php include_once( 'parts/panel-timepicker.php' ); ?>
<?php include_once( 'parts/panel-admin.php' ); ?>
</script>
<script type="text/html" id='tmpl-wooccm-modal-info'>
  <?php include_once( 'parts/info.php' ); ?>
</script>