<ul class="subsubsub">
  <?php do_action('wooccm_sections_header'); ?>
  <li><a target="_blank" href="<?php echo WOOCCM_DOCUMENTATION_URL; ?>"><?php echo esc_html__('Documentation', 'woocommerce-checkout-manager'); ?></a></li>
</ul>
<br class="clear" />