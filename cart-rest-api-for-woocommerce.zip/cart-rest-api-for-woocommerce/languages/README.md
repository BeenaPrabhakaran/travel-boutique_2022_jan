# WARNING! DO NOT PUT CUSTOM TRANSLATIONS HERE!

CoCart Lite will delete all custom translations placed in this directory.

## Translating CoCart Lite

Put your custom CoCart Lite translations in your WordPress language directory, located at: `WP_LANG_DIR . "/cart-rest-api-for-woocommerce/{$textdomain}-{$locale}.mo";`

## Contributing your translating to CoCart Lite

If you want to help translate CoCart Lite, please visit our [translation page](https://translate.wordpress.org/projects/wp-plugins/cart-rest-api-for-woocommerce).

The alternative is to translate CoCart Lite on [translate.cocart.xyz](https://translate.cocart.xyz/projects/cart-rest-api-for-woocommerce/)

If CoCart Lite is already 100% translated for your language, join the team anyway!