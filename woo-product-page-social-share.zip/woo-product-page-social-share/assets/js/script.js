jQuery( document ).ready( function( $ ) {

	$( '.wpss_social_share_buttons' ).css( 'visibility', 'visible' );
});