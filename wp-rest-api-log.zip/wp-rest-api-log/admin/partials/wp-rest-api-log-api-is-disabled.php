<div class="wrap wp-rest-api-log-wrap">

	<h2><?php esc_html_e( 'WP REST API Log', 'wp-rest-api-log' ); ?></h2>

	<div class="error">
		<p><?php esc_html_e( 'The WP REST API is not enabled', 'wp-rest-api-log' ); ?></p>
	</div>

</div>