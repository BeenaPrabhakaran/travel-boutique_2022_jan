=== Country Code Selector ===
Contributors: intolap
Donate link: http://www.intolap.com/
Tags: woocommerce checkout, shopp checkout, gravity form, contact form 7, phone number validator, phone field validator, country code selector
Requires at least: 5.6
Tested up to: 5.8
WC requires at least: 5.0
WC tested up to: 5.5
Requires PHP: 7.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://pages.razorpay.com/intolap

Country Code Selector uses a JavaScript base to allow customers checking out in WooCommerce, Shopp eCommerce, Contact form 7, Gravity form plugins select the country code using a dropdown field.

== Description ==

Country Code Selector uses a JavaScript base to allow customers checking out in WooCommerce, Shopp, Contact form 7, Gravity form plugins select the country code using a dropdown field.

Country Code Selector is a free to use plugin and so we request you to create a ticket for any support before you rate this plugin. We are here to fix any bugs discovered beyond our testing. If you are happy with the support please give us a boost with a 5-star rating which will keep us motivating for further development.

[+] Demo  [Click Here](http://demo.intolap.com/)

[+] PRO version [Click Here](https://www.intolap.com/product/country-code-selector-pro/)

[youtube https://www.youtube.com/watch?v=LZ0HYpsP-UE]

== Installation ==

1. Upload the plugin files to the WordPress

2. Activate the plugin in WordPress

3. Go to "Settings" > "Country Code Selector" page in admin panel

4. Setup the plugin as per your requirement.

== Frequently Asked Questions ==

= Does this plugin work with Woo Commerce? =

Yes

= Does this plugin work with Shopp plugin? =

Yes, but shopp plugin is not maintained since 2 years, so we do not gurantee. Please contact for [Support] (http://www.intolap.com/contact-us/)

= Does this plugin work with Gravity Forms? =

Yes

= Does this plugin work with Contact Form 7? =

Yes

= Can I have it on a different form plugin? =

Yes, [PRO version](https://www.intolap.com/product/country-code-selector-pro/) allows you to use the tool on any form.

= Can I have this plugin in any other language? =

Yes, you can use translation plugin like Loco Translate or even add the translation files to the plugin's /language directory.

== Screenshots ==

1. admin.png
2. woocommerce.png
3. gform.png
4. cform7.png

== Changelog ==

= 1.6 =
* Compatibility tested for WordPress 5.7 and WooCommerce 5.2
* Country list fetch done using cURL instead of file_get_content(). So, cURL module must be installed on the server to use this plugin.

= 1.5 =
* Added 'Select All' options for country selection on admin UI.
* Added 'Clear All' options for country selection on admin UI.

= 1.4 =
* Fixed JS validation on the respective forms' phone field. Form was submitting even if the phone number is blank.
* Added translation capability to the plugin. Can use translation plugin like Loco Translate to translate this plugin to any language.

= 1.3 =
* Enhanced admin settings page with more control.
* Mandatory Country Code Selector JS validation on Gravity Forms
* Mandatory Country Code Selector validation on Contact Form 7

= 1.2 =
* Enhanced admin settings with more control on how Country Code Selector behave.
* Update Country Code Selector on woocommerce billing phone field onChange of woocommerce billing country select dropdown and vice-versa.
* Added Country Code Selector support for Gravity Forms
* Added Country Code Selector support for Contact Form 7
* Optional JS validator of the phone number using WC UTIL library.

= 1.1.0 =
* Initial version release