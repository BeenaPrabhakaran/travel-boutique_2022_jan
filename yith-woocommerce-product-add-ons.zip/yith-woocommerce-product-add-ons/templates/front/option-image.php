<?php
/**
 * WAPO Template
 *
 * @author  Corrado Porzio <corradoporzio@gmail.com>
 * @package YITH\ProductAddOns
 * @version 2.0.0
 *
 * @var YITH_WAPO_Addon $addon
 * @var int $x
 * @var string $option_image
 * @var string $hide_option_images
 * @var string $setting_hide_images
 * @var string $addon_options_images_position
 */

defined( 'YITH_WAPO' ) || exit; // Exit if accessed directly.

if ( $addon->get_option( 'show_image', $x ) && '' !== $option_image && ! $hide_option_images && 'yes' !== $setting_hide_images ) : ?>

	<div class="image position-<?php echo esc_attr( $addon_options_images_position ); ?> dtlflpic">
		<img src="<?php echo esc_attr( $option_image ); ?>" style="width:170px;height:110px;">
	</div>

<?php endif; ?>
