<?php
/**
 * WAPO Hooks
 *
 * @author  Corrado Porzio <corradoporzio@gmail.com>
 * @package YITH\ProductAddOns
 * @version 2.0.0
 */

// No hooks at the moment.
