=== WC Place Order Without Payment ===
Contributors: nitin247
Donate link: https://nitin247.com/buy-me-a-coffee
Tags: Checkout without payment,Woocommerce complete orders without payment, Order without payment, Checkout without payment in woocommerce, Disable payment functionality, Woocommerce payment disable, cart without payment, direct place order
Requires at least: 4.0
Tested up to: 5.8
Stable tag: 4.5
Version: 2.1
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Place Order Without Payment for WooCommerce will allow users to place orders directly without payment.

== Description ==

WC Place Order Without Payment will allow users to place orders directly.
This plugin will customize checkout page and offers to direct place order without payment.

After Installing this plugin, Payment system will be removed from checkout page of woocommerce and users can directly place order without payment.

This plugin is open for new feature request. Just create a request in plugin support

Plugin Features

1- Functionality to hide payment section from woocommerce site.

2- Direct Complete Order Without Payment.

3- Disable Payment Functionality in Woocommerce.

4- Complete orders without payment in woocommerce.

5- Fully Tested with latest wordpress and woocommerce versions.


== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `wc-place-order-without-payment` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. You are done.


== Screenshots ==


== Frequently Asked Questions ==
 
= How to setup Place order without payment? =
Activate the plugin through the 'Plugins' menu in WordPress, nothing more needs to be done.

= Does this plugin support latest woocommerce version? =
Yes, this plugin supports latest WooCommerce version.

= What is the default status after placing order? =
After placing order the order status is "Pending Payment" by default



== Changelog ==

** V 1.0 **
Stable initial release
** V 2.0 **
Plugin fix for woocommerce version 4.7
** V 2.1 **
CHanged default order status to processing instead of pending
