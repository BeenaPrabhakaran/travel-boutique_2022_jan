<?php

include_once( __DIR__ . '/api.route.reset-password.php' );
include_once( __DIR__ . '/api.route.set-password.php' );
include_once( __DIR__ . '/api.route.validate-code.php' );