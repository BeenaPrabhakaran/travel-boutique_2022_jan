<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- #content -->

	<?php get_template_part( 'template-parts/footer/footer-widgets' ); ?>
	<footer id="colophon" class="" role="contentinfo">
	    <div class="ftr1 float-left w-100 py-3 py-md-4">
                  <div class="container">
                     <div class="d-lg-flex justify-content-between w-100">
                        <span class="logo"><a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/Logo-blue.svg" alt=""></a></span>
                        <div>
                           <h3 class="float-left w-100">Download The RentZon Mobile App Today!</h3>
                           <div class="sub-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</div>
                        </div>
                        <span class="d-flex my-auto">
                        <a href="" class="mr-2"><img src="<?php echo get_stylesheet_directory_uri();?>/images/play-store.png" alt=""></a>
                        <a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/app-store.png" alt=""></a>
                        </span>
                     </div>
                  </div>
               </div>
               <div class="ftr2 float-left w-100 py-3 py-md-5">
                  <div class="container">
                     <div class="row">
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                           <ul class="ftr_menu m-0 p-0">
                              <li><a href="">About Us</a></li>
                              <li><a href="">Services</a></li>
                              <li><a href="">Products</a></li>
                              <li><a href="">Features</a></li>
                           </ul>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12">
                           <ul class="ftr_menu m-0 p-0">
                              <li><a href="">Refund Policy</a></li>
                              <li><a href="">Cancellation Policy</a></li>
                              <li><a href="">Privacy Policy</a></li>
                              <li><a href="">Terms And Conditions</a></li>
                           </ul>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12 mt-2 mt-lg-0">
                           <ul class="ftr_menu m-0 p-0">
                              <li><a href="">FAQ</a></li>
                              <li><a href="">Contact Us</a></li>
                           </ul>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-xs-12 mt-2 mt-lg-0">
                           <p class="text-uppercase">Connect with Us</p>
                           <ul class="social-icons m-0 pt-0 px-0 pb-3 border-bottom">
                              <li><a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/facebook-blue.svg" alt=""></a></li>
                              <li><a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/youtube-blue.svg" alt=""></a></li>
                              <li><a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/instagram-blue.svg" alt=""></a></li>
                              <li><a href=""><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/twitter-blue.svg" alt=""></a></li>
                           </ul>
                           <p class="text-uppercase mb-1 mt-3">SUPPORT HOTLINE</p>
                           <ul class="social-icons m-0 pt-0 px-0 pb-3">
                              <li><img src="<?php echo get_stylesheet_directory_uri();?>/images/icons/smartphone.svg" alt=""><span class="primary-text font-weight-bold ml-2">+1 (123) 456 78 90</span></li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="ftr3 float-left w-100 text-center py-2">
                  <p class="mb-0 text-white">© 2021 - 2025 rentzon.com</p>
               </div>
	    
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
