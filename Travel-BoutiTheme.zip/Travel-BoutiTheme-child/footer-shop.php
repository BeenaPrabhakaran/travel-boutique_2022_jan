<?php 
  $settingspost_id = '58';
  $lang = apply_filters( 'wpml_current_language', NULL ); 
  

  ?>
<?php if($lang == 'ar'){ ?>  
 <footer class="footarabi">
 <?php }else{?>
  <footer>
 <?php } ?>
  <div class="container">
  <input type="hidden" name="lang"  id="lang" value="<?php echo $lang ; ?>">
    <div class="row">
      <div class="col-lg-4">
        <div class="footlogo">
        <img src="<?php echo get_stylesheet_directory_uri();?>/images/footlogo.png">
       
      </div>
      <div class="footAddres">
        
        <?php if($lang == 'ar'){ ?> 
          <p class="d-flex pt-3"> <i class="adresLocicon" ></i>   <span style="padding-right:10px;">   
          <?php echo get_field('contact_address_footer_arabic',$settingspost_id);?></span></p>
        <?php }else{ ?>
          <p class="d-flex pt-3"><i class="adresLocicon"></i> <span>
          <?php echo get_field('contact_address_footer',$settingspost_id);?></span></p>

        <?php } ?>
        <?php if($lang == 'ar'){ ?> 
        <p class="d-flex pt-3"><i class="footEmailicon"></i>  <span style="padding-right:10px;">  
        <a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>" style="color:#fff;"><?php echo get_field('email_link',$settingspost_id);?></a></span></p>
            <?php } else{ ?>
              <p class="d-flex pt-3"><i class="footEmailicon"></i> <span>
        <a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>" style="color:#fff;"><?php echo get_field('email_link',$settingspost_id);?></a></span></p>

          <?php  } ?>
          <?php if($lang == 'ar'){ ?> 
          <p class="d-flex pt-3"><i class="footPhoneIcon"></i><span style="padding-right:10px;"><?php echo get_field('phone_number',$settingspost_id);?></span>
        </p>
      <?php } else{ ?>
          <p class="d-flex pt-3" ><i class="footPhoneIcon"></i><?php echo get_field('phone_number',$settingspost_id);?></p>

          <?php } ?>
      </div>
      </div>

      <div class="col-lg-3">
        <div class="footLinks">
        <?php if($lang == 'ar'){?>     
        <h2> <?php echo get_field('footer_quick_link_label_arabic',$settingspost_id);?></h2>
        <?php wp_nav_menu( array( 'container' => false,'menu_class'=>'menufootarabi','menu' => get_field('footer_links',$settingspost_id))); ?>
      <?php }else{ ?>
        <h2> <?php echo get_field('footer_quick_link_label',$settingspost_id);?></h2>
        <?php wp_nav_menu( array( 'container' => false,'menu_class'=>'','menu' => get_field('footer_links',$settingspost_id))); ?>
    
      <?php } ?>    </div>
      </div>

      <div class="col-lg-5">
      <div class="footLinks footSubscribe">
      <?php if($lang == 'ar'){ ?>  
        <div class="footLinks footSubscribe footarb">  
        <h2> <?php echo get_field('footer_subscription_section_label_arabic',$settingspost_id);?> </h2>   
        <?php echo do_shortcode( '[email-subscribers-form id="2"]' ); ?>
       </div>
      <?php }else{ ?>    
        <div class="footLinks footSubscribe foot">  
        <h2> <?php echo get_field('footer_subscription_section_label',$settingspost_id);?> </h2>
        <?php echo do_shortcode( '[email-subscribers-form id="2"]' ); ?>
        </div>
      <?php } ?>  

      </div>
      <?php if($lang== 'ar'){?> 
      <div class="footSocial" style="padding-top:0px;" >  
        <h2><?php echo get_field('footer_section_social_media_label_arabic',$settingspost_id);?></h2>
        <ul class="d-flex"> 
      <li><a href="<?php echo get_field('facebook_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/facebook.png"></li></a>
      <li><a href="<?php echo get_field('whatsapp_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/whatsapp.png"></li></a>
       <li><a href="<?php echo get_field('insta_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/instagram.png"></li></a>
        <li><a href="<?php echo get_field('youtube_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/youtube.png"></li></a>
      </ul>
      </div>
  
     <?php }else{?>
      <div class="footSocial"> 
      <h2><?php echo get_field('footer_section_social_media_label',$settingspost_id);?></h2>
      <ul class="d-flex"> 
      <li><a href="<?php echo get_field('facebook_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/facebook.png"></li></a>
      <li><a href="<?php echo get_field('whatsapp_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/whatsapp.png"></li></a>
       <li><a href="<?php echo get_field('insta_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/instagram.png"></li></a>
        <li><a href="<?php echo get_field('youtube_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/youtube.png"></li></a>
      </ul>
      </div>

     <?php } ?>
      </div>


    </div>
  </div>
</footer>
<section class="footBottombg">
  <div class="container">
    <div class="row">
    <div class="col-lg-6">
    <?php if($lang== 'ar'){?>    
      <?php echo get_field('copyright_text_arabic',$settingspost_id);?>
    <?php }else{?>
      <?php echo get_field('copyright_text',$settingspost_id);?>
     <?php } ?>  
      </div>
      <div class="col-lg-6">
        <div class="footMenu">
    <?php if($lang == 'ar'){ ?>
      <?php wp_nav_menu( array( 'container' => false,'menu' => get_field('footer_downside_menu_arabic',$settingspost_id),'items_wrap' => '<ul class="d-flex flex-wrap justify-content-end">%3$s</ul>' ) ); ?>
    <?php }else{ ?>
    <?php wp_nav_menu( array( 'container' => false,'menu' => get_field('footer_downside_menu',$settingspost_id),'items_wrap' => '<ul class="d-flex flex-wrap justify-content-end">%3$s</ul>' ) ); ?>
    <?php } ?> 
        
       </div>
      </div>
    </div>
  </div>
</section>





 <script src="<?php echo get_stylesheet_directory_uri();?>/js/jquery.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/owl.carousel.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/custom.js"></script>
  <script defer src="<?php echo get_stylesheet_directory_uri();?>/js/jquery.flexslider.js"></script>
   <script src="<?php echo get_stylesheet_directory_uri();?>/js/jquery-ui.min.js"></script>


 <script type="text/javascript">
  $(window).load(function() {
    // The slider being synced must be initialized first
    $('#carousel').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: true,
      itemMargin: 5,
      asNavFor: '#slider'
    });
  
    $('#slider').flexslider({
      animation: "slide",
      controlNav: false,
      animationLoop: false,
      slideshow: false,
      sync: "#carousel"
    });
  });


  $(function() {
    $( ".calendar" ).datepicker({
      dateFormat: 'dd-mm-yy',
      firstDay: 1
    });
    

    $(document).on('click', '.date-picker .input', function(e){
      var $me = $(this),
          $parent = $me.parents('.date-picker');
      $parent.toggleClass('open');
    });    
    
    $(".calendar").on("change",function(){
      var $me = $(this),
          $selected = $me.val(),
          $parent = $me.parents('.date-picker');
      $parent.find('.result').children('span').html($selected);
    });

  });
  


  $('.counter-count').each(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
          
          //chnage count up speed here
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });

    $('.counter-count').hover(function () {
        $(this).prop('Counter',0).animate({
            Counter: $(this).text()
        }, {
          
          //chnage count up speed here
            duration: 4000,
            easing: 'swing',
            step: function (now) {
                $(this).text(Math.ceil(now));
            }
        });
    });



        jQuery(window).load(function() {
            jQuery(".loader").fadeOut("slow");
         })
</script>

 
 <script>
  $(function() {
      $("#slider-range").slider({
        range: true,
        min: 0,
        max: 10000,
        values: [0, 10000],
        slide: function(event, ui) {
          $("#amount_min").val(ui.values[0]);
          $("#amount_max").val(ui.values[1]);
        }
      });
      $("#amount_min").val($("#slider-range").slider("values", 0));
      $("#amount_max").val($("#slider-range").slider("values", 1));
      $("#amount_min").change(function() {
        $("#slider-range").slider("values", 0, $(this).val());
      });
      $("#amount_max").change(function() {
        $("#slider-range").slider("values", 1, $(this).val());
      })

      $("#slider-range-product").slider({
        range: true,
        min: 0,
        max: 10000,
        values: [100, 10000],
        slide: function(event, ui) {
          $("#amount_min_prod").val(ui.values[0]);
          $("#amount_max_prod").val(ui.values[1]);
        }
      });
      $("#amount_min_prod").val($("#slider-range-product").slider("values", 0));
      $("#amount_max_prod").val($("#slider-range-product").slider("values", 1));
      $("#amount_min_prod").change(function() {
        $("#slider-range-product").slider("values", 0, $(this).val());
      });
      $("#amount_max_prod").change(function() {
        $("#slider-range-product").slider("values", 1, $(this).val());
      })
    });



    function PrcFilterchange(){  
      var lan = $("#lang").val(); 
      var catarray = [];
      var bgid  = $("#blogid").val();
      var min = $("#amount_min").val();
      var max = $("#amount_max").val();
      var city =  $('#city').val();


      alert(bgid);
      alert(min);
      alert(max);
      alert(city);

       $("input:checkbox[name=cate]:checked").each(function() {
          catarray.push($(this).val());
        });
        for (i = 0; i < catarray.length; ++i) {
            alert(catarray[i]);
        }
      $.ajax({
          type:'POST',
          data:{"action":"filterPrice","minprice": min,"maxprice":max,"catID": catarray,"blogid":bgid,"loca":city,"lang":lan },       
          url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php?lang="+lan,
          success: function(data) {
            $("#result").html(data); 
         
        }

      }); 
  }


 function sortChange(){
  var lan = $("#lang").val();
   var ordby  = $("#orderby").val();
   var prod  = $("#prodid").val();
   var pidarray = prod.split(',');
   var bgid  = $("#blogid").val();

   $.ajax({
          type:'POST',
          data:{"action":"sortProducts","prdorder": ordby,"prdval":pidarray,"bgval":bgid},       
         // url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php?lang="+lan,
         url: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
          success: function(data) {    
            alert(data);        
            $("#result").html(data);  
         
        }

      });
        
  } 

 


  </script> 
 <script>
  jQuery(document).ready(function($) {
    var lan = $("#lang").val();
    jQuery('#city').keypress(function() { 
            var cid = jQuery('#city').val();            
           // var ajaxurl= "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php?lang="+lan,
           var ajaxurl: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
            var data ={action: "searchLocation",  city:cid};
            $.post(ajaxurl, data, function (response){
                     // alert(response);
                $('#key').show();     
                $('#key').html(response);      
             });
            });
  });
 function exchangeVal(cityval){
      $('#city').val(cityval);   
 }
 

 function textSearch(){
    var serval =  $('#searchtext').val();
    var prod  = $("#prodid").val();
    var lan = $("#lang").val();
    var pidarray = prod.split(',');
    if($("#searchtext").val() ==''){
      $("#searchtext").addClass("error");
      return false;
         
    }else{
    
    $.ajax({
          type:'POST',
          data:{"action":"searchtextProducts","sertext": serval,"prdval":pidarray},       
         // var ajaxurl= "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php?lang="+lan,
         var ajaxurl: "http://3.234.242.230/travel-boutique-beta/wp-admin/admin-ajax.php?lang="+lan,
          success: function(data) {
            $("#result").html(data);
        }

      });
       $("#searchtext").removeClass("error");
    } 

 }
   
  </script>
   <script type="text/javascript">
    function resetlocal() {
        alert('hi');
        localStorage.removeItem("orderbgid");
        localStorage.removeItem("refcode");
       //localStorage.clear();
        alert(localStorage.getItem("orderbgid"));
        alert(localStorage.getItem("refcode"));
       }
    </script>
  <?php wp_footer();?>
</body>
</html>
