<?php
/*Template Name: Payment Status */
get_header();
?>
<section class="banner float-left w-100 position-relative">
 <div class="container">    
  <?php echo do_shortcode("[rdpg_payment_response]"); ?>
 </div>
 </section>
<?php 
get_footer();
?>
    