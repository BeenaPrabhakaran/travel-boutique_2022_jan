<?php
 /**
 * Template Name: Flash Page
 * 
 */
 get_header('shop'); 
 // global $yith_woocompare;   
 $lang = apply_filters( 'wpml_current_language', NULL );  
?>

<section class="pt-4">
<div class="container">
  <div class="row ">
    <div class="col-lg-12 col-12 order-2 order-lg-1 d-flex justify-content-center">
        <div class="hmHeadings">
        <?php if($lang == 'ar'){ ?>     
           <h2 class="bloggerlist"> <?php echo "المدونون"; ?> </h2>
        <?php }else{ ?>
          <h2 class="bloggerlist"> <?php echo "Bloggersssss"; ?> </h2>

       <?php }  ?> 
        </div>
    </div>
 </div>
   <div class="row" style="padding-top:20px;">
     <?php
        $pid = $_GET['id']; 
        global $wpdb;
        $tbl3 = $wpdb->prefix.'terms';
        $tbl4 = $wpdb->prefix.'blogger_product';
        $qry2 = "select bg.blogger_id, t.name,t.slug from " .$tbl4." bg ," .$tbl3 . " t 
                 where bg.blogger_id = t.term_id AND bg.product_id = ".$pid; 
                 
                 
                 echo "select bg.blogger_id, t.name,t.slug from " .$tbl4." bg ," .$tbl3 . " t 
                 where bg.blogger_id = t.term_id AND bg.product_id = ".$pid; 
      
        $resu2 = $wpdb->get_results( $qry2); 
        $row2 = count($resu2); //PHP count()
        foreach($resu2 as $res2){  
            $thumbvendor_id = get_term_meta($res2->blogger_id, 'avatar', true ); 
            $imagenow = wp_get_attachment_image_src( $thumbvendor_id); 
       ?>
     <div class="col-lg-3 pr-1 pl-1">
      <div class="bloggerBox">
      
      
      <div class="bloggerPic d-flex justify-content-center">
      <?php if($imagenow[0]){ ?>
        <?php if($lang == 'ar'){ ?>    
        <a href="#">
       <img src="<?php echo $imagenow[0];?>" alt="" ></a>
        <?php }else{ ?>
          <a href="#">
          <img src="<?php echo $imagenow[0];?>" alt="" ></a>

        <?php } ?>

          <?php } else { ?>
      <img src="<?php echo site_url();?>/wp-content/uploads/no-blogger.png" alt="">
     <?php } ?>
       </div>


     <div class="bloggerDetails">
     <?php if($lang == 'ar'){ 
     $arab = apply_filters( 'wpml_object_id',$res2->blogger_id,'vendors',false,'ar');     
      //echo 'arab'. $result->bgid; 
     ?>
        <h3><a href="<?php echo site_url();?>/ar/مدون/<?php echo get_term(icl_object_id($arab, 'vendors', false, 'ar'))->slug;?>/?orid=<?php echo $res2->blogger_id; ?>"><?php echo get_term(icl_object_id($arab, 'vendors', false, 'ar'))->name; ?></a></h3>
     <?php }else{ ?>
        <h3><a href="<?php echo site_url();?>/blogger/<?php echo $res2->slug; ?>"><?php echo $res2->name; ?></a>    </h3>
     <?php } ?> 
     <p> <?php echo limit_text($res2->description,12) ;?> </p>


    <?php /*

     <?php if($lang == 'ar'){ ?> 
        <h3> <a href="<?php echo site_url();?>/ar/blogger/<?php echo $res2->slug; ?>"><?php echo $res2->name; ?></a></h3>
      <?php }else{ ?>
         <h3> <a href="<?php echo site_url();?>/blogger/<?php echo $res2->slug; ?>"><?php echo $res2->name; ?></a></h3>
       <?php } ?> 
        <p> <?php echo limit_text($res2->description,12) ;?> </p> */ ?>
      </div>
      </div>
    </div>
    <?php  } ?>
     </div>
   </div>
 </section>
<?php get_footer('shop');?> 