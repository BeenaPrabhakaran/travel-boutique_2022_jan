<?php 
// This theme requires WordPress 5.3 or later.
if ( version_compare( $GLOBALS['wp_version'], '5.3', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'twenty_twenty_one_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 *
	 * @since Twenty Twenty-One 1.0
	 *
	 * @return void
	 */
	function twenty_twenty_one_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Twenty Twenty-One, use a find and replace
		 * to change 'twentytwentyone' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'twentytwentyone', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * This theme does not use a hard-coded <title> tag in the document head,
		 * WordPress will provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/**
		 * Add post-formats support.
		 */
		add_theme_support(
			'post-formats',
			array(
				'link',
				'aside',
				'gallery',
				'image',
				'quote',
				'status',
				'video',
				'audio',
				'chat',
			)
		);

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		set_post_thumbnail_size( 1568, 9999 );

		register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'twentytwentyone' ),
				'footer'  => __( 'Secondary menu', 'twentytwentyone' ),
			)
		);

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support(
			'html5',
			array(
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'style',
				'script',
				'navigation-widgets',
			)
		);

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		$logo_width  = 300;
		$logo_height = 100;

		add_theme_support(
			'custom-logo',
			array(
				'height'               => $logo_height,
				'width'                => $logo_width,
				'flex-width'           => true,
				'flex-height'          => true,
				'unlink-homepage-logo' => true,
			)
		);

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		// Add support for editor styles.
		add_theme_support( 'editor-styles' );
		$background_color = get_theme_mod( 'background_color', 'D1E4DD' );
	/*	if ( 127 > Twenty_Twenty_One_Custom_Colors::get_relative_luminance_from_hex( $background_color ) ) {
			add_theme_support( 'dark-editor-style' );
		}*/

		$editor_stylesheet_path = './assets/css/style-editor.css';

		// Note, the is_IE global variable is defined by WordPress and is used
		// to detect if the current browser is internet explorer.
		global $is_IE;
		if ( $is_IE ) {
			$editor_stylesheet_path = './assets/css/ie-editor.css';
		}

		// Enqueue editor styles.
		add_editor_style( $editor_stylesheet_path );

		// Add custom editor font sizes.
		add_theme_support(
			'editor-font-sizes',
			array(
				array(
					'name'      => esc_html__( 'Extra small', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XS', 'Font size', 'twentytwentyone' ),
					'size'      => 16,
					'slug'      => 'extra-small',
				),
				array(
					'name'      => esc_html__( 'Small', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'S', 'Font size', 'twentytwentyone' ),
					'size'      => 18,
					'slug'      => 'small',
				),
				array(
					'name'      => esc_html__( 'Normal', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'M', 'Font size', 'twentytwentyone' ),
					'size'      => 20,
					'slug'      => 'normal',
				),
				array(
					'name'      => esc_html__( 'Large', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'L', 'Font size', 'twentytwentyone' ),
					'size'      => 24,
					'slug'      => 'large',
				),
				array(
					'name'      => esc_html__( 'Extra large', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XL', 'Font size', 'twentytwentyone' ),
					'size'      => 40,
					'slug'      => 'extra-large',
				),
				array(
					'name'      => esc_html__( 'Huge', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XXL', 'Font size', 'twentytwentyone' ),
					'size'      => 96,
					'slug'      => 'huge',
				),
				array(
					'name'      => esc_html__( 'Gigantic', 'twentytwentyone' ),
					'shortName' => esc_html_x( 'XXXL', 'Font size', 'twentytwentyone' ),
					'size'      => 144,
					'slug'      => 'gigantic',
				),
			)
		);

		// Custom background color.
		add_theme_support(
			'custom-background',
			array(
				'default-color' => 'd1e4dd',
			)
		);

		// Editor color palette.
		$black     = '#000000';
		$dark_gray = '#28303D';
		$gray      = '#39414D';
		$green     = '#D1E4DD';
		$blue      = '#D1DFE4';
		$purple    = '#D1D1E4';
		$red       = '#E4D1D1';
		$orange    = '#E4DAD1';
		$yellow    = '#EEEADD';
		$white     = '#FFFFFF';

		add_theme_support(
			'editor-color-palette',
			array(
				array(
					'name'  => esc_html__( 'Black', 'twentytwentyone' ),
					'slug'  => 'black',
					'color' => $black,
				),
				array(
					'name'  => esc_html__( 'Dark gray', 'twentytwentyone' ),
					'slug'  => 'dark-gray',
					'color' => $dark_gray,
				),
				array(
					'name'  => esc_html__( 'Gray', 'twentytwentyone' ),
					'slug'  => 'gray',
					'color' => $gray,
				),
				array(
					'name'  => esc_html__( 'Green', 'twentytwentyone' ),
					'slug'  => 'green',
					'color' => $green,
				),
				array(
					'name'  => esc_html__( 'Blue', 'twentytwentyone' ),
					'slug'  => 'blue',
					'color' => $blue,
				),
				array(
					'name'  => esc_html__( 'Purple', 'twentytwentyone' ),
					'slug'  => 'purple',
					'color' => $purple,
				),
				array(
					'name'  => esc_html__( 'Red', 'twentytwentyone' ),
					'slug'  => 'red',
					'color' => $red,
				),
				array(
					'name'  => esc_html__( 'Orange', 'twentytwentyone' ),
					'slug'  => 'orange',
					'color' => $orange,
				),
				array(
					'name'  => esc_html__( 'Yellow', 'twentytwentyone' ),
					'slug'  => 'yellow',
					'color' => $yellow,
				),
				array(
					'name'  => esc_html__( 'White', 'twentytwentyone' ),
					'slug'  => 'white',
					'color' => $white,
				),
			)
		);

		add_theme_support(
			'editor-gradient-presets',
			array(
				array(
					'name'     => esc_html__( 'Purple to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'purple-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to purple', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'yellow-to-purple',
				),
				array(
					'name'     => esc_html__( 'Green to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $green . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'green-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to green', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $green . ' 100%)',
					'slug'     => 'yellow-to-green',
				),
				array(
					'name'     => esc_html__( 'Red to yellow', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $yellow . ' 100%)',
					'slug'     => 'red-to-yellow',
				),
				array(
					'name'     => esc_html__( 'Yellow to red', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $yellow . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'yellow-to-red',
				),
				array(
					'name'     => esc_html__( 'Purple to red', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $purple . ' 0%, ' . $red . ' 100%)',
					'slug'     => 'purple-to-red',
				),
				array(
					'name'     => esc_html__( 'Red to purple', 'twentytwentyone' ),
					'gradient' => 'linear-gradient(160deg, ' . $red . ' 0%, ' . $purple . ' 100%)',
					'slug'     => 'red-to-purple',
				),
			)
		);

		/*
		* Adds starter content to highlight the theme on fresh sites.
		* This is done conditionally to avoid loading the starter content on every
		* page load, as it is a one-off operation only needed once in the customizer.
		*/
		if ( is_customize_preview() ) {
			require get_template_directory() . '/inc/starter-content.php';
			add_theme_support( 'starter-content', twenty_twenty_one_get_starter_content() );
		}

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );

		// Add support for custom line height controls.
		add_theme_support( 'custom-line-height' );

		// Add support for experimental link color control.
		add_theme_support( 'experimental-link-color' );

		// Add support for experimental cover block spacing.
		add_theme_support( 'custom-spacing' );

		// Add support for custom units.
		// This was removed in WordPress 5.6 but is still required to properly support WP 5.5.
		add_theme_support( 'custom-units' );
	}
}
add_action( 'after_setup_theme', 'twenty_twenty_one_setup' );

/**
 * Register widget area.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 *
 * @return void
 */


/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @global int $content_width Content width.
 *
 * @return void
 */
function twenty_twenty_one_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'twenty_twenty_one_content_width', 750 );
}
add_action( 'after_setup_theme', 'twenty_twenty_one_content_width', 0 );

/**
 * Enqueue scripts and styles.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twenty_twenty_one_scripts() {
	// Note, the is_IE global variable is defined by WordPress and is used
	// to detect if the current browser is internet explorer.
	global $is_IE, $wp_scripts;
	if ( $is_IE ) {
		// If IE 11 or below, use a flattened stylesheet with static values replacing CSS Variables.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/assets/css/ie.css', array(), wp_get_theme()->get( 'Version' ) );
	} else {
		// If not IE, use the standard stylesheet.
		wp_enqueue_style( 'twenty-twenty-one-style', get_template_directory_uri() . '/style.css', array(), wp_get_theme()->get( 'Version' ) );
	}

	// RTL styles.
	wp_style_add_data( 'twenty-twenty-one-style', 'rtl', 'replace' );

	// Print styles.
	wp_enqueue_style( 'twenty-twenty-one-print-style', get_template_directory_uri() . '/assets/css/print.css', array(), wp_get_theme()->get( 'Version' ), 'print' );

	// Threaded comment reply styles.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	// Register the IE11 polyfill file.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills-asset',
		get_template_directory_uri() . '/assets/js/polyfills.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	// Register the IE11 polyfill loader.
	wp_register_script(
		'twenty-twenty-one-ie11-polyfills',
		null,
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
	wp_add_inline_script(
		'twenty-twenty-one-ie11-polyfills',
		wp_get_script_polyfill(
			$wp_scripts,
			array(
				'Element.prototype.matches && Element.prototype.closest && window.NodeList && NodeList.prototype.forEach' => 'twenty-twenty-one-ie11-polyfills-asset',
			)
		)
	);

	// Main navigation scripts.
	if ( has_nav_menu( 'primary' ) ) {
		wp_enqueue_script(
			'twenty-twenty-one-primary-navigation-script',
			get_template_directory_uri() . '/assets/js/primary-navigation.js',
			array( 'twenty-twenty-one-ie11-polyfills' ),
			wp_get_theme()->get( 'Version' ),
			true
		);
	}

	// Responsive embeds script.
	wp_enqueue_script(
		'twenty-twenty-one-responsive-embeds-script',
		get_template_directory_uri() . '/assets/js/responsive-embeds.js',
		array( 'twenty-twenty-one-ie11-polyfills' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'twenty_twenty_one_scripts' );

/**
 * Enqueue block editor script.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_block_editor_script() {

	wp_enqueue_script( 'twentytwentyone-editor', get_theme_file_uri( '/assets/js/editor.js' ), array( 'wp-blocks', 'wp-dom' ), wp_get_theme()->get( 'Version' ), true );
}

add_action( 'enqueue_block_editor_assets', 'twentytwentyone_block_editor_script' );

/**
 * Fix skip link focus in IE11.
 *
 * This does not enqueue the script because it is tiny and because it is only for IE11,
 * thus it does not warrant having an entire dedicated blocking script being loaded.
 *
 * @link https://git.io/vWdr2
 */
function twenty_twenty_one_skip_link_focus_fix() {

	// If SCRIPT_DEBUG is defined and true, print the unminified file.
	if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
		echo '<script>';
		include get_template_directory() . '/assets/js/skip-link-focus-fix.js';
		echo '</script>';
	}

	// The following is minified via `npx terser --compress --mangle -- assets/js/skip-link-focus-fix.js`.
	?>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",(function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())}),!1);
	</script>
	<?php
}
add_action( 'wp_print_footer_scripts', 'twenty_twenty_one_skip_link_focus_fix' );

/** Enqueue non-latin language styles
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
 /*
function twenty_twenty_one_non_latin_languages() {
	$custom_css = twenty_twenty_one_get_non_latin_css( 'front-end' );

	if ( $custom_css ) {
		wp_add_inline_style( 'twenty-twenty-one-style', $custom_css );
	}
}
add_action( 'wp_enqueue_scripts', 'twenty_twenty_one_non_latin_languages' );
*/

/**
 * Enqueue scripts for the customizer preview.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_preview_init() {
	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);

	wp_enqueue_script(
		'twentytwentyone-customize-preview',
		get_theme_file_uri( '/assets/js/customize-preview.js' ),
		array( 'customize-preview', 'customize-selective-refresh', 'jquery', 'twentytwentyone-customize-helpers' ),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_preview_init', 'twentytwentyone_customize_preview_init' );

/**
 * Enqueue scripts for the customizer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_customize_controls_enqueue_scripts() {

	wp_enqueue_script(
		'twentytwentyone-customize-helpers',
		get_theme_file_uri( '/assets/js/customize-helpers.js' ),
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'customize_controls_enqueue_scripts', 'twentytwentyone_customize_controls_enqueue_scripts' );

/**
 * Calculate classes for the main <html> element.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_the_html_classes() {
	$classes = apply_filters( 'twentytwentyone_html_classes', '' );
	if ( ! $classes ) {
		return;
	}
	echo 'class="' . esc_attr( $classes ) . '"';
}

/**
 * Add "is-IE" class to body if the user is on Internet Explorer.
 *
 * @since Twenty Twenty-One 1.0
 *
 * @return void
 */
function twentytwentyone_add_ie_class() {
	?>
	<script>
	if ( -1 !== navigator.userAgent.indexOf( 'MSIE' ) || -1 !== navigator.appVersion.indexOf( 'Trident/' ) ) {
		document.body.classList.add( 'is-IE' );
	}
	</script>
	<?php
}
add_action( 'wp_footer', 'twentytwentyone_add_ie_class' );
add_filter('use_block_editor_for_post', '__return_false', 10);
function mytheme_add_woocommerce_support() {
add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );

function createLocations() {

//labels array added inside the function and precedes args array

$labels = array(
'name' => _x( 'Locations', 'post type general name' ),
'singular_name' => _x( 'Location', 'post type singular name' ),
'add_new' => _x( 'Add New', 'Location' ),
'add_new_item' => __( 'Add New Location' ),
'edit_item' => __( 'Edit Location' ),
'new_item' => __( 'New Location' ),
'all_items' => __( 'All Location' ),
'view_item' => __( 'View Location' ),
'search_items' => __( 'Search Locations' ),
'not_found' => __( 'No Location found' ),
'not_found_in_trash' => __( 'No Location found in the Trash' ),
'parent_item_colon' => '',
'menu_name' => 'Location'
);

// args array

$args = array(
'labels' => $labels,
'description' => '',
'public' => true,
'menu_position' => 80,
'supports' => array( 'title', 'thumbnail' ),
'has_archive' => true,
);

register_post_type( 'locations', $args );
}
add_action( 'init', 'createLocations' );




/*My Functions*/
function homesliders() {

//labels array added inside the function and precedes args array

$labels = array(
'name' => _x( 'Sliders', 'post type general name' ),
'singular_name' => _x( 'Slider', 'post type singular name' ),
'add_new' => _x( 'Add New', 'Slider' ),
'add_new_item' => __( 'Add New Slider' ),
'edit_item' => __( 'Edit Slider' ),
'new_item' => __( 'New Slider' ),
'all_items' => __( 'All Slider' ),
'view_item' => __( 'View Slider' ),
'search_items' => __( 'Search Sliders' ),
'not_found' => __( 'No hotels found' ),
'not_found_in_trash' => __( 'No Sliders found in the Trash' ),
'parent_item_colon' => '',
'menu_name' => 'Sliders'
);

// args array

$args = array(
'labels' => $labels,
'description' => '',
'public' => true,
'menu_position' => 4,
'supports' => array( 'title', 'thumbnail' ),
'publicly_queryable'  => false,
'has_archive' => true,
);

register_post_type( 'sliders', $args );
}
add_action( 'init', 'homesliders' );

function sliderhome(){
    /*$lang='ICL_LANGUAGE_CODE'; */
 
    $args = array(
    'post_type' => 'sliders',
    'posts_per_page' => -1,
    'orderby'        => 'date',
	'order'          => 'ASC'
);
$loop = new wp_Query($args);
?>
<div id="demo" class="carousel slide" data-ride="carousel">
<div class="carousel-inner">
<ul class="carousel-indicators">
    <?php
if ( $loop->have_posts() ) :
$cnttt = -1;
while($loop->have_posts()) : $loop->the_post();
$cnttt++; ?>
        <li data-target="#demo" data-slide-to="<?php echo $cnttt; ?>"></li>
<?php
endwhile;
wp_reset_query();
endif; 
?>
</ul>
<?php
if ( $loop->have_posts() ) :
while($loop->have_posts()) : $loop->the_post();
$image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'single-post-thumbnail' );
$mobimage = get_post_meta( get_the_ID(), 'mobile_banner', true );
$image_attributes = wp_get_attachment_url( $mobimage );
?>
<div class="carousel-item">
        <img class="banner-desk" src="<?php echo $image[0];?>" alt="">
        <img class="banner-mobile" src="<?php echo $image_attributes;?>" alt="">
</div>
<?php
endwhile;
wp_reset_query();
endif; 
?>
</div>
<a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
</a>
<a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
</a>
</div>
<?php
}
add_shortcode('sliderhome', 'sliderhome');
add_filter( 'woocommerce_currency_symbol', 'wc_change_uae_currency_symbol', 10, 2 );
function wc_change_uae_currency_symbol( $currency_symbol, $currency ) {
switch ( $currency ) {
case 'KWD':
$currency_symbol = 'KD ';
break;
}
return $currency_symbol;
}
add_action( 'after_setup_theme', 'wpdocs_theme_setup' );
function wpdocs_theme_setup() {
    add_image_size( 'prod-thumb', 261, 155, true );
    add_image_size( 'blogger-size-detail', 196, 278, true );
    add_image_size( 'blogger-header', 848, 339, true );
    add_image_size( 'product-mainslider', 555, 300, true );
    add_image_size( 'thumb-mainslider', 115, 80, true );
   /* add_image_size( 'featured-thumb', 148, 99, true ); // (cropped)
    add_image_size( 'featured-main', 495, 280, true ); // (cropped)
    add_image_size( 'product-main', 285, 191, true ); // (cropped)
    add_image_size( 'category-main', 218, 252, true ); // (cropped)
    add_image_size( 'partner-size', 147, 187, true );*/
}
add_filter( 'image_size_names_choose', 'my_custom_sizes' );
 
function my_custom_sizes( $sizes ) {
    return array_merge( $sizes, array(
        'featured-size' => __( 'Featured Size' ),
    ) );
}
add_filter( 'woocommerce_breadcrumb_defaults', 'wcc_change_breadcrumb_delimiter' );
function wcc_change_breadcrumb_delimiter( $defaults ) {
	// Change the breadcrumb delimeter from '/' to '>'
	$defaults['delimiter'] = ' &gt; ';
	return $defaults;
}
/*Order Change*/
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 20 );


/*Order Change*/
add_filter( 'woocommerce_product_tabs', 'woo_custom_product_tabs' );
function woo_custom_product_tabs( $tabs ) {

    // 2 Adding new tabs and set the right order

    // Adds the other products tab
    $tabs['cancellation_policy_tab'] = array(
        'title'     => __( 'Cancellation Policy', 'woocommerce' ),
        'priority'  => 120,
        'callback'  => 'woo_cancellation_policy_tab_content'
    );

    return $tabs;

}
if ( !function_exists( 'yith_wapo_customization_hide_all_options' ) ) {
	add_action( 'admin_enqueue_scripts', 'yith_wapo_customization_hide_all_options', 999 );

	function yith_wapo_customization_hide_all_options() {

		$js = "jQuery(document).ready(function ($) {
			 jQuery('div#my_custom_product_data .options_group:last-child').hide(); 
		});";

		wp_add_inline_script( 'yith-wccl-admin', $js, 'before' );
	}
}

// New Tab contents
function woo_cancellation_policy_tab_content() {
    global $product;
    
    $canpolicy = get_post_meta($product->get_id(),'cancellation_policy',true);
    echo $canpolicy;
}

/*add_action( 'init', 'create_subjects_hierarchical_taxonomy', 0 );*/
 

// /*Custom field in order*/
function patricks_woocommerce_catalog_orderby( $orderby ) {
	// Add "Sort by date: oldest to newest" to the menu
	// We still need to add the functionality that actually does the sorting
	$orderby['oldest_to_recent'] = __( 'Sort by date: oldest to newest', 'woocommerce' );

	// Change the default "Sort by newness" to "Sort by date: newest to oldest"
	$orderby["date"] = __('Sort by date: newest to oldest', 'woocommerce');

	// Remove price & price-desc
// 	unset($orderby["price"]);
// 	unset($orderby["price-desc"]);

	return $orderby;
}
add_filter( 'woocommerce_catalog_orderby', 'patricks_woocommerce_catalog_orderby', 20 );

// // Add the ability to sort by oldest to newest
function patricks_woocommerce_get_catalog_ordering_args( $args ) {
	$orderby_value = isset( $_GET['orderby'] ) ? woocommerce_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );

	if ( 'oldest_to_recent' == $orderby_value ) {
		$args['orderby'] = 'date';
		$args['order']   = 'ASC';
	}

	return $args;
}
add_filter( 'woocommerce_get_catalog_ordering_args', 'patricks_woocommerce_get_catalog_ordering_args', 20 );

/*
add_action( 'widgets_init', 'filtersidebar' );
function filtersidebar() {
    register_sidebar( array(
        'name' => __( 'Filter Sidebar', 'theme-slug' ),
        'id' => 'filtersidebar',
        'description' => __( 'Widgets in this area for filter sidebar', 'theme-slug' ),
        'before_widget' => '<span id="%1$s" class="widget %2$s filtersidebar">',
	'after_widget'  => '</span>',
	'before_title'  => '<h3 class="filternow widget-title filter_title">',
	'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'searchsidebar' );
function searchsidebar() {
    register_sidebar( array(
        'name' => __( 'Search Sidebar', 'theme-slug' ),
        'id' => 'searchsidebar',
        'description' => __( 'Widgets in this area for search sidebar', 'theme-slug' ),
        'before_widget' => '<span id="%1$s" class="widget %2$s searchsidebar">',
	'after_widget'  => '</span>',
	'before_title'  => '<h3 class="searchnow widget-title search_title">',
	'after_title'   => '</h3>',
    ) );
}
 */

if ( ! function_exists('yith_wcbk_ajax_booking_customize_available_times_formatted_time' ) ) {
 add_filter('yith_wcbk_ajax_booking_available_times_formatted_time','yith_wcbk_ajax_booking_customize_available_times_formatted_time', 10, 3);
 function yith_wcbk_ajax_booking_customize_available_times_formatted_time( $formatted_time, $time, $product ){
 $duration = $product->get_duration();
 switch ( $product->get_duration_unit() ) {
 case 'minute':
 $duration *= 60;
 break;
 case 'hour':
 $duration *= 3600;
 break;
        }
 $start_time = date( 'g:i a', strtotime($time) );
 $end_time = date( 'g:i a', strtotime( $start_time ) + $duration );
 $formatted_time = $start_time . ' to ' . $end_time;
 return $formatted_time;
    }
}


add_filter( 'yith_wcbk_get_minimum_minute_increment', 'yith_wcbk_customize_minimum_minute_increment', 99 );

if( !function_exists( 'yith_wcbk_customize_minimum_minute_increment' ) ){
 function yith_wcbk_customize_minimum_minute_increment( $increment ){
  $increment = 30;
  return $increment;
 }
}

function filter_product_type_options( $array ) { 
    unset($array['external']);
    unset($array['grouped']);
    unset($array['simple']);
    unset($array['variable']);
    return $array; 
}; 

add_filter( 'product_type_selector', 'filter_product_type_options', 10, 1 ); 

// function remove_short_description() {
 
// remove_meta_box( 'postexcerpt', 'product', 'normal');
 
// }
// add_action('add_meta_boxes', 'remove_short_description', 999);

function get_excerpt( $count ) {
$permalink = get_permalink($post->ID);
$excerpt = get_the_content();
$excerpt = strip_tags($excerpt);
$excerpt = substr($excerpt, 0, $count);
$excerpt = substr($excerpt, 0, strripos($excerpt, " "));
$excerpt = $excerpt.'...';
return $excerpt;
}

if( !function_exists('yith_wcbk_product_data_panels') ) {
 function yith_wcbk_product_data_panels( $data_panels ) {
 // $data_panels['yith_booking_people']['label'] = 'Booking Quantity';
 unset( $data_panels['yith_booking_services'] );
 unset( $data_panels['yith_booking_sync'] );
 unset( $data_panels['advanced'] );
 return $data_panels;
    }
 add_filter( 'yith_wcbk_product_booking_tabs', 'yith_wcbk_product_data_panels' );
}

/*
function remove_dashboard_widgets() {
    global $wp_meta_boxes;
 
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_drafts']);
    unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
    unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
 
}
 
add_action('wp_dashboard_setup', 'remove_dashboard_widgets' );

 */

 
if( function_exists('YITH_Vendors') ) {
  /*  add_filter('yith_wcmv_to_remove_dashboard_widgets', 'yith_wcmv_to_remove_dashboard_widgets');
    if ( ! function_exists('yith_wcmv_to_remove_dashboard_widgets')) {
        function yith_wcmv_to_remove_dashboard_widgets($to_removes)
        {
            $to_removes_custom = array(
                array(
                    'id' => 'fue-dashboard',
                    'screen' => 'dashboard',
                    'context' => 'normal'
                ),
                array(
                    'id' => 'dashboard_primary',
                    'screen' => 'dashboard',
                    'context' => 'normal'
                ),
                array(
                    'id' => 'yit_dashboard_products_news',
                    'screen' => 'dashboard',
                    'context' => 'normal'
                ),
                array(
                    'id' => 'yit_dashboard_blog_news',
                    'screen' => 'dashboard',
                    'context' => 'normal'
                ),
            );
            return array_merge($to_removes, $to_removes_custom);
        }
    }

    add_action( 'admin_bar_menu', 'yith_wcmv_remove_wp_logo', 5 );

  */


    if( ! function_exists( 'yith_wcmv_remove_wp_logo' ) ){
        function yith_wcmv_remove_wp_logo(){
            $vendor = yith_get_vendor( 'current', 'user' );

            if( $vendor->is_valid() ){
                remove_action( 'admin_bar_menu', 'wp_admin_bar_wp_menu', 10 );
                add_action( 'admin_footer_text', '__return_empty_string', 999 );
                add_action( 'update_footer', '__return_empty_string', 999 );
            }
        }
    }

   /* add_action( 'wp_dashboard_setup', 'yit_remove_dashboard_widgets', 11 );
    function yit_remove_dashboard_widgets() {
        global $wp_meta_boxes;
        $vendor = yith_get_vendor( 'current', 'user' );

        if( $vendor->is_valid() ){
            unset( $wp_meta_boxes['dashboard']['side']['core']['yit_dashboard_products_news'] );
            unset( $wp_meta_boxes['dashboard']['side']['core']['yit_dashboard_blog_news'] );
        }
    } */
}


add_action( 'admin_init', 'my_remove_menu_pages' );
function my_remove_menu_pages() {


  global $user_ID;

 // if ( $user_ID != 1 ) { //your user id

  remove_menu_page('edit.php'); // Posts
  remove_submenu_page( 'index.php', 'update-core.php' );
  remove_submenu_page( 'index.php', 'index.php' );
  // remove_menu_page('upload.php'); // Media
  // remove_menu_page('link-manager.php'); // Links
  // remove_menu_page('edit-comments.php'); // Comments
  // remove_menu_page('edit.php?post_type=page'); // Pages
  // remove_menu_page('plugins.php'); // Plugins
  // remove_menu_page('themes.php'); // Appearance
  // remove_menu_page('users.php'); // Users
  // remove_menu_page('tools.php'); // Tools
  // remove_menu_page('options-general.php'); // Settings
  // remove_menu_page('edit.php'); // Posts
  // remove_menu_page('upload.php'); // Media
 // } /
}

function hide_help() {
    echo '<style type="text/css">
            #contextual-help-link-wrap { display: none !important; }
    </style>';
}
add_action('admin_head', 'hide_help');

if ( !function_exists( 'yith_wcbk_customization_add_custom_minutes_duration' ) ) {
    add_filter( 'yith_wcbk_duration_minute_select_options', 'yith_wcbk_customization_add_custom_minutes_duration' );
 function yith_wcbk_customization_add_custom_minutes_duration( $durations ) {
 $durations[ '120' ] = '120';
 $durations[ '180' ] = '180';
 asort( $durations );
 return $durations;
    }
}
add_filter( 'woocommerce_admin_features', 'disable_features' );

function disable_features( $features ) {
	$marketing = array_search('marketing', $features);
	unset( $features[$marketing] );
	return $features;
}

function woocommerce_subcats_from_parentcat_by_ID($parent_cat_ID) {

   
}


add_filter( 'woocommerce_get_breadcrumb', 'change_breadcrumb' );
function change_breadcrumb( $crumbs ) {

    return array_splice($crumbs, 0, 2);
}

if( !function_exists('yith_wapo_print_options_default_args') ) {

  add_filter( 'yith_wapo_print_options_default_args', 'yith_wapo_print_options_default_args' );

 function yith_wapo_print_options_default_args( $args ) {

 if( 'number' == $args['type'] ) {
 $args['min_html']  = 'min="0"';
 }
 return $args;
 }
}
/*
add_filter('login_title', custom_login_title, 99);
function custom_login_title($origtitle) { 

    return get_bloginfo('Login');

} */

add_filter('woocommerce_add_to_cart_fragments', 'rentzon_change_cart_count',10,1);

function rentzon_change_cart_count($fragments){
 $fragments['span.rentzon_wc_count']= '<span class="badge rentzon_wc_count">'. WC()->cart->get_cart_contents_count() .'</span>';   
 return $fragments;     
}

add_action('init', 'rentzon_remove_wcbk_services');

function rentzon_remove_wcbk_services(){
    register_taxonomy('yith_booking_service',array());
}

if ( defined( 'YITH_WCWL' ) && ! function_exists( 'yith_wcwl_get_items_count' ) ) {
 function yith_wcwl_get_items_count() {
  ob_start();
  echo esc_html( yith_wcwl_count_all_products() ); 
  ?>

  <?php
  return ob_get_clean();
 }
 add_shortcode( 'yith_wcwl_items_count', 'yith_wcwl_get_items_count' );
}

if ( defined( 'YITH_WCWL' ) && ! function_exists( 'yith_wcwl_ajax_update_count' ) ) {
 function yith_wcwl_ajax_update_count() {
  wp_send_json( array(
      'count' => yith_wcwl_count_all_products()
  ) );
 }
 add_action( 'wp_ajax_yith_wcwl_update_wishlist_count', 'yith_wcwl_ajax_update_count' );
 add_action( 'wp_ajax_nopriv_yith_wcwl_update_wishlist_count', 'yith_wcwl_ajax_update_count' );
}

if ( defined( 'YITH_WCWL' ) && ! function_exists( 'yith_wcwl_enqueue_custom_script' ) ) {
 function yith_wcwl_enqueue_custom_script() {
  wp_add_inline_script(
      'jquery-yith-wcwl',
      "
        jQuery( function( $ ) {
          $( document ).on( 'added_to_wishlist removed_from_wishlist', function() {
            $.get( yith_wcwl_l10n.ajax_url, {
              action: 'yith_wcwl_update_wishlist_count'
            }, function( data ) {
              $('.yith-wcwl-items-count').html( data.count );
            } );
          } );
        } );
      "
  );
 }
 add_action( 'wp_enqueue_scripts', 'yith_wcwl_enqueue_custom_script', 20 );
}


 add_filter( 'woocommerce_redirect_single_search_result', '__return_false' );




 
 //custompost type for service2
 if(!function_exists('sidead_init')){
function sidead_init() {
    // set up service labels
    $labels = array(
        'name' => 'Side Ad',
        'singular_name' => 'Side Ad',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Side Ad',
        'edit_item' => 'Edit Side Ad',
        'new_item' => 'New Side Ad',
        'all_items' => 'Side Ad',
        'view_item' => 'View Side Ad',
        'search_items' => 'Search Side Ad',
        'not_found' =>  'No Side Ad Found',
        'not_found_in_trash' => 'No Side Ad found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Side Ad',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'sidead','with_front' => false  ),
        'query_var' => true,
        'publicly_queryable'  => false,
        'menu_icon' => 'dashicons-randomize',
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'trackbacks',
            'custom-fields',
            'comments',
            'revisions',
            'thumbnail',
            'author',
            'page-attributes'
        )
    );
    register_post_type( 'sidead', $args );
}
 }
 add_action('init', 'sidead_init');

 // footer ad

 //custompost type for service2
 if(!function_exists('footerad_init')){
function footerad_init() {
    // set up service labels
    $labels = array(
        'name' => 'Footer Ad',
        'singular_name' => 'Footer Ad',
        'add_new' => 'Add New',
        'add_new_item' => 'Add New Footer Ad',
        'edit_item' => 'Edit Footer Ad',
        'new_item' => 'New Footer Ad',
        'all_items' => 'Footer Ad',
        'view_item' => 'View Footer Ad',
        'search_items' => 'Search Footer Ad',
        'not_found' =>  'No Footer Ad Found',
        'not_found_in_trash' => 'No Footer Ad found in Trash', 
        'parent_item_colon' => '',
        'menu_name' => 'Footer Ad',
    );
    
    // register post type
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'show_ui' => true,
        'capability_type' => 'post',
        'hierarchical' => false,
        'rewrite' => array('slug' => 'footerad','with_front' => false  ),
        'query_var' => true,
        'menu_icon' => 'dashicons-randomize',
        'publicly_queryable'  => false,
        'supports' => array(
            'title',
            'editor',
            'excerpt',
            'trackbacks',
            'custom-fields',
            'comments',
            'revisions',
            'thumbnail',
            'author',
            'page-attributes'
        )
    );
    register_post_type( 'footerad', $args );
}
 }
 add_action('init', 'footerad_init');
 
 
add_filter( 'woocommerce_settings_tabs_array', 'filter_wc_settings_tabs_array', 200, 1 );
function filter_wc_settings_tabs_array( $tabs_array ) {
    // Only for "shipping_manager" user role
    if( current_user_can( 'shop_manager' ) ) {
        // Remove some specific tabs
        unset( $tabs_array['checkout'], $tabs_array['order_status'] ); // <== replace 'order_status' by 
    }

    return $tabs_array;
}

function wooninja_remove_items() {
$remove = array('wc-status', 'wc-addons','wwpp-wholesale-roles-page','shop_coupon','wpo_wcpdf_options_page', );
foreach ( $remove as $submenu_slug ) {
 if( current_user_can( 'shop_manager' ) ) {
remove_submenu_page( 'woocommerce', $submenu_slug );
remove_menu_page( 'tools.php' );
}
}
}

add_action( 'admin_menu', 'wooninja_remove_items', 99, 0 );


add_action( 'admin_menu', 'rename_woocoomerce', 999 );
 
function rename_woocoomerce()
{
    global $menu;
 
    // Pinpoint menu item
    $woo = rename_woocommerce( 'WooCommerce', $menu );
 
    // Validate
    if( !$woo )
        return;
 
    $menu[$woo][0] = 'Store Settings';
}
 
function rename_woocommerce( $needle, $haystack )
{
    foreach( $haystack as $key => $value )
    {
        $current_key = $key;
        if(
            $needle === $value
            OR (
                is_array( $value )
                && rename_woocommerce( $needle, $value ) !== false
            )
        )
        {
            return $current_key;
        }
    }
    return false;
}

add_action('admin_head', 'yith_wcbk_add_custom_admin_style');

function yith_wcbk_add_custom_admin_style() {
    echo '<style>
    select#_yith_booking_duration_unit option[value=month] {
  display: none;
 }
  </style>';
} 



// // Add term and conditions check box on registration form
add_action( 'woocommerce_register_form', 'add_terms_and_conditions_to_registration', 20 );
function add_terms_and_conditions_to_registration() {

    // if ( wc_get_page_id( 'terms' ) > 0 && is_account_page() ) {
         ?>
         <p class="form-row terms wc-terms-and-conditions">
          <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms'] ) ), true ); ?> id="terms" /> <span class="ter-con"><?php printf( __( 'I&rsquo;ve read and accept the <a href="terms-and-conditions" target="_blank" >Terms &amp; Conditions</a>', 'woocommerce' ), esc_url( wc_get_page_permalink( 'terms' ) ) ); ?></span> <span class="required">*</span>
            </label>
            <input type="hidden" name="terms-field" value="1" />
        </p>
    <?php
    // }
}

// Validate required term and conditions check box
add_action( 'woocommerce_register_post', 'terms_and_conditions_validation', 20, 3 );
function terms_and_conditions_validation( $username, $email, $validation_errors ) {
    if ( ! isset( $_POST['terms'] ) )
        $validation_errors->add( 'terms_error', __( 'Terms and condition are not checked!', 'woocommerce' ) );

    return $validation_errors;
}

add_action( 'woocommerce_email_order_meta', 'rentzon_add_payment_details', 15,4 );
  
function rentzon_add_payment_details(  $order, $sent_to_admin, $plain_text, $email ) {
	echo '<h2>Payment Reference Details</h2>';
	echo '<div class="order_note">Tap id: '.get_post_meta($order->get_id(),'tap_reference_id',true).'</div>';
	echo '<div class="order_note">Reference id: '.get_post_meta($order->get_id(),'order_tap_method_id',true).'</div>';
	echo '<div class="order_note">Payment Method: '.get_post_meta($order->get_id(),'order_tap_payment_method',true).'</div>';
}

add_action('woocommerce_thankyou_tap', 'rentzon_add_order_notes');

function rentzon_add_order_notes($order_id){
  // var_dump(get_post_meta($order_id,'order_tap_method_id',true));
    $order = wc_get_order($order_id);
	echo '<h2>Payment Reference Details</h2>';
	echo '<div class="order_note">Tap id: '.$order->get_meta('tap_reference_id').'</div>';
	echo '<div class="order_note">Reference id: '.$order->get_meta('order_tap_method_id').'</div>';
	echo '<div class="order_note">Payment Method: '.$order->get_meta('order_tap_payment_method').'</div>';
}




//add_action('template_redirect', 'get_tap_order_details');

function get_tap_order_details(){
  if( is_wc_endpoint_url( 'order-received' ) ){ 
      if(isset($_GET['key'])):
         $ord_id = wc_get_order_id_by_order_key($_GET['key']);
	  	ob_start();	
	  	$available_gateways = WC()->payment_gateways->get_available_payment_gateways();
	    if(array_key_exists('tap',$available_gateways)):
	     	$settings = $available_gateways['tap']->settings;
 	     	$testmode = $settings['testmode'] == 'yes';
 	     	$private_key = $testmode ? $settings['test_private_key'] : $settings['private_key'];
 	  	 	$payment_mode = $settings['payment_mode'] == 'charge' ? 'charges': 'authorize';
	          	if($ord_id != 0 ): 
            		$ord_id =intval($ord_id);  
       			$url ="https://api.tap.company/v2/".$payment_mode."/".$_GET['tap_id'];
       			$args=array(
             		'headers'     => array(
             		"Authorization"=>"Bearer ".$private_key,
             		"Content-type"=>"application/json"
             		),
         		);
	  			
 	  			$response=wp_remote_get($url,$args);
 	  			$response = json_decode( wp_remote_retrieve_body($response));
	            ob_end_clean();
				if($response):
			   		add_post_meta($ord_id,'tap_reference_id', $_GET['tap_id'] ); 
			   		add_post_meta($ord_id ,'order_tap_payment_method', $response->source->payment_method);
			   		add_post_meta($ord_id ,'order_tap_method_id', $response->reference->payment);
				endif;  
 	 	 	endif;
        endif; 
	  	sleep(5);
       endif; 
  }
}

function wpml_wc_api_home_url( $url, $path, $orig_scheme, $blog_id ) {
    global $sitepress;
 
    if ( isset( $sitepress ) && 0 === strpos( $path, 'wc-api/' ) ) {
 
        $url = $sitepress->convert_url( str_replace( $path, '', $url ), $sitepress->get_default_language() );
        $url = untrailingslashit( $url ) . '/' . ltrim( $path, '/' );
    }
 
    return $url;
}
add_filter( 'home_url', 'wpml_wc_api_home_url', 0, 4 );


if ( ! function_exists( 'yith_booking_remove_calendar_option' ) ) {
function yith_booking_remove_calendar_option() {
 echo '<style type="text/css"> ._yith_booking_enable_calendar_range_picker {
        display: none !important;
      } </style>';
}
add_action('admin_head', 'yith_booking_remove_calendar_option');
}


// add_filter( 'woocommerce_continue_shopping_redirect', 'bbloomer_change_continue_shopping' );
 
// function bbloomer_change_continue_shopping() {
//   return wc_get_page_permalink( 'shop' );
// }



add_filter( 'woocommerce_continue_shopping_redirect', 'my_changed_woocommerce_continue_shopping_redirect', 10, 1 );
function my_changed_woocommerce_continue_shopping_redirect( $return_to ){

    $return_to = wc_get_page_permalink( 'checkout' );

    return $return_to;
}


add_filter( 'wc_add_to_cart_message_html', 'my_changed_wc_add_to_cart_message_html', 10, 2 );
function my_changed_wc_add_to_cart_message_html($message, $products){

    if (strpos($message, 'Continue shopping') !== false) {
        $message = str_replace("Continue shopping", "Proceed to Checkout", $message);
    }

    return $message;

}

function golden_oak_web_design_woocommerce_checkout_terms_and_conditions() {
  remove_action( 'woocommerce_checkout_terms_and_conditions', 'wc_terms_and_conditions_page_content', 30 );
}
add_action( 'wp', 'golden_oak_web_design_woocommerce_checkout_terms_and_conditions' );

// remove logged in header bar
add_filter( 'show_admin_bar', '__return_false' );

remove_action( 'woocommerce_order_details_after_order_table', 'woocommerce_order_again_button' );
add_action( 'login_head', 'hide_login_nav' );

function hide_login_nav()
{
    ?><style>#nav,#backtoblog{display:none}</style><?php
}

// add_filter('allow_empty_comment', '__return_true');


 function comment_validation_init() {
    if(is_single() && comments_open() ) { ?>        
    <script type="text/javascript" src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
    $('#commentform').validate({

    rules: {
      author: {
        required: true,
        minlength: 2
      },

      email: {
        required: true,
        email: true
      },

      comment: {
        required: true,
        // minlength: 20
      }
    },

    messages: {
      author: "Please fill the required field",
      email: "Please enter a valid email address.",
      comment: "Please fill the required field"
    },

    errorElement: "div",
    errorPlacement: function(error, element) {
      element.after(error);
    }

    });
    });
    </script>
    <?php
    }
    }
    add_action('wp_footer', 'comment_validation_init');
    add_filter( 'woocommerce_taxonomy_args_product_tag', 'custom_wc_taxonomy_label_product_tag' );
function custom_wc_taxonomy_label_product_tag( $args ) {
	$args['label'] = 'Cities';
	$args['labels'] = array(
	    'name' 				=> 'Cities',
	    'singular_name' 	=> 'City',
        'menu_name'			=> 'Cities',
		'edit_item'   => 'Edit City',
		'add_new_item' => 'Add City',
		'popular_items' => 'Popular Cities',
		'search_items' => 'Search City',
		'view_item' => 'View City',
		'separate_items_with_commas' => 'Separate cities with comma',
		'choose_from_most_used' => 'Choose from the most used Cities'
		
	);

	return $args;
}

//remove admin header

function Hide_WooCommerce_Breadcrumb() {
  echo '<style>
    .woocommerce-layout__header {
        display: none;
    }
    .woocommerce-layout__activity-panel-tabs {
        display: none;
    }
    .woocommerce-layout__header-breadcrumbs {
        display: none;
    }
    .woocommerce-embed-page .woocommerce-layout__primary{
        display: none;
    }
    .woocommerce-embed-page #screen-meta, .woocommerce-embed-page #screen-meta-links{top:0;}
    </style>';
}
add_action('admin_head', 'Hide_WooCommerce_Breadcrumb');

add_filter( 'author_link', 'my_author_link' );
 
function my_author_link() {
	return home_url( 'products' );
}

add_filter( 'manage_edit-product_columns', 'show_product_order',15 );
function show_product_order($columns){
$columns['product_tag'] = __('Cities');

   return $columns;
}
if( ! function_exists( 'yith_woocompare_filter_button_text' ) ) {
	add_filter( 'wpml_translate_single_string', 'yith_woocompare_filter_button_text', 1, 3 );
	function yith_woocompare_filter_button_text( $button, $contest, $plugin ) {

		if ( $plugin != 'plugin_yit_compare_button_text' ) {
			return $button;
		}

		global $yith_woocompare, $product;

		$product_id = ! is_null( $product ) ? yit_get_prop( $product, 'id', true ) : 0;

		if ( in_array( $product_id, $yith_woocompare->obj->products_list ) ) {
			return __( 'Added', 'yith-woocommerce-compare' );
		}

		return $button;
	}
}
 add_filter( 'woocommerce_my_account_my_orders_query', 'unset_pending_payment_orders_from_my_account', 10, 1 );
// function unset_pending_payment_orders_from_my_account( $args ) {
//     $statuses = wc_get_order_statuses();    
//     unset( $statuses['wc-pending'] );
//     $args['post_status'] = array_keys( $statuses );
//     return $args;
// }
// if ( class_exists( 'YITH_WCBK_Post_Types' ) ) {
//  add_action( 'pre_get_posts', 'yith_wcbk_filter_booking' );

//  function yith_wcbk_filter_booking( $query ) {
//  if ( isset( $query->query['post_type'] ) && YITH_WCBK_Post_Types::$booking === $query->query['post_type'] ) {
//          $query->set( 'post_status', 'bk-paid' );
//  }
//   }
// }


// add_action( 'woocommerce_checkout_order_created', 'order_received_empty_cart_action', 10, 1 );
// or 
// add_action( 'woocommerce_thankyou', 'order_received_empty_cart_action', 10, 1 );
// function order_received_empty_cart_action( $order_id ){
//     WC()->cart->empty_cart();
// }
/*.......................... nextgencia functions ......................*/


  add_action('woocommerce_before_add_to_cart_button','wdm_add_custom_fields');
 /*
  * Adds custom field for Product
  * @return [type] [description]
  */
 function wdm_add_custom_fields()
 {
    ob_start();
  //  callback();
      ?>
    <div class="wdm-custom-fields">
             <input type="hidden" name="wdm_name" id="wdm_name" value="">
         </div>
         <div class="clear"></div>

         <div class="wdm-custom-fields">
             <input type="hidden" name="wdm_name_ref" id="wdm_name_ref" value="">
         </div>
         <div class="clear"></div>
         
 
     <?php 
 
     $content = ob_get_contents();
     ob_end_flush();  
     return $content;
 } 

 add_filter('woocommerce_add_cart_item_data','wdm_add_item_data',10,3);

 /**
  * Add custom data to Cart
  * @param  [type] $cart_item_data [description]
  * @param  [type] $product_id     [description]
  * @param  [type] $variation_id   [description]
  * @return [type]                 [description]
  */
 function wdm_add_item_data($cart_item_data, $product_id, $variation_id)
 {
     if(isset($_REQUEST['wdm_name']))
     {
         if($_REQUEST['wdm_name']!='null'){
           $cart_item_data['wdm_name'] = sanitize_text_field($_REQUEST['wdm_name']);
         }
     }
     if(isset($_REQUEST['wdm_name_ref']))
     {
         if($_REQUEST['wdm_name_ref']!='null'){
            $cart_item_data['wdm_name_ref'] = sanitize_text_field($_REQUEST['wdm_name_ref']);
         } 
     }


 
     return $cart_item_data;
 }

 add_filter('woocommerce_get_item_data','wdm_add_item_meta',10,2);

 /**
  * Display information as Meta on Cart page
  * @param  [type] $item_data [description]
  * @param  [type] $cart_item [description]
  * @return [type]            [description]
  */
 function wdm_add_item_meta($item_data, $cart_item)
 {
 
    global $wpdb;
    $tbl1 = $wpdb->prefix.'terms';
    $tbl2 = $wpdb->prefix.'termmeta'; 
    $tbl3 = $wpdb->prefix.'blogger_product';
   
   
    if(array_key_exists('wdm_name', $cart_item))
     {
        $custom_details = $cart_item['wdm_name'];
        if($custom_details!='null'){
         
            $qry ="select t.term_id as bgid,t.name as bgname,tm.term_id ,tm.meta_key, blg.bpid, blg.blogger_id
                   from ".$tbl1. " t ,".$tbl2." tm , " .$tbl3." blg
                   where t.term_id = tm.term_id AND 
                   tm.meta_key ='owner' AND
                   tm.term_id = blg.blogger_id AND
                   blg.bpid = ".$custom_details;
                  
           $results = $wpdb->get_results($qry); 
            foreach($results as $result){ 
                 $bgcodename =  $result->bgname.'('.$custom_details.')'; 
            } 
            $item_data[] = array(
                'key'   => 'Name',
                'value' => $bgcodename
            );
        } 
     
      }

     if(array_key_exists('wdm_name_ref', $cart_item))
     {
         $custom_details_ref = $cart_item['wdm_name_ref'];
         if($custom_details_ref!='null'){

            $qry2 ="select t.term_id as bgid,t.name as bgname,tm.term_id ,tm.meta_key, blg.bpid, blg.blogger_id from 
            ".$tbl1. " t ,".$tbl2." tm , " .$tbl3." blg where 
            t.term_id = tm.term_id AND 
            tm.meta_key ='owner' AND 
            blg.blogger_id = t.term_id AND 
            blg.bpid = ".$custom_details_ref ;

          
                $results2 = $wpdb->get_results( $qry2); 
                foreach($results2 as $result2){ 
                    $refcodename =  $result2->bgname.'('.$custom_details_ref.')';   
                }  



            $item_data[] = array(
                'key'   => 'RefName',
                'value' => $refcodename
            );
         } 
     }
 
     return $item_data;
 }


 add_action( 'woocommerce_checkout_create_order_line_item', 'wdm_add_custom_order_line_item_meta',10,4 );

 function wdm_add_custom_order_line_item_meta($item, $cart_item_key, $values, $order)
 {
 
    global $wpdb;
    $tbl1 = $wpdb->prefix.'terms';
    $tbl2 = $wpdb->prefix.'termmeta'; 
    $tbl3 = $wpdb->prefix.'blogger_product';
    
  if(array_key_exists('wdm_name', $values))
     {
        
        $bgcode = $values['wdm_name'];
        $qry ="select t.term_id as bgid,t.name as bgname,tm.term_id ,tm.meta_key, blg.bpid, blg.blogger_id
               from ".$tbl1. " t ,".$tbl2." tm , " .$tbl3." blg
               where t.term_id = tm.term_id AND 
               tm.meta_key ='owner' AND
               tm.term_id = blg.blogger_id AND
               blg.bpid = ".$bgcode;
              
       $results = $wpdb->get_results($qry); 
        foreach($results as $result){ 
             $bgcodename =  $result->bgname.'('.$bgcode.')'; 
        }      
        
        $item->add_meta_data('BGCODE',$bgcodename);
     }
    
     if(array_key_exists('wdm_name_ref', $values))
     {

        $refcode = $values['wdm_name_ref'];
        $qry2 ="select t.term_id as bgid,t.name as bgname,tm.term_id ,tm.meta_key, blg.bpid, blg.blogger_id from 
                ".$tbl1. " t ,".$tbl2." tm , " .$tbl3." blg where 
                t.term_id = tm.term_id AND 
                tm.meta_key ='owner' AND 
                blg.blogger_id = t.term_id AND 
                blg.bpid = ".$refcode ;

              
        $results2 = $wpdb->get_results( $qry2); 
        foreach($results2 as $result2){ 
             $refcodename =  $result2->bgname.'('.$refcode.')'; 
        }      
        
        $item->add_meta_data('REFEREDCODE',$refcodename);
                //$item->add_meta_data('REFEREDCODE',$values['wdm_name_ref']);
                
     }
 
    /* if(array_key_exists('wdm_name', $values))
     {
        $item->add_meta_data('BGCODE',$values['wdm_name']);
     }
     if(array_key_exists('wdm_name_ref', $values))
     {
         $item->add_meta_data('REFEREDCODE',$values['wdm_name_ref']);
     } */
         //echo "<script> resetlocal(); </script>"; 
     
     ?>
   <script type="text/javascript">
    function resetlocal() {
       // alert('hi');
       // localStorage.removeItem("orderbgid");
       // localStorage.removeItem("refcode");
       localStorage.clear();
       }
    </script>
 <?php } 

 
/* blogger dashboard product review save/edit section */
add_action('wp_ajax_Attending', 'eventAttend');
add_action('wp_ajax_nopriv_Attending', 'eventAttend');
function eventAttend(){
  global $wpdb;
  //echo "avetth";
  $review = $_POST['data']; 
  $id     = $_POST['id'];    //table row id 
  $bgid = $_POST['revblogid'];
  $uid  = $_POST['userid'];
  $pdid = $_POST['prodid'];
  $user = get_userdata($uid);
  $nme = $user->data->display_name;
  $bpdate = date("Y-m-d");

  $table2 = $wpdb->prefix.'blogger_product';
  $qr2     = "select bpid from " .$table2. " where product_id = " .$pdid. " AND blogger_id = " .$bgid ;

 // echo  "select bpid from " .$table2. " where product_id = " .$pdid. " AND blogger_id = " .$bgid ;
  $res2 = $wpdb->get_results($qr2); 
  foreach($res2 as $vl2){
      $bp  = $vl2->bpid;
  }   
$table = $wpdb->prefix.'blogger_product_review';
if($id == '0'){  
     $sql = $wpdb->prepare("INSERT INTO ".$table. "(`bpid`,`bp_pro_review`,`bp_userid`,`bp_name`,`bp_date`,`bp_status`) values
     ('".$bp."', '".$review."', '".$uid."', '".$nme."','".$bpdate."','Approved')");
      $wpdb->query($sql); 
 }else{ 
       $wpdb->update( 
          $table, 
          array( 
              'bp_pro_review' => $review 
          ), 
          array('bg_prod_rewid' => $id)
      );
  
  }
  echo $review;
  die;

}
 
 /* blogger dashboard product review  section */
 add_action('wp_ajax_Retrieve', 'eventRetrieve');
 add_action('wp_ajax_nopriv_Retrieve', 'eventRetrieve');
 function eventRetrieve(){
    global $wpdb;
    $rwid = $_POST['dataid']; 
    $table2 = $wpdb->prefix.'blogger_product_review';    
    $qry2 = "SELECT * FROM "
        .$table2. " WHERE bg_prod_rewid = " . $rwid ;

    $results2 = $wpdb->get_results( $qry2);
    foreach($results2 as $result){
        $review = $result->bp_pro_review;
        
        echo $review;

    }    
      die;
  }
  function enable_page_excerpt() {
    add_post_type_support('page', array('excerpt'));
  }
  add_action('init', 'enable_page_excerpt');
  function limit_text($text, $limit) {
    if (str_word_count($text, 0) > $limit) {
        $words = str_word_count($text, 2);
        $pos   = array_keys($words);
        $text  = substr($text, 0, $pos[$limit]) . '...';
    }
    return $text;
  
 }
 add_filter( 'use_block_editor_for_post', '__return_false' );
 function hand_picked_deals(){ ?>
 <section class="hmhandpickDeal mt-5">
 <div class="container">
   <div class="dealshead">
     <h2>Hand Picked Deals </h2>
   </div>
 <div class="owl-carousel" id="handPickedSeals">
 <?php
    /* $lang=ICL_LANGUAGE_CODE; */
  
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 20,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'post_status'    => 'publish',
        'meta_query' => array(
        'relation' => 'AND',
        array(
        'key'     => 'flash_deal',
        'value'   => 1,
        'compare' => 'IN',
        ),
    ),
        'tax_query'      => array(
        'relation' => 'AND',
        array(
        'taxonomy' => 'product_type',
        'field'    => 'slug',
        'terms'    => YITH_WCBK_Product_Post_Type_Admin::$prod_type,
       ),
    ),
 );
 $loop = new wp_Query($args);
 while($loop->have_posts()) { $loop->the_post();
  $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ) );
?>
       <div class="item">
       <?php if($image[0]){ ?>
           <a href="<?php echo site_url();?>/flash-deals/?id=<?php echo get_the_ID();?>"><div class="flash-deal-thump-cover">
               <img src="<?php echo $image[0];?>" alt=""></div></a>
           <?php } else { ?>  
           <div class="flash-deal-thump-cover"><img src="<?php echo site_url();?>/wp-content/uploads/woocommerce-placeholder.png" alt="" class="dealimgs"></div>
       <?php } ?>
           <div class="dealsText" style="margin-bottom:20px;">
           <a href="<?php echo site_url();?>/flash-deals/?id=<?php echo get_the_ID();?>" style="color:#fff;"><?php echo get_the_title();?>
          
       </a>
           </div>

       </div>
    <?php  }  wp_reset_query(); ?>
   </div>
 </div>
</section>
  <?php }



    
    add_action('wp_ajax_filterPriceprod', 'eventfilterPriceprod');
    add_action('wp_ajax_nopriv_filterPriceprod', 'eventfilterPriceprod');
    function eventfilterPriceprod(){
        global $wpdb;
       // echo "eveth ajax";
        $newArray = array();
        $minpr = $_POST['minprice'];  
        $maxpr = $_POST['maxprice'] ;
        $pdid = $_POST['prodID'];  
       // echo $minpr;
       // echo $maxpr; 
       // print_r($pdid); 
       foreach($pdid as $prod){   
            $_product = wc_get_product($prod);
            $prodprice = $_product->get_price();
            // echo  $prodprice;
            if(($prodprice > $minpr) && ($prodprice < $maxpr)){
                echo $prod;  
               $newArray[] = $prod; 
             //  echo $prod;  
            } //if condition ends 
          }  //foreach loop
        //print_r($newArray);
         foreach($newArray as $val){   
            $product3 = wc_get_product($val);
            $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($val),'prod-thumb');
             
             ?>
         <div class="col-lg-4 col-md-6">
          <div class="resultBox">
          <div class="boxpic">
            <a href="<?php echo $product3->get_permalink();?>">
            <img src="<?php echo $image3[0];?>"> </a>
          </div>
          <div class="boxDetails text-center">
            <h2><?php echo mb_strimwidth(get_the_title($val), 0,100, '...');?></h2>
            <p><?php echo mb_strimwidth($product3->get_short_description($val),0,60,'...');?></p>
          <?php if ($product3->is_type( 'booking' )) { ?>  
            <h3><?php echo $product3->get_price_html(); ?></h3>
           <?php }elseif($product3->product_type=='variable') {   
                            $available_variations = $product3->get_available_variations();
                            $count = count($available_variations)-1;
                            $variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                            $variable_product1= new WC_Product_Variation( $variation_id );
                            $regular_price = $variable_product1 ->regular_price;
                            $sales_price = $variable_product1 ->sale_price;
                        ?>  
                  <h3>KD <?php echo $sales_price;?></h3>
                                <h3>KD <?php echo $regular_price;?></h3> 
             <?php }else{ ?>  
                <h3><?php echo $product3->get_price_html(); ?></h3>
              <?php } ?>
          </div>
          <div class="d-flex">
          
          <div class="cart"><a href="<?php echo $product3->get_permalink();?>" style="color:#fff;"> ADD TO CART</a></div>
              <div class="wishicon"><a href="<?php echo $product3->get_permalink();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/wishicon.png"></a> </div>
          </div>
       </div>
        
      </div>
     <?php } ?>
     <input type="hidden" name="prodid" id="prodid" value="<?php implode(",",$pdid); ?>;">     
      <?php 
     

    } ?>

 <?php
   add_action('wp_ajax_filterPrice', 'eventfilterPrice');
   add_action('wp_ajax_nopriv_filterPrice', 'eventfilterPrice');
   function eventfilterPrice(){
       global $wpdb;
       $minpr = $_POST['minprice'];  
       $maxpr = $_POST['maxprice'] ;
       $ctid = $_POST['catID'];  
       $bgval = $_POST['blogid'] ; 
       $newArray = array();
       $tbl5 = $wpdb->prefix.'blogger_product';
       $qry5 ="select * from " .  $tbl5 ." 
              where bp_status = '1' AND blogger_id = $bgval ";
       $res = $wpdb->get_results($qry5);
       if(count($ctid) > 0){
        foreach($res as $result5){         
            if( has_term($ctid, 'product_cat',$result5->product_id ) ){
                $_product = wc_get_product($result5->product_id );
                $prodprice = $_product->get_price();
            if(($prodprice >=$minpr) &&($prodprice <= $maxpr)){
                    $newArray[] = $result5->product_id;
                } // price checking
                
               }   // category exist checking
            }  //forloop  
          //  $newArray[] = $result5->product_id;
      }else{ 
      
        /*category array null  */
        foreach($res as $prod){
   
         $_product = wc_get_product($prod->product_id);
         $prodprice = $_product->get_price();
         // echo  $prodprice;
         if(($prodprice >=$minpr) && ($prodprice <= $maxpr)){
            $newArray[] = $prod->product_id;

         } //if condition ends 
       }  //foreach loop
    }
     // print_r($newArray);

     
     $tbl6 = $wpdb->prefix.'postmeta';
     $cityval = $_POST['loca'];
     $newArrayVal = array();
       foreach($newArray as $serchval){
         $qry6 ="select * from " .  $tbl6 ." where meta_key = '_yith_booking_location' AND meta_value like  
               '".$cityval."%' and post_id = '".$serchval."' " ;
 
 
               $res6 = $wpdb->get_results($qry6);
               if(count($res6) > 0){   
               foreach($res6 as $result6){  
                  $newArrayVal[] =  $result6->post_id;  
                   
                 } 
               }      
          }
         
 
      if(count($newArrayVal)>0){  
         $pidval =  implode(",",$newArrayVal);
   
       foreach($newArrayVal as $val){   
           $product3 = wc_get_product($val);
           $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($val),'prod-thumb');
            
            ?>
        <div class="col-lg-4 col-md-6">
         <div class="resultBox">
         <div class="boxpic">
           <a href="<?php echo $product3->get_permalink();?>">
           <img src="<?php echo $image3[0];?>"> </a>
         </div>
         <div class="boxDetails text-center">
           <h2><?php echo mb_strimwidth(get_the_title($val), 0,100, '...');?></h2>
           <p><?php echo mb_strimwidth($product3->get_short_description($val),0,60,'...');?></p>
         <?php if ($product3->is_type( 'booking' )) { ?>  
           <h3><?php echo $product3->get_price_html(); ?></h3>
          <?php }elseif($product3->product_type=='variable') {   
                           $available_variations = $product3->get_available_variations();
                           $count = count($available_variations)-1;
                           $variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                           $variable_product1= new WC_Product_Variation( $variation_id );
                           $regular_price = $variable_product1 ->regular_price;
                           $sales_price = $variable_product1 ->sale_price;
                       ?>  
                 <h3>KD <?php echo $sales_price;?></h3>
                               <h3>KD <?php echo $regular_price;?></h3> 
            <?php }else{ ?>  
               <h3><?php echo $product3->get_price_html(); ?></h3>
             <?php } ?>
         </div>
         <div class="d-flex">
         
         <div class="cart"><a href="<?php echo $product3->get_permalink();?>" style="color:#fff;"> ADD TO CART</a></div>
             <div class="wishicon"><a href="<?php echo $product3->get_permalink();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/wishicon.png"></a> </div>
         </div>
      </div>
       
     </div>
    <?php }
     }else{ ?>
                <p class="woocommerce-info" style="width:100%;"><?php esc_html_e( 'No products were found matching your selection.', 'woocommerce' ); ?></p>
      <?php   } ?>
      <input type="hidden" name="prodid" id="prodid" value="<?php echo $pidval; ?>;">     
       <?php 
       die(); 

   }   // function ends

 /* function for autofilling locatin textbox */
  add_action('wp_ajax_searchLocation', 'eventsearchLocation');
  add_action('wp_ajax_nopriv_searchLocation', 'eventsearchLocation');
  function eventsearchLocation(){
      global $wpdb;
     // echo "eveth ajax";
    $cityval =  $_POST['city'];

    $tbl5 = $wpdb->prefix.'postmeta';
    $qry5 ="select * from " .  $tbl5 ." where meta_key = '_yith_booking_location' AND meta_value like  '".$cityval."%' " ;
    $res = $wpdb->get_results($qry5);
    if(count($res) > 0){   
      foreach($res as $result5){  $cityval = "'".$result5->meta_value."'"; ?>     
            <a href="javascript:void(0);" onclick="exchangeVal(<?php echo $cityval;?>)" style="padding: 0px;font-size: 1rem;font-weight: 400;
    line-height: 1.5; color: #495057; text-decoration: none;"><?php echo $result5->meta_value; ?></a>       
        
     <?php } 
    } 
     die();
  }
 
  




  add_action('wp_ajax_sortProducts', 'eventsortProducts');
  add_action('wp_ajax_nopriv_sortProducts', 'eventsortProducts');
  function eventsortProducts(){
      global $wpdb;
     // echo "eveth ajax";
      $order = $_POST['prdorder'];  
      $prdsarray = $_POST['prdval'] ;
    // echo $order;
     // print_r($prdsarray);
      $prodtopass = implode(",",$prdsarray);
    //  echo $prodtopass;
      $bgvalue   = $_POST['bgval'];
     
      $productarray = array();
    /* if($order == 'date'){
        $orderby= 'date'; 
        $order = 'asc';  }
     if($order == 'price'){
        $orderby= 'price'; 
        $order = 'asc';  }
     if($order == 'oldest_to_recent'){
        $orderby= 'date'; 
        $order = 'desc' ; }
     if($order == 'price-desc'){
        $orderby= 'price'; 
        $order = 'desc' ; } */
        foreach($prdsarray as $vl){
            $product3 = wc_get_product($vl);
            $prodprice = $product3->get_price();
            $productarray[$vl] = $prodprice;
        }
        if($order == 'price'){
            asort($productarray,1);
           // print_r($productarray); 
          // $pidval =  implode(",",$productarray);
   
            foreach($productarray as $key => $value){   
                $product3 = wc_get_product($key);
                $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($key),'prod-thumb');
                    
                    ?>
                <div class="col-lg-4 col-md-6">
                <div class="resultBox">
                <div class="boxpic">
                <a href="<?php echo $product3->get_permalink();?>">
                <img src="<?php echo $image3[0];?>"> </a>
                </div>
                <div class="boxDetails text-center">
                <h2><?php echo mb_strimwidth(get_the_title($key), 0,100, '...');?></h2>
                <p><?php echo mb_strimwidth($product3->get_short_description($key),0,60,'...');?></p>
                <?php if ($product3->is_type( 'booking' )) { ?>  
                <h3><?php echo $product3->get_price_html(); ?></h3>
                <?php }elseif($product3->product_type=='variable') {   
                                $available_variations = $product3->get_available_variations();
                                $count = count($available_variations)-1;
                                $variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                                $variable_product1= new WC_Product_Variation( $variation_id );
                                $regular_price = $variable_product1 ->regular_price;
                                $sales_price = $variable_product1 ->sale_price;
                            ?>  
                        <h3>KD <?php echo $sales_price;?></h3>
                                    <h3>KD <?php echo $regular_price;?></h3> 
                    <?php }else{ ?>  
                    <h3><?php echo $product3->get_price_html(); ?></h3>
                    <?php } ?>
                </div>
                <div class="d-flex">
                 <input type="hidden" name="prodid" id="prodid" value="<?php echo $prodtopass;?>"> 
                <div class="cart"><a href="<?php echo $product3->get_permalink();?>" style="color:#fff;"> ADD TO CART</a></div>
                    <div class="wishicon"><a href="<?php echo $product3->get_permalink();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/wishicon.png"></a> </div>
                </div>
            </div>
            
            </div>
            <?php }
          }  //price ASC ends here
        if($order == 'price-desc'){
            arsort($productarray,1);
            //print_r($productarray); 
           // $pidval =  implode(",",$productarray);
   
            foreach($productarray as $key => $value){   
                $product3 = wc_get_product($key);
                $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($key),'prod-thumb');
                    
                    ?>
                <div class="col-lg-4 col-md-6">
                <div class="resultBox">
                <div class="boxpic">
                <a href="<?php echo $product3->get_permalink();?>">
                <img src="<?php echo $image3[0];?>"> </a>
                </div>
                <div class="boxDetails text-center">
                <h2><?php echo mb_strimwidth(get_the_title($key), 0,100, '...');?></h2>
                <p><?php echo mb_strimwidth($product3->get_short_description($key),0,60,'...');?></p>
                <?php if ($product3->is_type( 'booking' )) { ?>  
                <h3><?php echo $product3->get_price_html(); ?></h3>
                <?php }elseif($product3->product_type=='variable') {   
                                $available_variations = $product3->get_available_variations();
                                $count = count($available_variations)-1;
                                $variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                                $variable_product1= new WC_Product_Variation( $variation_id );
                                $regular_price = $variable_product1 ->regular_price;
                                $sales_price = $variable_product1 ->sale_price;
                            ?>  
                        <h3>KD <?php echo $sales_price;?></h3>
                                    <h3>KD <?php echo $regular_price;?></h3> 
                    <?php }else{ ?>  
                    <h3><?php echo $product3->get_price_html(); ?></h3>
                    <?php } ?>
                </div>
                <div class="d-flex">
                <input type="hidden" name="prodid" id="prodid" value="<?php echo $prodtopass;?>"> 
                <div class="cart"><a href="<?php echo $product3->get_permalink();?>" style="color:#fff;"> ADD TO CART</a></div>
                    <div class="wishicon"><a href="<?php echo $product3->get_permalink();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/wishicon.png"></a> </div>
                </div>
            </div>
            
            </div>
            <?php } 

        } //price DESC ends here
       
       
  } 
  
  add_action('wp_ajax_searchtextProducts', 'eventsearchtextProducts');
   add_action('wp_ajax_nopriv_searchtextProducts', 'eventsearchtextProducts');
   function eventsearchtextProducts(){
      
       global $wpdb;
       $serchval   = $_POST['sertext'];
       $prdsarray  = $_POST['prdval'] ;
       $prodtopass = array();
       $newArray = array();
       $tblpost = $wpdb->prefix.'posts';
      //  $qrypost ="select * from " .  $tblpost ." where `post_type` ='product' AND `post_title` like '".$serchval.'%'. "' ";
      $qrypost ="select * from " .  $tblpost ." where `post_type` ='product' AND `post_title` like  '".$serchval.'%'. "' " ;
     // echo "select * from " .  $tblpost ." where `post_type` ='product' AND `post_title` like  '".$serchval.'%'. "' " ;
        $respost = $wpdb->get_results($qrypost);

        if(count($respost) > 0){   
        foreach($respost as $result5){ 
          
          $product3 = wc_get_product($result5->ID);
          $prodtopassarra[] = $result5->ID ;
          $prodtopass  = implode(",",$prodtopassarra);
          $image3 = wp_get_attachment_image_src( get_post_thumbnail_id($result5->ID),'prod-thumb');
              
              ?>
          <div class="col-lg-4 col-md-6">
          <div class="resultBox">
          <div class="boxpic">
          <a href="<?php echo $product3->get_permalink();?>">
          <img src="<?php echo $image3[0];?>"> </a>
          </div>
          <div class="boxDetails text-center">
          <h2><?php echo mb_strimwidth(get_the_title($result5->ID), 0,100, '...');?></h2>
          <p><?php echo mb_strimwidth($product3->get_short_description($result5->ID),0,60,'...');?></p>
          <?php if ($product3->is_type( 'booking' )) { ?>  
          <h3><?php echo $product3->get_price_html(); ?></h3>
          <?php }elseif($product3->product_type=='variable') {   
                          $available_variations = $product3->get_available_variations();
                          $count = count($available_variations)-1;
                          $variation_id=$available_variations[$count]['variation_id']; // Getting the variable id of just the 1st product. You can loop $available_variations to get info about each variation.
                          $variable_product1= new WC_Product_Variation( $variation_id );
                          $regular_price = $variable_product1 ->regular_price;
                          $sales_price = $variable_product1 ->sale_price;
                      ?>  
                  <h3>KD <?php echo $sales_price;?></h3>
                              <h3>KD <?php echo $regular_price;?></h3> 
              <?php }else{ ?>  
              <h3><?php echo $product3->get_price_html(); ?></h3>
              <?php } ?>
          </div>
          <div class="d-flex">
         
          <div class="cart"><a href="<?php echo $product3->get_permalink();?>" style="color:#fff;"> ADD TO CART</a></div>
              <div class="wishicon"><a href="<?php echo $product3->get_permalink();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/wishicon.png"></a> </div>
          </div>
      </div>
      
      </div>
      <?php




 
        } // foreach ends here
      }else{ ?>
              <p class="woocommerce-info" style="width:100%;"><?php esc_html_e( 'No products were found matching your selection.', 'woocommerce' ); ?></p>
                <?php  
             $prodtopass  = implode(",",$prdsarray);
            
            
            } ?>
                <input type="hidden" name="prodid" id="prodid" value="<?php echo $prodtopass; ?>;">     
                <?php 
                die(); 

   }    // function ends

  




  //remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );

 //remove product title only
 remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );

 remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );


 add_action('wp_ajax_filterdaterange', 'eventfilterdaterange');
 add_action('wp_ajax_nopriv_filterdaterange', 'eventfilterdaterange');

 function eventfilterdaterange(){
    
    global $wpdb;
    $sortby      = $_POST['sortby'];
    $userid     = $_POST['userval'];  
  $orme     = $wpdb->prefix.'wc_order_stats';
  $ormeta   = $wpdb->prefix.'woocommerce_order_itemmeta';
  $ormeta2  = $wpdb->prefix.'woocommerce_order_items'; 
  $orderarray = array();
  $newdisplayarray = array();

       $ormequery = "select order_id from " .$orme. " where customer_id = " .$userid ;
       
       $ormeres   = $wpdb->get_results($ormequery); 
       foreach($ormeres as $ormeval){
             $orderarray[]  = $ormeval->order_id;
       } 
     
     if($sortby!='0'){
       foreach($orderarray as $result2){
            $order = wc_get_order($result2);
            $ordrdate = date_create($order->get_date_created());   
            if($order->get_status() == $sortby) {  
                $qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
                FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
                item.order_item_id = ord.order_item_id AND
                ord.order_id = '".$result2."'  " ;        
             $res2 = $wpdb->get_results($qrybg2); 
             foreach($res2 as $resval){  
                 $newdisplayarray[] = $resval->order_id;     
          
              }      
           } 
        }
         if(count($newdisplayarray)=='0'){
            echo "F";
          }    
     }else{
        foreach($orderarray as $result2){
            $order = wc_get_order($result2);
            $ordrdate = date_create($order->get_date_created());   
           $qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
                FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
                item.order_item_id = ord.order_item_id AND
                ord.order_id = '".$result2."'  " ;        
             $res2 = $wpdb->get_results($qrybg2); 
             foreach($res2 as $resval){  
                 $newdisplayarray[] = $resval->order_id;     
          
              }      
                  
          } 
        

     }
    if(count($newdisplayarray>0)){ 
        foreach($newdisplayarray as $result2){        
            $order = wc_get_order($result2);
            $ordrdate = date_create($order->get_date_created());   
            $qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
                FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
                item.order_item_id = ord.order_item_id AND
                ord.order_id = '".$result2."'  " ;      


                $res2 = $wpdb->get_results($qrybg2); 
                foreach($res2 as $resval){?>
             <tr id="statuschecked">
                <td><?php echo $resval->order_id .'<br/>'; ?>
                <?php echo 'Order Created On : '.date_format( $ordrdate,'d-m-Y');?></td>       
                <td><?php echo $resval->order_item_id;?></td>
                <td><?php echo $resval->order_item_name;?></td>          
                <td><?php echo $order->get_status();?></td>
        
            </tr> 
        
        <?php  }      
        
            }
    }else{echo "F";  }

      die();
       
 } // function ends 



  add_action('wp_ajax_assignproductsblog', 'eventassignproductsblog');
  add_action('wp_ajax_nopriv_assignproductsblog', 'eventassignproductsblog');
  function eventassignproductsblog(){
    //echo "aveth ajax";
    //$wpdb->insert($table2,array('object_id'=>$sel,'term_taxonomy_id'=>$blogger,'term_order'=>0),array('%d','%d','%d'));

    $t=time();
    $ti = date("Y-m-d",$t);
  global $wpdb;
    $table = $wpdb->prefix.'blogger_product'; 
    $table2 = $wpdb->prefix.'term_relationships';       
    $prodsel      = $_POST['prodarr'];
    $blogger      = $_POST['blogid'];
    $selaction    = $_POST['slact'];
   // echo $selaction;
    if($selaction == '1'){
       // echo "inside";
        foreach($prodsel as $sel){
           $frstqry = "SELECT * FROM ".$table2. " WHERE object_id = " . $sel. " AND term_taxonomy_id = " . $blogger ; 
           $frstres = $wpdb->get_results($frstqry);
           $rwcount = count($frstres);
           if($rwcount == 0){
                $wpdb->query("INSERT INTO " .$table2. "(object_id, term_taxonomy_id, term_order) VALUES (" .$sel."," .$blogger.", 0)" );
            }
        }    
    }else{
          
        foreach($prodsel as $sel){        
           $wpdb->query("DELETE  FROM " .$table2. " WHERE object_id = " .$sel. " AND term_taxonomy_id = " .$blogger );
           //echo "DELETE  FROM " .$table2. " WHERE object_id = " .$sel. " AND term_taxonomy_id = " .$blogger;
        }    
    }
 foreach($prodsel as $sel){
     $qry2 ="SELECT bpid FROM "
        .$table. " WHERE product_id = " . $sel. " AND blogger_id = " . $blogger ;

    $results2 = $wpdb->get_results( $qry2); 
    $rowcount = count($results2); //PHP count()
   if($rowcount == 0){  
       
    $wpdb->insert( 
        $table, 
        array( 
            'product_id' =>  $sel, 
            'blogger_id' => $blogger ,
            'bp_status'=> $selaction,
            'time'=>$ti
        ), 
        array( 
            '%d', 
            '%d',
            '%d',
            '%s'

        ) 
     ); 
     
   }else{ 

        
       $wpdb->update( 
        $table, 
        array( 
            'bp_status' => $selaction
        ), 
        array( 'blogger_id' => $blogger , 'product_id' => $sel)
       );

       


    } 

  }
   echo "Updated Blogger Products" ;
   die; 
 
} // fun complete

 add_action('wp_ajax_filterbookingstatus', 'eventfilterbookingstatus');
 add_action('wp_ajax_nopriv_filterbookingstatus', 'eventfilterbookingstatus');

function eventfilterbookingstatus(){
   
   global $wpdb;
   $sortby      = $_POST['sortby'];
   $userid     = $_POST['userval'];  
   $ordordval = $_POST['ordval']; 
  
  $orme     = $wpdb->prefix.'wc_order_product_lookup';
 $ormeta   = $wpdb->prefix.'woocommerce_order_itemmeta';
 $ormeta2  = $wpdb->prefix.'woocommerce_order_items'; 
 $newpost  = $wpdb->prefix.'posts'; 
 $datetbl  = $wpdb->prefix.'postmeta';
 
 $orderarray = array();
 $postarray  = array();
 $newdisplayarray = array();
  if($sortby != '0'){
    foreach($ordordval as $result2){ 
        $postid = $result2 + 1;
        $qry = "select ID, post_status from " .$newpost. " where ID = " .$postid;
        $rs  = $wpdb->get_results( $qry);
        foreach($rs as $vl){
           $sts = $vl->post_status;
           if($sts  ==  $sortby){
               $newdisplayarray[] = $vl->ID;
           }
        } 
    }    
     //print_r($newdisplayarray);
     if(count($newdisplayarray)=='0'){
        echo "F";
      } 
     foreach($newdisplayarray as $newval){ 
        $sub = 1;  
        $order = $newval - $sub ;
      
        
        ?>
      <tr class="booking">
          <td class="booking-id" data-title="Booking"><a href="<?php echo site_url();?>/my-account/view-booking/<?php echo $newval; ?>">
          <?php echo '#'.$newval; ?></a>
        <a href="<?php echo get_the_permalink($newval);?>"><?php echo get_the_title($newval);?></a></td>
            <td class="booking-order" data-title="Order">
        <a href="<?php echo site_url();?>/my-account/view-order/<?php echo $order; ?>"><?php echo '#'. $order; ?></a>                    </td>
            <td class="booking-from" data-title="From">
            <?php 
              $thepost = $wpdb->get_row( $wpdb->prepare( "select meta_value from " .$datetbl." where meta_key = '_from' AND post_id = " .$newval) );
              $timestamp= $thepost->meta_value	;
              echo gmdate("F d, Y", $timestamp);
            ?>
            </td>
            <td class="booking-to" data-title="To">
            <?php   $thepost2 = $wpdb->get_row( $wpdb->prepare( "select meta_value from " .$datetbl." where meta_key = '_start' AND post_id = " .$newval) );
              $timestamp2 = $thepost2->meta_value	;
              echo gmdate("F d, Y", $timestamp2); ?>
              </td>
            <td class="booking-status" data-title="Status" style="text-transform: capitalize;">
            <?php $sts = get_post_status($newval);
                  $s = explode("bk-", $sts);
                  echo $s[1];
            ?>                    
            </td>
       <td class="booking-actions" data-title="&nbsp;">
        <div class="yith-wcbk-booking-actions">
        <a href="<?php echo site_url();?>/my-account/view-booking/<?php echo $newval; ?>" class="button view ">View</a></div>
        </td>
        </tr>

     <?php } 
  }else{
         
    foreach($ordordval as $result2){ 
        $postid = $result2 + 1;
        $qry = "select ID, post_status from " .$newpost. " where ID = " .$postid;
        $rs  = $wpdb->get_results( $qry);
        foreach($rs as $vl){
           $sts = $vl->post_status;           
               $newdisplayarray[] = $vl->ID;
           
        } 
    }    
     //print_r($newdisplayarray);
     if(count($newdisplayarray)=='0'){
        echo "F";
      } 
     foreach($newdisplayarray as $newval){ 
        $sub = 1;  
        $order = $newval - $sub ;
      
        
        ?>
      <tr class="booking">
          <td class="booking-id" data-title="Booking"><a href="<?php echo site_url();?>/my-account/view-booking/<?php echo $newval; ?>">
          <?php echo '#'.$newval; ?></a>
        <a href="<?php echo get_the_permalink($newval);?>"><?php echo get_the_title($newval);?></a></td>
            <td class="booking-order" data-title="Order">
        <a href="<?php echo site_url();?>/my-account/view-order/<?php echo $order; ?>"><?php echo '#'. $order; ?></a>                    </td>
            <td class="booking-from" data-title="From"><?php 
              $thepost = $wpdb->get_row( $wpdb->prepare( "select meta_value from " .$datetbl." where meta_key = '_from' AND post_id = " .$newval) );
              $timestamp= $thepost->meta_value	;
              echo gmdate("F d, Y", $timestamp);
            ?></td>
            <td class="booking-to" data-title="To">
            <?php   $thepost2 = $wpdb->get_row( $wpdb->prepare( "select meta_value from " .$datetbl." where meta_key = '_start' AND post_id = " .$newval) );
              $timestamp2 = $thepost2->meta_value	;
              echo gmdate("F d, Y", $timestamp2); ?></td>
            <td class="booking-status" data-title="Status" style="text-transform: capitalize;">
            <?php $sts = get_post_status($newval);
                  $s = explode("bk-", $sts);
                  echo $s[1];
            ?>                    
            </td>
       <td class="booking-actions" data-title="&nbsp;">
        <div class="yith-wcbk-booking-actions">
        <a href="<?php echo site_url();?>/my-account/view-booking/<?php echo $newval; ?>" class="button view ">View</a></div>
        </td>
        </tr>

     <?php } 

         
     }
      die();

} // function




 add_filter( 'woocommerce_checkout_fields' , 'custom_remove_woo_checkout_fields' );
 
 function custom_remove_woo_checkout_fields( $fields ) {

    // remove billing fields
 
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_country']);
    unset($fields['billing']['billing_state']); 
    
      return $fields;
  }


add_action('wp_ajax_bloggerproinfo', 'bloggerproinfo');
add_action('wp_ajax_nopriv_bloggerproinfo', 'bloggerproinfo');

function bloggerproinfo(){
  global $wpdb;

  $sortby      = $_POST['bgval'];
  $table = $wpdb->prefix.'blogger_product';

  $args = array(
    'post_type' => 'product',
    'posts_per_page' => -1,
    'orderby'        => 'date',
    'order'          => 'DESC',
    'post_status'    => 'publish',
    );
    $loop = new wp_Query($args);
  if ( $loop->have_posts() ) :
  while($loop->have_posts()) : $loop->the_post();
   $image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'product-main' );
    $pid   = get_the_ID();
    ?> 
    <tr class="text-gray-700 dark:text-gray-400">
    <td style="text:align:center;" class="prchk">
    <?php 
    $thepost ="SELECT bpid FROM "
        .$table. " WHERE product_id = " . $pid. " AND bp_status = 1 AND  blogger_id = " . $sortby ;        

    $results2 = $wpdb->get_results( $thepost); 
    $rowcount = count($results2); 
   if($rowcount!=''){
    ?>
    <input type="checkbox" name="prodsel" value="<?php echo get_the_ID();?>" class="product" checked>
   <?php }else{ ?>
    <input type="checkbox" name="prodsel" value="<?php echo get_the_ID();?>" class="product" >

   <?php } ?>
    </td>
    <td class="px-4 py-3" class="primg">
    <div class="flex items-center text-sm">
        <!-- Avatar with inset shadow -->
        <div class="relative hidden w-8 h-8 mr-3 rounded-full md:block">
        <img src="<?php echo $image[0];?>" alt="" >        
        <div class="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
        </div>
        <div>
        <p class="font-semibold"></p>
        </div>
    </div>
    </td>
    <td class="px-4 py-3 text-sm">
    <p class="font-semibold"><?php echo get_the_title();?>(<?php echo get_the_ID();?>)</p>
    </td>
              <td class="px-4 py-3 text-xs">
            <?php
                global $wpdb;
                $tbl3 = $wpdb->prefix.'terms';
                $tbl4 = $wpdb->prefix.'blogger_product';
                $qry2 ="select bg.blogger_id, bg.product_id,bg.bp_status ,t.name from " .$tbl4. " bg , " .$tbl3. " t
                        where  bg.blogger_id = t.term_id AND
                        bg.bp_status = '1' AND
                        bg.product_id = ".$pid ;
     
         
               $results2 = $wpdb->get_results( $qry2); 
               $rowcount = count( $results2  ); //PHP count()
            
               if($rowcount > 0){   
               foreach($results2 as $result2){ ?>
                     
              <span class="px-2 py-1 font-semibold leading-tight text-gray-700 bg-gray-100 rounded-full dark:text-gray-100 dark:bg-gray-700">
                  <?php echo $result2->name; ?>
                </span>
              <?php }  
                 } else { ?>
                <span class="px-2 py-1 font-semibold leading-tight text-gray-700 bg-gray-100 rounded-full dark:text-gray-100 dark:bg-gray-700">
                  <?php echo "*****" ; ?>
                </span>
               <?php } ?>    

              </td>
              
            </tr>
            <?php
                endwhile;
                wp_reset_query();
                endif; 

 } 

 add_filter( 'woocommerce_billing_fields', 'adjust_requirement_of_checkout_contact_fields');
    function adjust_requirement_of_checkout_contact_fields( $fields ) {
        $fields['billing_email']['required']    = false;
        return $fields;
    }


 add_action('wp_ajax_bloggerorderids', 'bloggerorderids');
 add_action('wp_ajax_nopriv_bloggerorderids', 'bloggerorderids');
 function bloggerorderids(){
    global $wpdb;
     $bgid = $_POST['bgval'];

     $tbl3 = $wpdb->prefix.'woocommerce_order_items';
     $tbl4 = $wpdb->prefix.'woocommerce_order_itemmeta';
     $tbl5 = $wpdb->prefix.'blogger_product';

     /* echo $bgid; */
     $qry = "SELECT items.order_id,items.order_item_id,itemmeta.meta_value FROM " .$tbl3." items, "
            .$tbl4. " itemmeta where items.order_item_id = itemmeta.order_item_id
             AND itemmeta.meta_key = 'BGCODE' AND items.order_id = " .$bgid;
     
           /* echo "SELECT items.order_id,items.order_item_id,itemmeta.meta_value FROM " .$tbl3." items, "
             .$tbl4. " itemmeta where items.order_item_id = itemmeta.order_item_id
              AND itemmeta.meta_key = 'BGCODE' AND items.order_id = " .$bgid; */
              
     $results = $wpdb->get_results($qry);      
      foreach($results as $vl){
          $bgname = $vl->meta_value;
          $get_number = preg_replace('/[^0-9]+/', '', $bgname );
          $blg = $get_number;        
      }        

      $bgidquery = "select blogger_id  from " .$tbl5. " where bpid = " .$blg;
      echo "select blogger_id  from " .$tbl5. "where bpid = " .$blg;
      $bgres    = $wpdb->get_results($bgidquery);
      foreach($bgres as $bgrs){
          $blgid = $bgrs->blogger_id;
      } 
        

       $qry2 = "SELECT items.order_id,items.order_item_id,itemmeta.meta_value FROM " .$tbl3." items, "
      .$tbl4. " itemmeta where items.order_item_id = itemmeta.order_item_id
       AND itemmeta.meta_key = 'REFEREDCODE' AND items.order_id = " .$bgid;
   
        $results2 = $wpdb->get_results($qry2);      
        foreach($results2 as $vl2){
            $refname = $vl2->meta_value;
            $get_number2 = preg_replace('/[^0-9]+/', '', $refname );
            $blg2 = $get_number2;  
        }        
  
        $bgidquery2 = "select blogger_id  from " .$tbl5. " where bpid = " .$blg2;

        //echo "select blogger_id  from " .$tbl5. "where bpid = " .$get_number2;
        $bgres2   = $wpdb->get_results($bgidquery2);
        foreach($bgres2 as $bgrs2){
            $blgid2 = $bgrs2->blogger_id;
        }
      ?>
           

       
    <tr>
      <td>Blogger Direct Booking</td>
      <td > 
        <input type="text"  class="form-control" value="<?php echo $bgname;?>" disabled="disabled" >
        <input type="hidden" name="dirblgr" id="dirblgr" value="<?php echo $blgid;?>">
      </td>
      </tr>
      
      <tr>
          <td>Add Direct Commison Amount</td>
          <td>
          <input type="text" name="dircommission" id="dircommission" class="form-control"></td>
       </tr>

       <tr>
         <td>Blogger By Reference</td>
           <td> 
           <input type="text" class="form-control" value="<?php echo $refname;?>" disabled="disabled" >
           <input type="hidden" name="refblgr" id="refblgr" value="<?php echo $blgid2;?>">
           </td>
       </tr>
       
       <tr>
          <td>Add Reference Commison Amount</td>
          <td>
          <input type="text" name="refcommission" id="refcommission" class="form-control"></td>
       </tr>



        </tr>
        
           <tr><td >Commission Notes </td>
            <td><textarea name="commnotes" id="commnotes" class="form-control"></textarea></td>
         </tr> 
            
         <tr >  
        <td colspan="2" style="text-align:right;">
          <input type="hidden" name="bgi" id="bgi" value="<?php echo $bgid; ?>">  
           <input type="button" name="submit" id="submit" value="Save" class="btn addcartBtn" onclick="commisubmit();"></td>
      </tr>
   
   
   
   <?php    die;
 }




add_action('wp_ajax_addcommision', 'addcommision');
add_action('wp_ajax_nopriv_addcommision', 'addcommision');
function addcommision(){
    global $wpdb;
    $comtable = $wpdb->prefix.'blogger_commision';
   
   // data:{"action":"addcommision","ordnum":ordid,"dirord":dirbg,"diramount":diramt,"reford":refbg,"refamount":refamt,"cmnt":not}
   
   
     $ordid       = $_POST['ordnum'];
     $dirorderbg  = $_POST['dirord'];
     $reforderbg  =  $_POST['reford'];
     //$bg      =    $_POST['blog'];     
     $not     = $_POST['cmnt'];
     $sts     = "initiated";
     $date    = date('Y/m/d', time());
     
     if($dirorderbg != ''){        
        $diramt =  $_POST['diramount'];
        $type   = 'directorder';
        $qry     ="select cmid from " .$comtable. " where ord_id = " .$ordid. " AND blogger_id = " .$dirorderbg. " AND commi_type = '".$type."' ";
       
        //echo "select cmid from " .$comtable. " where ord_id = " .$ordid. " AND blogger_id = " .$dirorderbg. " AND commi_type = '".$type."' ";  

        $results = $wpdb->get_results( $qry); 
        $rowcount = count( $results  ); //PHP count
       
       if($rowcount == 0){ 
            $sql = $wpdb->prepare("INSERT INTO ".$comtable. "(`ord_id`,`commi_amt`,`commi_notes`,`commi_type`,`commi_date`,`commi_status`,`blogger_id`) values
             ('".$ordid."', '".$diramt."', '".$not."', '".$type."','".$date."', '".$sts."','".$dirorderbg."')");

          
            $wpdb->query($sql); 
            echo "Commission Added";
        }   
     }
     
     if($reforderbg != ''){
        $refamt     =  $_POST['refamount'];
        $type  = 'orderbyref';
        $qry2     ="select cmid from " .$comtable. " where ord_id = " .$ordid. " AND blogger_id = " .$reforderbg. " AND commi_type = '".$type."' ";
  // echo "select cmid from " .$comtable. " where ord_id = " .$ordid. " AND blogger_id = " .$reforderbg. " AND commi_type = '".$type."' ";
        $results2 = $wpdb->get_results( $qry2); 
        $rowcount = count( $results2  ); //PHP count


        if($rowcount == 0){ 
            $sql = $wpdb->prepare("INSERT INTO ".$comtable. "(`ord_id`,`commi_amt`,`commi_notes`,`commi_type`,`commi_date`,`commi_status`,`blogger_id`) values
             ('".$ordid."', '".$refamt."', '".$not."', '".$type."','".$date."', '".$sts."','".$reforderbg."')");

           

            $wpdb->query($sql); 
            echo "Commission Added";
        } 
     }       
    
     die;
} //commision adding ends here    
//add_filter( 'wcfm_is_allow_store_name', '__return_false' );  

add_action('wp_ajax_filtrevenue', 'filtrevenue');
add_action('wp_ajax_nopriv_filtrevenue', 'filtrevenue');
function filtrevenue(){
    //echo "revenue";
    $date = date("Y-m-d");// current date

      //$date = strtotime(date("Y-m-d", strtotime($date)) . " -1 day");

    $week = strtotime(date("Y-m-d", strtotime($date)) . " -1 week");
    $weeknew = date('Y-m-d', $week);

  //  $date = strtotime(date("Y-m-d", strtotime($date)) . " +2 week");

  //  $date = strtotime(date("Y-m-d", strtotime($date)) . " +1 month");

    $month = strtotime(date("Y-m-d", strtotime($date)) . " -1 month");
    $monthnew = date('Y-m-d', $month);

    $year = strtotime(date("Y-m-d", strtotime($date)) . " -12 month");
    $yearnew = date('Y-m-d', $year);



    global $wpdb;
    $comtable = $wpdb->prefix.'blogger_commision';
    $bgid       =    $_POST['blogr'];
    $period   =    $_POST['revemod'];
    // alert('yes');
     if($period == '0'){
        $qrycom = "SELECT * FROM " .$comtable. " where blogger_id   = " .$bgid ; 
        //echo "SELECT * FROM " .$comtable. " where blogger_id   = " .$bgid. " AND " .$timeSQL ; 
        $res2 = $wpdb->get_results( $qrycom); 
     }else{

            if ($period == 'today') {
                $timeSQL = "commi_date = '".$date."' ";
            }
            if($period == 'week'){
                $timeSQL = "commi_date <= '".$date."' AND commi_date >= '".$weeknew."' ";

            }
            if($period == 'monthly'){
                $timeSQL = "commi_date <= '".$date."' AND commi_date >=  '".$monthnew."' ";

            }
            if($period == 'yearly'){
                $timeSQL = "commi_date <= '".$date."' AND commi_date >=  '".$yearnew."' ";

            }

        $qrycom = "SELECT * FROM " .$comtable. " where blogger_id   = " .$bgid. " AND " .$timeSQL ; 
            //echo "SELECT * FROM " .$comtable. " where blogger_id   = " .$bgid. " AND " .$timeSQL ; 
        $res2 = $wpdb->get_results( $qrycom); 

      }    

     
    
     
    if(count($res2) !=''){
     foreach($res2 as $result2){
        $ordtype =  $result2->commi_type;
        if($ordtype='orderbyref'){$type = "Order By Ref";}else{$type = "Direct Order";}
        ?>
        <tr>
        <td><?php  $order = new WC_Order($result2->ord_id);
            $items = $order->get_items();
            foreach ( $items as $item ) {
                $product_name = $item['name']; 
            echo $product_name. '------'.$result2->ord_id;  
            }  ?></td>   
         
         <td><?php echo $type; ?></td>           
         <td><?php echo $result2->commi_status; ?></td>
         <td><?php echo $result2->commi_date; ?></td>
         <td><?php echo $result2->commi_amt; ?></td>
       </tr>
      
     <?php } ?>
     <tr>
       <td></td>
       <td></td>  
       <td></td> 
     
       <td><strong><?php echo "Total Income:" ?></strong></td>
       <?php 
         $tblcom = $wpdb->prefix.'blogger_commision';
         if($period == '0'){

         $qrybgtot = "SELECT sum(`commi_amt`) as tot FROM " .$comtable. " where blogger_id  = " .$bgid. 
                     " group by(`blogger_id`) " ;
         }else{
            $qrybgtot = "SELECT sum(`commi_amt`) as tot FROM " .$comtable. " where blogger_id  = " .$bgid. 
            " AND " .$timeSQL. " group by(`blogger_id`) " ;

         }

   
         $restot = $wpdb->get_results($qrybgtot); 
          foreach($restot as $result2){?>
             <td><strong><?php echo $result2->tot;?></strong></td>
           <?php } ?>
       </tr> 
   <?php }else   { ?>
    <tr>
       <td colspan="4"><?php echo "No records found";?></td><tr>
    <?php } ?>
 <?php 
}   

add_action('wp_ajax_selectcommision', 'selectcommision');
add_action('wp_ajax_nopriv_selectcommision', 'selectcommision');
function selectcommision(){
  
  global $wpdb;
  $comtable = $wpdb->prefix.'blogger_commision';
  $bgid       =    $_POST['blogr'];
  $qrybgtot = "SELECT * FROM " .$comtable. " where blogger_id  = " .$bgid ;
  $restot = $wpdb->get_results($qrybgtot);
  $i = 1 ; 
   foreach($restot as $result2){?>
    <tr>
    <td><?php echo $i;?></td>
    <td><?php echo $result2->ord_id .'('.$result2->commi_type.')'; ?></td>
    <td><?php echo $result2->commi_amt;?></td>
    <td><?php echo $result2->commi_notes;?></td>
    <td><?php echo $result2->commi_status;?>	</td>
    <td><a href="#" onclick="editcommrow(<?php echo $result2->cmid;?>)">Edit</a></td>
   </tr>
            
        <?php $i = $i + 1; }

  die;
}
add_action('wp_ajax_filterordertype', 'filterordertype');
add_action('wp_ajax_nopriv_filterordertype', 'filterordertype');
function filterordertype(){
 global $wpdb;
 $orme  = $wpdb->prefix.'wc_order_stats';
 $ormeta = $wpdb->prefix.'woocommerce_order_itemmeta';
 $ormeta2 = $wpdb->prefix.'woocommerce_order_items';
 $orderarray = array(); 
 $orderitems = array(); 
 $ordbg       =    $_POST['blogid'];
 $ordtype     =    $_POST['seltype'];
 $bloid       =   $_POST['bd'];
 // $ordbg2   = '"'.$ordbg.'"' ;
  $ordtype2 = '"'.$ordtype.'"' ;

 $tblbg = $wpdb->prefix.'blogger_product';
 $qrybg = "select bl.* from ". $tblbg . " bl where 
           bl.blogger_id  =  " .$bloid . " AND bl.bp_status = 1"; 
         
        /* echo "select bl.* from ". $tblbg . " bl where 
           bl.blogger_id  =  " .$bloid . " AND bl.bp_status = 1"; */
           
 $bid = array();
 $res = $wpdb->get_results( $qrybg); 
 foreach($res as $val){
   $bid[] = $val->bpid ;
 }
  //print_r($bid);
 
 
 
  $orderidsarray = array();
 foreach($bid as $bidval){
     $bgname = $ordbg.'('.$bidval.')';
     $blogrna = "'".$bgname."'";

      $qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
      FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
      item.meta_key = " .$ordtype2. " AND
      item.order_item_id = ord.order_item_id AND
      item.meta_value  = " .$blogrna ;



       $res2 = $wpdb->get_results( $qrybg2); 
      // print_r($res2);

      // echo 'count'.count($res2);
    
       foreach($res2 as $result2){ 
          $orderidsarray[] = $result2->order_id;
          $order = wc_get_order($result2->order_id);
          $ordrdate = date_create($order->get_date_created());     
          if(has_post_parent($result2->order_id)){$flg = "no";}  
          if($flg != 'no'){      
         ?>       
         <tr id="statuschecked">

            <td><?php echo $result2->order_id .$flg.'<br/>'; ?>
            <?php echo 'Order Created On : '.date_format( $ordrdate,'d-m-Y');?></td>      
          
            <td><?php echo $result2->order_item_name;?></td>          
            <td><?php echo $order->get_status();?></td>
    
          </tr>
        
        <?php }
         }  
         //else condition 
      }
}

add_action('wp_ajax_editdisplaycommision', 'editdisplaycommision');
add_action('wp_ajax_nopriv_editdisplaycommision', 'editdisplaycommision');
function editdisplaycommision(){
 global $wpdb;
 $rowid = $_POST['cmdrow'];
 //echo $rowid;

 $tblbg = $wpdb->prefix.'blogger_commision';
 $qrybg = "select * from " .$tblbg. " where cmid = " .$rowid; 
  
 $resbg = $wpdb->get_results($qrybg); 
 $stsarray = array('completed','pending','initiated');
 foreach($resbg as $bg){
 
   ?>
  <tr>
   <td>Add Commison Amount</td>
    <td>
    <input type="text" name="commission" id="commission" class="form-control" value="<?php echo $bg->commi_amt;?>"></td>
    </tr>            
    <tr><td>Commission Notes </td>
    <td  ><textarea name="commnotes" id="commnotes" class="form-control"><?php echo $bg->commi_notes;?></textarea></td>
    </tr>
    <tr><td>Commission Status </td>
    <td><select name="commistatus" id="commistaatus" class="form-control">
    <?php foreach($stsarray as $sts){
         if($sts == $bg->commi_status){
        ?>    
        <option value="<?php echo $sts; ?>" selected><?php echo $sts; ?></option>
     <?php }else{ ?>
        <option value="<?php echo $sts; ?>"><?php echo $sts; ?></option>
     <?php 
          }
       } ?>  
    </select>
    </td>
    </tr>
    <tr>  
        <td colspan="2" >
    <input type="hidden" name="bgi" id="bgi" value="<?php echo $bg->cmid; ?>">  
    <input type="button" name="submit" id="submit" value="Update" class="btn addcartBtn" onclick="commiupdate();" style="float:right;" ></td>
    </tr>
  
<?php }
   die;
 }

 add_action('wp_ajax_editupdatecommision', 'editupdatecommision');
 add_action('wp_ajax_nopriv_editupdatecommision', 'editupdatecommision');
 function editupdatecommision(){
  global $wpdb;
  $tableup = $wpdb->prefix.'blogger_commision';
   $rowid = $_POST['cmdrow'];
   $amt = $_POST['cmdamt'];
   $note = $_POST['cmdnote'];
   $sts = $_POST['cmdsts'];
   $wpdb->update( 
    $tableup, 
    array( 
        'commi_amt' => $amt,
        'commi_notes' => $note,
        'commi_status' => $sts,
    ), 
    array('cmid' => $rowid)
   ); 
 }

 add_action('wp_ajax_saveReview', 'saveReview');
 add_action('wp_ajax_nopriv_saveReview', 'saveReview');  
 function saveReview(){
    global $wpdb;
    $tablere = $wpdb->prefix.'blogger_product_review';
    $name = $_POST['aname'];
    $email = $_POST['aemail'];
    $ud = $_POST['auid'];
    $rw = $_POST['areview'];
    $bpid = $_POST['pdid'];
    $bpdate = date("Y-m-d");// current date
    $sts  = 'Not Approved';
    $sql = $wpdb->prepare("INSERT INTO ".$tablere. "(`bpid`,`bp_pro_review`,`bp_userid`,`bp_name`,`bp_email`,`bp_date`,`bp_status`,`bp_type`) values
             ('".$bpid."', '".$rw."', '".$ud."', '".$name."','".$email."', '".$bpdate."','".$sts."','cuser')");        

    $wpdb->query($sql); 
    echo "Review Added";
   die;
 }


 
 add_action('wp_ajax_chanereviewstatus', 'chanereviewstatus');
 add_action('wp_ajax_nopriv_chanereviewstatus', 'chanereviewstatus');  
 function chanereviewstatus(){
    global $wpdb;
    $tablere = $wpdb->prefix.'blogger_product_review';
    $rwid  = $_POST['rowid'];
    $sts = $_POST['sts'];
    echo $rwid;
    echo $sts;
    $wpdb->update( 
        $tablere, 
        array( 
            'bp_status' => $sts 
        ), 
        array( 'bg_prod_rewid' => $rwid  )
       );

       $apprarray = array('Approved','Not Approved');
       $qryrw ="select bp_status from  " .$tablere. " where bg_prod_rewid = " .$rwid;  
       $resrew = $wpdb->get_results($qryrw); 	?>
<select name="revapprove" id="revapprove<?php echo $rwid;?>" onchange="changeapproved('<?php echo $rwid ;?>');">
    <?php 
     
    foreach($apprarray as $app){
        if($res->bp_status == $app){?>
        <option value="<?php echo $app ;?>" selected><?php echo $app ;?></option>
    <?php }else{ ?>
        <option value="<?php echo $app ;?>"><?php echo $app ;?></option>

    <?php }  }?>
    </select>
 <?php 
     die;
 }   
 add_filter( 'admin_footer_text', '__return_empty_string', 11 );
 add_filter( 'update_footer',     '__return_empty_string', 11 );

 function example_admin_bar_remove_logo() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu( 'wp-logo' );
  }
 add_action( 'wp_before_admin_bar_render', 'example_admin_bar_remove_logo', 0 );

function store_mall_wc_empty_cart_redirect_url() {
        $url = 'http://lockmyseat.com/'; // change this link to your need
        return esc_url( $url );
    }
    add_filter( 'woocommerce_return_to_shop_redirect', 'store_mall_wc_empty_cart_redirect_url' );
add_action( 'before_delete_post', function( $id ) {
    $product = wc_get_product( $id );
    if ( ! $product ) {
        return;
    }
      global $wpdb;
      $table2 = $wpdb->prefix.'blogger_product';
       $qr2 =  $wpdb->query("DELETE  FROM " .$table2. " WHERE product_id = " .$id );
    $all_product_ids         = [];
    $product_thum_id_holder  = [];
    $gallery_image_id_holder = [];
    $thum_id                 = get_post_thumbnail_id( $product->get_id() );
    
    if ( function_exists( 'dokan' ) ) {
        $vendor = dokan()->vendor->get( dokan_get_current_user_id() );
        if ( ! $vendor instanceof WeDevs\Dokan\Vendor\Vendor || $vendor->get_id() === 0 ) {
            return;
        }
        $products = $vendor->get_products();
        if ( empty( $products->posts ) ) {
            return;
        }
        foreach ( $products->posts as $post ) {
            array_push( $all_product_ids, $post->ID );
        }
    } else {
        $args     = [ 'posts_per_page' => '-1' ];
        $products = wc_get_products( $args );
        foreach ( $products as $product ) {
            array_push( $all_product_ids, $product->get_id() );
        }
    }

    foreach ( $all_product_ids as $product_id ) {
        
       // $qr2     = "select bpid from " .$table2. " where product_id = " .$pdid. " AND blogger_id = " .$bgid ;
        if ( intval( $product_id ) !== intval( $id ) ) {
            array_push( $product_thum_id_holder, get_post_thumbnail_id( $product_id ) );
            $wc_product        = wc_get_product( $product_id );
           
            $gallery_image_ids = $wc_product->get_gallery_image_ids();
            if ( empty( $gallery_image_ids ) ) {
                continue;
            }
            foreach ( $gallery_image_ids as $gallery_image_id ) {
                array_push( $gallery_image_id_holder, $gallery_image_id );
            }
        }
    }
    if ( ! in_array( $thum_id, $product_thum_id_holder ) && ! in_array( $thum_id, $gallery_image_id_holder ) ) {
        wp_delete_attachment( $thum_id, true );
        if ( empty( $thum_id ) ) {
            return;
        }
        $gallery_image_ids = $product->get_gallery_image_ids();
        if ( empty( $gallery_image_ids ) ) {
            return;
        }
        foreach ( $gallery_image_ids as $gallery_image_id ) {
            wp_delete_attachment( $gallery_image_id, true );
        }
    }


    
} );
add_action('wp_ajax_homeblogshow', 'homeblogshow');
add_action('wp_ajax_nopriv_homeblogshow', 'homeblogshow');  
function homeblogshow(){
   global $wpdb;
   $showids = array();
   $tbl1 = $wpdb->prefix.'terms';
   $tbl2 = $wpdb->prefix.'termmeta';
   $tbl3 = $wpdb->prefix.'term_taxonomy';
   $qry = "select t.term_id as bgid,t.name as bgname,tm.term_id ,t.slug as vendurl,tm.meta_key,tx.description 
          from ".$tbl1. " t ,".$tbl2." tm , ".$tbl3." tx 
          where t.term_id = tm.term_id AND 
          tx.term_id = t.term_id AND 
          tx.taxonomy = 'yith_shop_vendor' AND
          tm.meta_key ='owner' limit 0,10";

  
   $results = $wpdb->get_results($qry); 
   foreach($results as $result){   
     $thumbvendor_id = get_term_meta($result->bgid, 'avatar', true ); 
     $showids[] = $result->bgid;
     $imagenow = wp_get_attachment_image_src( $thumbvendor_id, 'partner-size' ); 
     $inrry = $wpdb->get_row( $wpdb->prepare( "select tm.term_id ,tm.meta_value
           from ".$tbl2." tm 
           where tm.term_id = $result->bgid AND 
           tm.meta_key ='enable_selling' "));
              
      if($inrry->meta_value =='yes'){
?>
    <div class="col-lg-2 pr-1 pl-1">
     <div class="bloggerBox">
     <div class="bloggerPic d-flex justify-content-center">
     <?php if($imagenow[0]){ ?>
       <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>">
      <img src="<?php echo $imagenow[0];?>" alt="" > </a>
         <?php } else { ?>
     <img src="<?php echo site_url();?>/wp-content/uploads/no-blogger.png" alt="">
    <?php } ?>
      </div>
    <div class="bloggerDetails">
      <h3>  <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>"><?php echo $result->bgname; ?></a></h3>
       <!--<p> <?php //echo limit_text( ,12) ;?> </p>-->
     </div>
     </div>
   </div>
   <?php }
    } 
       $showid = implode(',',$showids);

   ?>

 <?php  echo "<script> storeids('".$showid."'); </script>";
     die;
 }  

 add_action('wp_ajax_homeblogshowload', 'homeblogshowload');
 add_action('wp_ajax_nopriv_homeblogshowload', 'homeblogshowload');  
 function homeblogshowload(){
   global $wpdb;
   $shwbids = $_POST['showedblogids'];
   $shwarray = array();
   $shwarray = explode(',',$shwbids);
   $showedids = array();
   $tbl1 = $wpdb->prefix.'terms';
   $tbl2 = $wpdb->prefix.'termmeta';
   $tbl3 = $wpdb->prefix.'term_taxonomy';
   $ipquery= "select t.term_id as bgid,t.name as bgname,tm.term_id ,t.slug as vendurl,tm.meta_key,tx.description 
   from ".$tbl1. " t ,".$tbl2." tm , ".$tbl3." tx 
   where t.term_id = tm.term_id AND 
   tx.term_id = t.term_id AND 
   tx.taxonomy = 'yith_shop_vendor' AND
   tm.meta_key ='owner' ";
   $res2 = $wpdb->get_results($ipquery); 
   
   $rowcount = count($res2);
    $qry = "select t.term_id as bgid,t.name as bgname,tm.term_id ,t.slug as vendurl,tm.meta_key,tx.description 
          from ".$tbl1. " t ,".$tbl2." tm , ".$tbl3." tx 
          where t.term_id = tm.term_id AND 
          tx.term_id = t.term_id AND 
          tx.taxonomy = 'yith_shop_vendor' AND
          t.term_id NOT IN (".$shwbids.") AND
          tm.meta_key ='owner' limit 0,10";
  
   $results = $wpdb->get_results($qry); 
   foreach($results as $result){   
     $thumbvendor_id = get_term_meta($result->bgid, 'avatar', true ); 
     $showedids[] = $result->bgid;
     $imagenow = wp_get_attachment_image_src( $thumbvendor_id, 'partner-size' ); 
     $inrry =$wpdb->get_row( $wpdb->prepare( "select tm.term_id ,tm.meta_value
           from ".$tbl2." tm 
           where tm.term_id = $result->bgid AND 
           tm.meta_key ='enable_selling' "));
              
      if($inrry->meta_value =='yes'){
?>
    <div class="col-lg-2 pr-1 pl-1">
     <div class="bloggerBox">
     <div class="bloggerPic d-flex justify-content-center">
     <?php if($imagenow[0]){ ?>
       <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>">
      <img src="<?php echo $imagenow[0];?>" alt="" > </a>
         <?php } else { ?>
     <img src="<?php echo site_url();?>/wp-content/uploads/no-blogger.png" alt="">
    <?php } ?>
      </div>
    <div class="bloggerDetails">
      <h3>  <a href="<?php echo site_url();?>/blogger/<?php echo $result->vendurl;?>"><?php echo $result->bgname; ?></a></h3>
       <!--<p> <?php //echo limit_text( ,12) ;?> </p>-->
     </div>
     </div>
   </div>
   <?php }
    } 
      // $showid = implode(',',$showedids);
       $alreadydisplayed = array();
       $alreadydisplayed = array_merge($showedids,  $shwarray);
       $showid = implode(',',$alreadydisplayed);
      if(count($alreadydisplayed) < $rowcount){
        echo "<script> storeids('".$showid."'); </script>";
      }else{
        echo "<script> destroyids('".$showid."'); </script>";
      }
   ?>
   <input type="hidden" name="showbgid" id="showbgid" value="<?php echo $alreadydisplayed;?>">
   <?php 
     die;
 }
 add_filter( 'woocommerce_product_tabs', 'wp_woo_rename_reviews_tab', 98);
 function wp_woo_rename_reviews_tab($tabs) {
     global $product;        
         $tabs['reviews']['title'] = 'Reviews';
     return $tabs;
 }
 add_action('wp_ajax_pickbloggers', 'pickbloggers');
 add_action('wp_ajax_nopriv_pickbloggers', 'pickbloggers');  
 function pickbloggers(){
  // echo "yes blogger";
   global $wpdb;
   $ctd = $_POST['catid'];
  // echo $ctd;
  $pid = array();
  $bgids = array(); 

    $all_ids = get_posts( array(
        'post_type' => 'product',
        'numberposts' => -1,
        'post_status' => 'publish',
        'fields' => 'ids',
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' =>  $ctd, /*category name*/
                'operator' => 'IN',
                )
             ),
         ));
         foreach ( $all_ids as $id ) {
              $pid[] = $id;
         }
         $pidstr = implode(',',$pid);
  // print_r($pid);

   $tbl1 = $wpdb->prefix.'terms';
   $tbl2 = $wpdb->prefix.'termmeta';
   $tbl3 = $wpdb->prefix.'blogger_product';
   $qr = "select bg.blogger_id , bg.product_id from ".$tbl3." bg
          where product_id IN ( ".$pidstr.")" ;
    
   
    $res = $wpdb->get_results($qr); 
    foreach($res as $resval){ 
      //  echo $resval->blogger_id;
           $bgids[] = $resval->blogger_id;
    }  
   // print_r($bgids);
    $bgids = array_unique($bgids);
    $bgidss = implode(',',$bgids);

     $qry = "select t.term_id as bgid,t.name as bgname,t.slug,tm.term_id ,tm.meta_key 
            from ".$tbl1. " t ,".$tbl2." tm 
            where t.term_id = tm.term_id AND 
            t.term_id IN (".$bgidss.") AND
            tm.meta_key ='owner' " ;
     $rs = $wpdb->get_results($qry); ?>
    <select class="form-control" name="blg" id="blg">  
    <?php 
    foreach($rs as $vl){ ?>
        <option value="<?php echo $vl->slug;?>"><?php echo $vl->bgname; ?></option>
     <?php } ?>
     </select>       
  <?php

   die;
 }     