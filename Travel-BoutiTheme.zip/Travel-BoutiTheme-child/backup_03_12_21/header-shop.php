<!DOCTYPE html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>

<head>
     <meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>

  <!-- Favicons -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/images/favicon.png" rel="icon">
  <link href="<?php echo get_stylesheet_directory_uri();?>/imgages/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Satisfy&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,200;0,300;0,400;0,600;0,700;0,900;1,200;1,300;1,400;1,600&family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display+SC:wght@400;700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Teko:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@100&display=swap" rel="stylesheet">

  <!-- Bootstrap core CSS -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="<?php echo get_stylesheet_directory_uri();?>/css/jquery-ui.min.css" rel="stylesheet">
    <link href="<?php echo get_stylesheet_directory_uri();?>/css/owl.carousel.min.css" rel="stylesheet">
   <link href="<?php echo get_stylesheet_directory_uri();?>/css/custom.css" rel="stylesheet">
   <script type="text/javascript">
   var cd = jQuery.noConflict();
   cd(document).ready(function() { 
  	var queryString = window.location.search;
  	var urlParams = new URLSearchParams(queryString);
	
  //	alert(queryString);
 // alert(localStorage.getItem('orderbgid'));
 // alert(localStorage.getItem('refcode'));
     
  if (localStorage.getItem('orderbgid') > 0){
     //	alert('orderbgidyes');
		//alert(localStorage.getItem('orderbgid'));
		cd("#wdm_name").val(localStorage.getItem('orderbgid')) ;
 
   }else{
	  // alert('locabgnull');
 	    var page_type = urlParams.get('bgcode');
       // alert(page_type);
	  localStorage.setItem('orderbgid', page_type);
	//	alert(localStorage.getItem('orderbgid'));
	  cd("#wdm_name").val(localStorage.getItem('orderbgid')) ; 

   }

   if (localStorage.getItem('refcode') > 0){
	   // alert('locarefnullnot');
		//alert(localStorage.getItem('refcode'));
		cd("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 
   }else{  
	   //  alert('locarefnull');
 	    var page_type2 = urlParams.get('refcode');
       // alert(page_type2);
		localStorage.setItem('refcode', page_type2);
   	//	alert(localStorage.getItem('refcode'));
		cd("#wdm_name_ref").val(localStorage.getItem('refcode')) ; 

    }



     // alert(cd("#wdm_name").val());
     // alert(cd("#wdm_name_ref").val());


    
	
  });
  </script>

</head>

<body>
<header>
<div class="topHeader DeskShow">
  <div class="container">
    <div class="row">
        <div class="col-lg-4">
          <p class="d-flex"> <i class="hmPhoneIcon"> </i><span><?php echo get_field('phone_number',$settingspost_id);?></span> <span class="pl-2 pr-2 hmtopseprt"> | </span> <i class="hmmailIcon"> </i><span><a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>"><?php echo get_field('email_link',$settingspost_id);?></a> </span></p>
        </div>
        <div class="col-lg-8">
          <ul class="d-flex justify-content-end">
            <a href="http://lockmyseat.com/cart/"><li>          <?php echo "Cart";?></li></a>
          <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>">
          <li data-toggle="modal"><i class="hmSignInIcon"></i><span>Sign Out</span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/my-account/">
          <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/my-account/">Sign In</a></span></li>
          </a>
           <?php } ?> 
           <a href="<?php echo site_url();?>/my-account/">
          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span>My Account</span></li> </a>

          </ul>
        </div>
    </div>
  </div>
</div>


    <!-- Mobile Navigation -->
<section class="mobileShow " id="wrapper">
  <a href="#" class="menu"><img src="<?php echo get_stylesheet_directory_uri();?>/images/mobmenu.png"></a>
</section>
  <nav class="slide-content">
    <div class="hmclose"><img src="<?php echo get_stylesheet_directory_uri();?>/images/hmclose.png"></div>
  <ul class="pt-2">
  <?php if(is_user_logged_in()){?>
            <a href="<?php echo wp_logout_url( home_url() ); ?>">
          <li data-toggle="modal" data-target=""><i class="hmSignInIcon"></i><span>Sign Out</span></li>
          </a>
          <?php } else { ?>
            <a href="<?php echo site_url();?>/my-account/">
          <li><i class="hmAccountIcon"></i><span><a href="<?php echo site_url();?>/my-account/">Sign In</a></span></li>
          </a>
           <?php } ?> 
    <a href="<?php echo site_url();?>/my-account/">          
          <li data-toggle="modal" ><i class="hmRegisterIcon"></i><span>My Account</span></li> 
    </a>
    <li><a href="<?php echo site_url();?>/">Home</a></li>
    <li class="dropdown"><a href="" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
     <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
  </div>
    </li>
    <li><a href="<?php echo site_url();?>/how-it-works">How it works</a></li>
    <li><a href="<?php echo site_url();?>/contact-us">Contact</a></li>

  </ul>
</nav>
<div class="slide-fade"></div>
    <!-- Mobile Navigation close-->

   <div class="container">
    <div class="row headpad">
    <div class="col-lg-4 col-md-4 col-12">
    <a href="<?php echo site_url();?>"><img src="<?php echo get_stylesheet_directory_uri();?>/images/logo.png" alt="" class="img-fluid hmlogo"></a>
    </div>
    <div class="col-lg-8">
      <div class="searchBox">
        <form class="d-flex flex-wrap justify-content-between">

 

</form>

  </div>
  </div>
  </div>
  </div>

<div class="headMenu DeskShow">
<div class="container">
 <ul class="d-flex justify-content-center">
  <li class="active"><a href="<?php echo site_url();?>/">Home</a></li>
  <li class="dropdown"><a href="<?php echo site_url();?>/" class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services </a>
    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
      <a class="dropdown-item" href="<?php echo site_url();?>/category/simcard/">Sim Card</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/insurance/">Insurance</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/packages/">Packages</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/groups-travel/">Groups Travel</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/pcr/">PCR</a>
      <a class="dropdown-item" href="<?php echo site_url();?>/category/airport-services/">Airport Services</a>
    </div>
  </li>
    <li><a href="<?php echo site_url();?>/how-it-works">How it works</a></li>
    <li><a href="<?php echo site_url();?>/contact-us">Contact</a></li>
  </ul> 
 </div>
</div>

</header>