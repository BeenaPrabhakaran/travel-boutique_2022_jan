<?php
/**
 * Template Name: Contact Page Template
 *
 */
?>
<?php get_header();

 $settingspost_id = '128'; 
  $lang = apply_filters( 'wpml_current_language', NULL );
 // echo 'lang'.$lang;
?>
<style>
  .input-group .Message{width:648px; height:-1px ;}
  .conmap{padding-top: 93px;padding-bottom:40px;}
  @media only screen and (max-width: 768px) {
    .conmap{padding-top:0px;padding-bottom:0px;}
}
</style>
<main id="content" role="main">
        <!-- ========== MAIN CONTENT
       
         
            <div class="bg-gray-13 bg-md-transparent">
                <div class="container">
                 
                    <div class="my-md-3">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-3 flex-nowrap flex-xl-wrap overflow-auto overflow-xl-visble">
                                <li class="breadcrumb-item flex-shrink-0 flex-xl-shrink-1"><a href="../home/index.html">Home</a></li>
                                <li class="breadcrumb-item flex-shrink-0 flex-xl-shrink-1 active" aria-current="page">Contact-v1</li>
                            </ol>
                        </nav>
                    </div>
                  
                </div>
            </div>
            <!-- End breadcrumb -->

<?php if ( have_posts() ) { while ( have_posts() ) { the_post(); ?>
<div class="container">
<div class="mb-5">
<?php 
      if($lang == 'ar'){    ?>  
       <h1 class="text-center"><?php echo 'اتصل بنا'; ?></h1>
   <?php }else{?>
    <h1 class="text-center"><?php echo 'Contact Us'; ?></h1>
  <?php } ?>  
</div>
 <div class="row mb-10">
   <div class="col-lg-5 col-xl-5 mb-5 mb-lg-0">
    <div class="mr-xl-6">
      <div class="border-bottom border-color-1 mb-5">
     <?php 
      if($lang == 'ar'){    ?>
             <h3 class="section-title mb-0 pb-2 font-size-25">
                <?php  echo 'اترك لنا رسالة' ; ?></h3> 
       <?php }else{ ?>
        <h3 class="section-title mb-0 pb-2 font-size-25">
                Leave us a Message</h3>
       <?php }   ?> 
    
    </div>
    <p class="max-width-830-xl text-gray-90">
   
    <?php
    if($lang == 'ar'){    
       echo get_field('contact_page_message_arabic',$settingspost_id); 
    }else{
        echo get_field('contact_page_message',$settingspost_id);
    }   ?>
		
    <?php 
        if($lang == 'ar'){         
            echo do_shortcode( '[contact-form-7 id="3019" title="Contact Form Arabic"]' );
        }else{
            echo do_shortcode( '[contact-form-7 id="37" title="Contact form 1"]' );
        }
    
    //the_content(); ?>
    </div>
</div>

    <div class="col-lg-7 col-xl-7">
        <div class="mb-6 conmap" >
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.835252972956!2d144.95592398991224!3d-37.817327693787625!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sEnvato!5e0!3m2!1sen!2sin!4v1575470633967!5m2!1sen!2sin" width="100%" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
        </div>
        <div class="border-bottom border-color-1 mb-5">
            <h3 class="section-title mb-0 pb-2 font-size-25">Our Address</h3>          
      
        <address class="mb-6 text-lh-23">
        <?php //echo get_field('contact_address',$settingspost_id); 
		  echo "Travel BoutiqueKW ,"; ?>
		  
        <?php echo "Kuwait, Support:9867895678" ; ?>
            <div class="">Support<?php echo '9867895678'; ?></div>
            <div class="">Email: <a class="text-blue text-decoration-on" href="mailto:<?php echo "travelboutique@gmail.com"; ?>"><?php echo "travelboutique@gmail.com"; ?></a></div>
        </address> 
        </div>
        <!--<h5 class="font-size-14 font-weight-bold mb-3">Opening Hours</h5>
        <div class="">Monday to Friday: 9am-9pm</div>
        <div class="mb-6">Saturday to Sunday: 9am-11pm</div>


        <h5 class="font-size-14 font-weight-bold mb-3">Careers</h5>
        <p class="text-gray-90">If you’re interested in employment opportunities at Electro, please email us: <a class="text-blue text-decoration-on" href="mailto:contact@yourstore.com">contact@yourstore.com</a></p>
    -->
     </div>
   </div>
   <?php } 
    }   ?>
   </div>



        </main>
        <!-- ========== END MAIN CONTENT ========== -->
<?php get_footer(); ?>