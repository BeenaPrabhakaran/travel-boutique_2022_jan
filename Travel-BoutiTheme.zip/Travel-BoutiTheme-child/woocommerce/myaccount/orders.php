<?php
/**
 * Orders
 *
 * Shows orders on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/orders.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.7.0
 */

defined( 'ABSPATH' ) || exit;
 ?>
 <style>
	 .ui-state-default, .ui-widget-content .ui-state-default{border:none;border-radius:0%;}
 </style>	 
<script type="text/javascript">
   function bloggerdateSorter(){


 var ordsortby  = $("#sortorder").val();
 var userid     = $("#userval").val();
  $.ajax({
    type:'POST',
    data:{"action":"filterdaterange","sortby":ordsortby,"userval":userid},       
    url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
    success: function(data) {    
      if ($.trim(data) == 'F' ) {   
        $("#reshead").hide();
        $("#replace").html('No Order Data Found'); 

      }else{
        $("#reshead").show();
       $("#replace").html(data); 
      } 
    }		
  }); 
   
}
</script>
 <?php
      $lang = apply_filters( 'wpml_current_language', NULL );
  ?>


  <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
        <thead>     
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
      
        <td>   
        <div class="sortoption " style="width:100%">
       
        <?php  if($lang =='ar'){?>
        <div class="form-group mr-3 downArrow">
          <select class="form-control" id="sortorder" onchange="bloggerdateSorter();">
            <option value="0"><?php echo 'فرز حسب الحالة'  ; ?></option>
            <option value="pending"><?php echo 'في انتظار الدفع' ; ?></option>
            <option value="shipped"><?php echo 'شحنها' ; ?></option>
            <option value="on-hold"><?php echo 'حجب' ; ?></option>
            <option value="completed"><?php echo 'مكتمل' ; ?></option>
            <option value="processing"><?php echo 'معالجة' ; ?></option>
            <option value="cancelled"><?php echo 'ألغيت' ; ?> </option>
            <option value="refunded"><?php echo 'إعادة مال' ; ?></option>
            <option value="failed"><?php echo 'فشل' ; ?></option>
           </select>
        </div>
      <?php }else{ ?>
        <div class="form-group mr-3 downArrow">
          <select class="form-control" id="sortorder" onchange="bloggerdateSorter();">
            <option value="0">Sort by status</option>
            <option value="pending">Pending Payment</option>
            <option value="shipped">Shipped</option>
            <option value="on-hold">On Hold</option>
            <option value="completed"> Completed</option>
            <option value="processing"> Processing</option>
            <option value="cancelled">Cancelled</option>
            <option value="refunded">Refunded</option>
            <option value="failed">Failed</option>
           </select>
        </div>


     <?php } ?>

        </div>
        </td>
     </tr> 
     <?php  if($lang =='ar'){?>
        <tr id="reshead">
            <th class="booking-id"><span class="nobr"><?php echo ' طلبيةId' ; ?></span></th>
            <th class="booking-from"><span class="nobr"><?php echo 'معرف عنصر الطلب' ; ?></span></th>
            <th class="booking-to"><span class="nobr"><?php echo 'تم طلب العنصر' ; ?></span></th>
            <th class="booking-status"><span class="nobr"><?php echo 'حالة الطلب' ; ?></span></th>            
        </tr>
      <?php }else{ ?>
        <tr id="reshead">
            <th class="booking-id"><span class="nobr">Order Id</span></th>
            <th class="booking-from"><span class="nobr">Order Item ID</span></th>
            <th class="booking-to"><span class="nobr">Order Items</span></th>
            <th class="booking-status"><span class="nobr">Order Status</span></th>            
        </tr>

      <?php } ?>

        </thead>
       <tbody id="replace" >
    <?php 
     global $current_user;
     $user_id = get_current_user_id();
      global $wpdb;
     $orme  = $wpdb->prefix.'wc_order_stats';
     $ormeta = $wpdb->prefix.'woocommerce_order_itemmeta';
     $ormeta2 = $wpdb->prefix.'woocommerce_order_items';
     $orderarray = array(); 
     $orderitems = array(); 
 
       $ormequery = "select order_id from " .$orme. " where customer_id = " .$user_id ;
      // echo "select order_id from " .$orme. " where customer_id = " .$user_id ;
       $ormeres   = $wpdb->get_results($ormequery); 
       foreach($ormeres as $ormeval){
             $orderarray[]  = $ormeval->order_id;
       } 
      //print_r($orderarray); 
	  //883 891 
	 if(count($orderarray)> 0 ) {
		 
		$orderidsarray = array();
      foreach($orderarray as $ordval){
			$qrybg2 = "SELECT distinct(item.order_item_id),ord.order_id, ord.order_item_name 
			FROM " .$ormeta. " item ,".$ormeta2. " ord WHERE 
			item.order_item_id = ord.order_item_id AND
			ord.order_id = '".$ordval."' ";
	
      $res2 = $wpdb->get_results( $qrybg2); 
 
         foreach($res2 as $result2){ 
            $orderidsarray[] = $result2->order_id;
            $order = wc_get_order($result2->order_id);
            $ordrdate = date_create($order->get_date_created());            
           ?>   
           <tr id="statuschecked">
              <td><?php echo $result2->order_id .'<br/>'; ?>
              <?php echo 'Order Created On : '.date_format( $ordrdate,'d-m-Y');?></td>       
              <td><?php echo $result2->order_item_id;?></td>
              <td><?php echo $result2->order_item_name;?></td>          
              <td><?php echo $order->get_status();?></td>
      
            </tr>
		
          
          <?php  }  
                  
        }    $ordvalstr =  implode(",",$orderidsarray);   
		
		?>
     
	  <?php }else{ ?>
		<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
		<a class="woocommerce-Button button" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>"><?php esc_html_e( 'Browse products', 'woocommerce' ); ?></a>
		<?php esc_html_e( 'No order has been made yet.', 'woocommerce' ); ?>
	</div>

	  <?php } 
       ?>

     <tbody>
     <input type="hidden"  name="userval" id="userval" value="<?php echo $user_id; ?>">
 </table>     
<?php do_action( 'woocommerce_after_account_orders', $has_orders ); ?>
