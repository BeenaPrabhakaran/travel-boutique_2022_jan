<?php
/**
 * Bookings
 *
 * Shows booking on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/bookings-table.php.
 *
 * @var YITH_WCBK_Booking[] $bookings
 * @var bool                $has_bookings
 */

if ( !defined( 'ABSPATH' ) ) {
    exit;
}  
    global $current_user;
    $bookuser_id = get_current_user_id();
    global $wpdb;

?>
 <script type="text/javascript">
  function bloggerbookingSorter(){     
      var orderby = $("#sortbooking").val();
      var userid     = $("#bookid").val();
      var ordarray   = $("#orderids").val();    
      var pidarray = ordarray.split(',');
      $.ajax({
         type:'POST',
         data:{"action":"filterbookingstatus","sortby":orderby,"ordval":pidarray},       
         url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
    success: function(data) {       
        $("#replace").html(data); 
        if ($.trim(data) == 'F' ) {   
        $("#reshead").hide();
            $("#replace").html('No Data Found'); 
        }else{
             $("#reshead").show();
            $("#replace").html(data); 
         } 
        }		
     });   
  }

 </script>
 <?php
   $lang = apply_filters( 'wpml_current_language', NULL );

   if($lang == 'ar'){  
       $account_bookings_columns = array(
           'booking-id'      => __( 'الحجز', 'yith-booking-for-woocommerce' ),
           'booking-order'   => __( 'طلب', 'yith-booking-for-woocommerce' ),
           'booking-from'    => __( 'من', 'yith-booking-for-woocommerce' ),
           'booking-to'      => __( 'ل', 'yith-booking-for-woocommerce' ),
           'booking-status'  => __( 'حالة', 'yith-booking-for-woocommerce' ),
           'booking-actions' => '&nbsp;',
   
       );
   }else{
       $account_bookings_columns = array(
           'booking-id'      => __( 'Booking', 'yith-booking-for-woocommerce' ),
           'booking-order'   => __( 'Order', 'yith-booking-for-woocommerce' ),
           'booking-from'    => __( 'From', 'yith-booking-for-woocommerce' ),
           'booking-to'      => __( 'To', 'yith-booking-for-woocommerce' ),
           'booking-status'  => __( 'Status', 'yith-booking-for-woocommerce' ),
           'booking-actions' => '&nbsp;',
   
       );  
   
   }	

 /* 
 $account_bookings_columns = array(
    'booking-id'      => __( 'Booking', 'yith-booking-for-woocommerce' ),
    'booking-order'   => __( 'Order', 'yith-booking-for-woocommerce' ),
    'booking-from'    => __( 'From', 'yith-booking-for-woocommerce' ),
    'booking-to'      => __( 'To', 'yith-booking-for-woocommerce' ),
    'booking-status'  => __( 'Status', 'yith-booking-for-woocommerce' ),
    'booking-actions' => '&nbsp;',

);  */
  $account_bookings_columns = apply_filters( 'yith_wcbk_my_account_booking_columns', $account_bookings_columns );
?>
<?php do_action( 'yith_wcbk_before_bookings_table', $has_bookings ); $ordarray = array(); ?>

<?php if ( $has_bookings ) :
    
     foreach ( $bookings as $booking ){
        $ordarray[] =  $booking->order_id ;
   }
   
    

      //print_r($ordarray);
      $ordids = implode(',',$ordarray);
    ?>

    <table class="shop_table shop_table_responsive my_account_bookings account-bookings-table">
        <thead>
        <tr>
          <td></td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
      
        <td colspan="3">   
        <div class="sortoption " style="width:100%">
        <input type="hidden" name="orderids" id="orderids" value="<?php echo $ordids; ?>">
        <input type="hidden" name="bookid" id="bookid" value="<?php echo $bookuser_id;?>">
        
        <?php
        if($lang == 'ar'){ ?>  
        <div class="form-group mr-3 downArrowarb">
          <select class="form-control" id="sortbooking" onchange="bloggerbookingSorter();">
            <option value="0"><?php echo 'الجميع'; ?></option>
            <option value="bk-paid"><?php echo 'دفع'  ; ?></option>
            <option value="bk-cancelled"><?php echo 'ألغيت' ; ?></option>
            <option value="bk-completed"><?php echo 'مكتمل' ; ?></option>
           </select>
           </div>  
        <?php } else{?>  
            <div class="form-group mr-3 downArrow"> 
           <select class="form-control" id="sortbooking" onchange="bloggerbookingSorter();">
            <option value="0">All</option>
            <option value="bk-paid">Paid</option>
            <option value="bk-cancelled">Cancelled</option>
            <option value="bk-completed">Completed</option>
           </select>
           </div>   
        <?php } ?>   


        
        </div>
        </td>
</tr>
        <tr id="reshead">
            <?php foreach ( $account_bookings_columns as $column_id => $column_name ) :  ?>
                <th class="<?php echo esc_attr( $column_id ); ?>"><span class="nobr"><?php echo esc_html( $column_name ); ?></span></th>
            <?php endforeach; ?>
        </tr>
        </thead>

        <tbody id="replace">
        <?php foreach ( $bookings as $booking ) :
            $order = wc_get_order( $booking->order_id );
            ?>
            <tr class="booking">
                <?php foreach ( $account_bookings_columns as $column_id => $column_name ) : ?>
                    <td class="<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
                        <?php if ( has_action( 'yith_wcbk_my_account_booking_column_' . $column_id ) ) {
                            do_action( 'yith_wcbk_my_account_booking_column_' . $column_id, $order, $booking );
                        } else {
                            switch ( $column_id ) {
                                case 'booking-id':
                                    $url   = esc_url( $booking->get_view_booking_url() );
                                    $title = $booking->get_title();
                                    echo "<a href='$url'>$title</a>";
                                    break;
                                case 'booking-order':
                                    $url   = esc_url( $order->get_view_order_url() );
                                    $title = _x( '#', 'hash before order number', 'woocommerce' ) . $order->get_order_number();
                                    echo "<a href='$url'>$title</a>";
                                    break;
                                case 'booking-from':
                                    echo $booking->get_formatted_date( 'from' );
                                    break;
                                case 'booking-to':
                                    echo $booking->get_formatted_date( 'to' );
                                    break;
                                case 'booking-status':
                                    echo $booking->get_status_text();
                                    break;
                                case 'booking-actions':
                                    do_action( 'yith_wcbk_show_booking_actions', $booking, true );
                                    break;
                            }
                        }
                        ?>
                    </td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php do_action( 'yith_wcbk_before_account_bookings_pagination' ); ?>

<?php endif; ?>

<?php do_action( 'yith_wcbk_after_bookings_table', $has_bookings ); ?>

