<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
	global $current_user;
	$user_id = get_current_user_id();
	global $wpdb;
	
	
	$tbl1 = $wpdb->prefix.'termmeta';
	$tbl2 = $wpdb->prefix.'blogger_product';

	$qry = $wpdb->get_row( $wpdb->prepare("select tm.term_id ,bl.blogger_id from ". $tbl1 . " tm ," .  $tbl2 . " bl 
		where tm.term_id = bl.blogger_id AND tm.meta_key ='owner' AND tm.meta_value =  " .$user_id));

	$bgid =  $qry->blogger_id;
 
do_action( 'woocommerce_before_account_navigation' );
?>
<?php if($bgid == ''){?>
<nav class="woocommerce-MyAccount-navigation" >
	<ul>
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"><?php echo esc_html( $label ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
<?php }else{ ?>
	<nav class="woocommerce-MyAccount-navigation" >
	<ul>
	<?php   $lang = apply_filters( 'wpml_current_language', NULL );
	  if($lang == 'ar'){	
	?>	
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--dashboard is-active">
			<a href="<?php echo site_url();?>/my-account/"><?php echo 'لوحة القيادة' ; ?></a>
		</li>
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-address">
			<a href="<?php echo site_url();?>/my-account/bookings/"><?php echo 'الحجوزات' ; ?></a>
		</li>
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-account">
			<a href="<?php echo site_url();?>/my-account/edit-account/"><?php echo 'تفاصيل الحساب' ; ?></a>
		</li>	
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--customer-logout">
			<a href="<?php echo site_url();?>/my-account/customer-logout/?_wpnonce=ea02a7d77f"><?php echo 'تسجيل خروج' ; ?></a>
		</li>
    <?php } else{ ?>
        <li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--dashboard is-active">
			<a href="<?php echo site_url();?>/my-account/">Dashboard</a>
		</li>
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-address">
			<a href="<?php echo site_url();?>/my-account/bookings/">Bookings</a>
		</li>
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--edit-account">
			<a href="<?php echo site_url();?>/my-account/edit-account/">Account details</a>
		</li>	
		<li class="woocommerce-MyAccount-navigation-link woocommerce-MyAccount-navigation-link--customer-logout">
			<a href="<?php echo site_url();?>/my-account/customer-logout/?_wpnonce=ea02a7d77f">Logout</a>
		</li>    
	 <?php } ?>
	</ul>
  </nav>
  <?php } ?>
<?php do_action( 'woocommerce_after_account_navigation' ); ?>