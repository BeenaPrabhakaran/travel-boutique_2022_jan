<?php
/**
 * Display single product reviews (comments)
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product-reviews.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.3.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! comments_open() ) {
	return;
}
	global $wpdb;
	$tablere = $wpdb->prefix.'blogger_product_review';
	if(isset($_GET['bgcode'])){
		$us = $_REQUEST['bgcode'];
	}
	if(isset($_GET['refcode'])){
		$us = $_REQUEST['refcode'];
	}

	$qry ="select * from " .$tablere. " where
			bpid  = ".$us;
	$rowcount = $wpdb->get_var("SELECT COUNT(*) FROM $tablere WHERE 
	             bp_status = 'Approved'  AND bpid = ".$us);	
?>
 <script type="text/javascript">
  function savereview(){
	 var cmd = $("#comment").val();
	 var ath = $("#author").val();
	 var em  = $("#email").val();
	 var usr = $("authe").val();
	 var bpid = $("#bgp").val();
	 if(cmd ==''){
		
		 alert("Enter review");
		 return false;
	 }
	 else if(ath == ''){
		alert("Enter Name");
		 return false;
	 }
	 else if(em == ''){
		alert("Enter Email");
		 return false;
	 }else{
		 $.ajax({
              type:'POST',
              data:{"action":"saveReview","areview": cmd,"aname":ath,"aemail":em,"pdid":bpid,"auid":usr},          
              url: "<?php bloginfo('url'); ?>/wp-admin/admin-ajax.php",
              success: function(data) {          
				  //alert(data);
                $("#resultaddeddiv").html(data);         

               }

        });
		
		
		 return true;

	 }
  } 
 </script>

 <?php
    if(is_user_logged_in() ) {
      $us = get_current_user_id();
	  $user_info = get_userdata($us);
	  $username = $user_info->user_login;
	  //$user_name = $user_info->display_name;
	  $user_email = $user_info->user_email;
	//  $user = wp_get_current_user(); // getting & setting the current user 
	 
	}
	if(isset($_GET['bgcode'])) {
        $blg  = $_GET['bgcode'];
   }
   if(isset($_GET['refcode'])) {
        $blg  = $_GET['refcode'];
   } 
 ?>
	
<div id="reviews" class="woocommerce-Reviews">
	<div id="comments">
	<input type="hidden" name="authe" id="authe" value="<?php echo $us; ?>">
	<input type="hidden" name="bgp" id="bgp" value="<?php echo $blg;?>">
	
	<?php /* <h3 style="font-size:15px;">
		<?php
			$count = $rowcount;
			//echo $count;
			if ($count != '0') {
			
				
				$reviews_title = sprintf( esc_html( _n( '%1$s review for %2$s', '%1$s reviews for %2$s', $count, 'woocommerce' ) ), esc_html( $count ), '<span>' . get_the_title() . '</span>' );
				echo apply_filters( 'woocommerce_reviews_title', $reviews_title, $count, $product ); // WPCS: XSS ok.
			} else {
				esc_html_e( 'Reviews', 'woocommerce' );
			}
			?> 

        </h3> */ ?>

		<?php if ( $rowcount != '0') : 
			 global $wpdb;
			 $tab = $wpdb->prefix.'blogger_product_review';
			  if(isset($_GET['bgcode'])){
				  $uss = $_REQUEST['bgcode'];
			  }
			  if(isset($_GET['refcode'])){
				  $uss = $_REQUEST['refcode'];
			  }
		  
			  $qryatb ="select * from " .$tab. " where 
					 bp_status ='Approved' AND
					 bpid  = ".$uss;   
    


			  $resultstb = $wpdb->get_results($qryatb);		 
			 
			  ?>
			  <ol class="commentlist" style="padding:0px;">
			 <?php
			  foreach($resultstb as $result){ ?>
			<li >
      <?php if($result->bp_type == 'blogger'){ ?> <strong> <?php  echo "Bloggers Review";?> </strong> <?php } ?>
		<p class="meta">
			<p><?php echo $result->bp_pro_review; ?></p>
				<p class="reviewmeta" style="text-align:right;">				
				  <strong class="woocommerce-review__author"><?php echo $result->bp_name; ?> </strong>
				  <span class="woocommerce-review__dash">&ndash;</span> 
			         <time class="woocommerce-review__published-date" datetime="<?php echo esc_attr( get_comment_date( 'c' ) ); ?>">
				     <?php echo $result->bp_date; ?></time>			     		
			    </p>
			 </p> </li>		
		    <?php } ?>
		
		   
			</ol>


		<?php else : ?>
			<p class="woocommerce-noreviews"><?php esc_html_e( 'There are no reviews yet.', 'woocommerce' ); ?></p>
		<?php endif; ?>
    </div>
<?php 

		$qryatb2 = $wpdb->get_results("select bg_prod_rewid from " .$tab. " where bp_userid = " .$us. " AND bpid  = ".$uss);  
		//echo "select bg_prod_rewid from " .$tab. " where bp_userid = " .$us. " AND bpid  = ".$uss;

	
		$rowcountrw = $wpdb->num_rows;
		//echo $rowcountrw;
  if($rowcountrw  < 1){?>
 <div id="review_form_wrapper">
  <div id="review_form">
			
		<form  method="post" id="commentform" class="comment-form" validate>
		<p class="comment-notes">
		<span id="email-notes">Your email address will not be published.</span> Required fields are marked <span class="required">*</span>
		</p>
		<div id="resultaddeddiv"></div>
		<p class="comment-form-comment"><label for="comment">Your review&nbsp;<span class="required">*</span></label>
		<textarea id="comment" name="comment" cols="45" rows="8" required=""></textarea></p>

		<p class="comment-form-author"><label for="author">Name&nbsp;<span class="required">*</span></label>
		<input class="form-control" id="author" name="author" type="text" value="<?php echo $username;?>" size="30" required=""></p>

		<p class="comment-form-email">
		<label for="email">Email&nbsp;<span class="required">*</span></label>
		<input class="form-control" id="email" name="email" type="email" value="<?php echo $user_email;?>" size="30" required=""></p>
		<br/>

		<p class="form-submit"><input name="submitreview" type="button" id="submitreview" class="submit" value="Submit" onclick="savereview();">

		</p>
		</form>
   </div>
 </div>
<?php } ?>

	<div class="clear"></div>

</div>


