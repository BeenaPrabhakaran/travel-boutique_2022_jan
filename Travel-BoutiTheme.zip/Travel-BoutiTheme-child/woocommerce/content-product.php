<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
global $wp;
$current_url = home_url( add_query_arg( array(), $wp->request ) );
$from="";
$location='';
$categories='';
$s='';
if(isset($_GET['from'])):
$from = wp_strip_all_tags($_GET['from']);    
endif;
if(isset($_GET['location'])):
 $location = wp_strip_all_tags($_GET['location']);    
endif;
if(isset($_GET['categories'])):
 $categories = wp_strip_all_tags($_GET['categories']);    
endif;
if(isset($_GET['s'])):
 $s = wp_strip_all_tags($_GET['s']);    
endif;

?>
<style>
.star-rating span{
    word-break: normal;
}
</style>
<?php
// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
 
 /*$pdids  = array();
 $pds = array();
 $bgids = array();
  $pdids[] = $product->get_id();
  print_r($pdids);
  global $wpdb;
  $tbl3 = $wpdb->prefix.'terms';
  $tbl4 = $wpdb->prefix.'blogger_product';
  echo "select distinct(bg.blogger_id), t.name from " . $tbl4  ." bg ," .$tbl3 . " t where 
  bg.blogger_id = t.term_id  AND bg.product_id in ($pdids) " ; 



  
 /*foreach($pdids as $pdval){ 
  $qry2 ="select distinct(bg.blogger_id), t.name from " . $tbl4  ." bg ," .$tbl3 . " t where 
          bg.blogger_id = t.term_id  AND bg.product_id = " .$pdval ;  
		  echo "select distinct(bg.blogger_id), t.name from " . $tbl4  ." bg ," .$tbl3 . " t where 
           bg.blogger_id = t.term_id  AND bg.product_id = " .$pdval ;
  $results2 = $wpdb->get_results($qry2);*/
 //}    
 
?>
  







