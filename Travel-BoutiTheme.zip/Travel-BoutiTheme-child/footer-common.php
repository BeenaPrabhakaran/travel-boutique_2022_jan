<?php $settingspost_id = '58';
//  $lang = apply_filters( 'wpml_current_language', NULL ); 
  $lang = apply_filters( 'wpml_current_language', NULL ); 
 // echo $lang;
  ?>
 <?php if($lang == 'ar'){ ?>  
 <footer class="footarabi">
 <?php }else{?>
  <footer>
 <?php } ?>

 <div class="container">
    
    <div class="row">
      <div class="col-lg-4">
        <div class="footlogo">
        <img src="<?php echo get_stylesheet_directory_uri();?>/images/footlogo.png">
      </div>
      <div class="footAddres">
        
        <?php if($lang == 'ar'){ ?> 
          <p class="d-flex pt-3"> <i class="adresLocicon" ></i>   <span style="padding-right:10px;">   
          <?php echo get_field('contact_address_footer_arabic',$settingspost_id);?></span></p>
        <?php }else{ ?>
          <p class="d-flex pt-3"><i class="adresLocicon"></i> <span>
          <?php echo get_field('contact_address_footer',$settingspost_id);?></span></p>

        <?php } ?>
        <?php if($lang == 'ar'){ ?> 
        <p class="d-flex pt-3"><i class="footEmailicon"></i>  <span style="padding-right:10px;">  
        <a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>" style="color:#fff;"><?php echo get_field('email_link',$settingspost_id);?></a></span></p>
            <?php } else{ ?>
              <p class="d-flex pt-3"><i class="footEmailicon"></i> <span>
        <a href="mailto:<?php echo get_field('email_link',$settingspost_id);?>" style="color:#fff;"><?php echo get_field('email_link',$settingspost_id);?></a></span></p>

          <?php  } ?>
          <?php if($lang == 'ar'){ ?> 
          <p class="d-flex pt-3"><i class="footPhoneIcon"></i><span style="padding-right:10px;"><?php echo get_field('phone_number',$settingspost_id);?></span>
        </p>
      <?php } else{ ?>
          <p class="d-flex pt-3" ><i class="footPhoneIcon"></i><?php echo get_field('phone_number',$settingspost_id);?></p>

          <?php } ?>
      </div>
      </div>

      <div class="col-lg-3">
        <div class="footLinks">
        <?php if($lang == 'ar'){?>     
        <h2> <?php echo get_field('footer_quick_link_label_arabic',$settingspost_id);?></h2>
        <?php wp_nav_menu( array( 'container' => false,'menu_class'=>'menufootarabi','menu' => get_field('footer_links',$settingspost_id))); ?>
      <?php }else{ ?>
        <h2> <?php echo get_field('footer_quick_link_label',$settingspost_id);?></h2>
        <?php wp_nav_menu( array( 'container' => false,'menu_class'=>'','menu' => get_field('footer_links',$settingspost_id))); ?>
    
      <?php } ?>    </div>
      </div>

      <div class="col-lg-5">
  
      <?php if($lang == 'ar'){ ?>  
        <div class="footLinks footSubscribe footarb">  
        <h2> <?php echo get_field('footer_subscription_section_label_arabic',$settingspost_id);?> </h2>   
        <?php echo do_shortcode( '[email-subscribers-form id="2"]' ); ?>
       </div>
      <?php }else{ ?>    
        <div class="footLinks footSubscribe foot">  
        <h2> <?php echo get_field('footer_subscription_section_label',$settingspost_id);?> </h2>
        <?php echo do_shortcode( '[email-subscribers-form id="2"]' ); ?>
        </div>
      <?php } ?>  

    
   <?php if($lang== 'ar'){?> 
      <div class="footSocial" style="padding-top:0px;" >  
        <h2><?php echo get_field('footer_section_social_media_label_arabic',$settingspost_id);?></h2>
        <ul class="d-flex"> 
      <li><a href="<?php echo get_field('facebook_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/facebook.png"></li></a>
      <li><a href="<?php echo get_field('whatsapp_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/whatsapp.png"></li></a>
       <li><a href="<?php echo get_field('insta_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/instagram.png"></li></a>
        <li><a href="<?php echo get_field('youtube_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/youtube.png"></li></a>
      </ul>
      </div>  
     <?php }else{?>
      <div class="footSocial"> 
      <h2><?php echo get_field('footer_section_social_media_label',$settingspost_id);?></h2>
      <ul class="d-flex"> 
      <li><a href="<?php echo get_field('facebook_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/facebook.png"></li></a>
      <li><a href="<?php echo get_field('whatsapp_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/whatsapp.png"></li></a>
      <li><a hr ef="<?php echo get_field('insta_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/instagram.png"></li></a>
      <li><a href="<?php echo get_field('youtube_link',$settingspost_id);?>"> <img src="<?php echo get_stylesheet_directory_uri();?>/images/youtube.png"></li></a>
      </ul>
      </div>
     <?php } ?>
      </div>


    </div>
  </div>
</footer>
<section class="footBottombg">
  <div class="container">
    <div class="row">
    <div class="col-lg-6">
    <?php if($lang== 'ar'){?>    
      <?php echo get_field('copyright_text_arabic',$settingspost_id);?>
    <?php }else{?>
      <?php echo get_field('copyright_text',$settingspost_id);?>
     <?php } ?>  
      </div>
      <div class="col-lg-6">
        <div class="footMenu">
    <?php if($lang == 'ar'){ ?>
      <?php wp_nav_menu( array( 'container' => false,'menu' => get_field('footer_downside_menu_arabic',$settingspost_id),'items_wrap' => '<ul class="d-flex flex-wrap justify-content-end">%3$s</ul>' ) ); ?>
    <?php }else{ ?>
    <?php wp_nav_menu( array( 'container' => false,'menu' => get_field('footer_downside_menu',$settingspost_id),'items_wrap' => '<ul class="d-flex flex-wrap justify-content-end">%3$s</ul>' ) ); ?>
    <?php } ?> 
        
       </div>
      </div>
    </div>
  </div>
</section>


  <script src="<?php echo get_stylesheet_directory_uri();?>/js/jquery.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/owl.carousel.min.js"></script>
  <script src="<?php echo get_stylesheet_directory_uri();?>/js/custom.js"></script>
<script defer src="<?php echo get_stylesheet_directory_uri();?>/js/jquery.flexslider.js"></script>
   <script src="<?php echo get_stylesheet_directory_uri();?>/js/jquery-ui.min.js"></script>

  <script type="text/javascript">
$(window).load(function() {
  // The slider being synced must be initialized first
  $('#carousel').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: true,
    itemMargin: 5,
    asNavFor: '#slider'
  });
 
  $('#slider').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: true,
    sync: "#carousel"
  });
});


$(function() {
  $( ".calendar" ).datepicker({
    dateFormat: 'dd/mm/yy',
    firstDay: 1
  });
  
  $(document).on('click', '.date-picker .input', function(e){
    var $me = $(this),
        $parent = $me.parents('.date-picker');
    $parent.toggleClass('open');
  });
  
  
  $(".calendar").on("change",function(){
    var $me = $(this),
        $selected = $me.val(),
        $parent = $me.parents('.date-picker');
    $parent.find('.result').children('span').html($selected);
  });
});
  </script>
  <?php wp_footer();?>
</body>
</html>