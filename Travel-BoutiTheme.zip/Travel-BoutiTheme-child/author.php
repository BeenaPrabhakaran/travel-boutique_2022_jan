<?php
/**
 * The template for displaying Author archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header(); ?>

	<section id="primary" class="content-area">
		<div id="content" class="site-content" role="main">

		

			<header class="archive-header">
				<h1 class="archive-title">
				
				</h1>
				

		</div><!-- #content -->
	</section><!-- #primary -->

<?php
get_footer(); ?>