<?php

namespace WeglotWP\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Name pages
 *
 * @since 2.0
 */
abstract class Helper_Pages_Weglot {
	const SETTINGS = 'weglot-settings';
}
